import"./C5icPxR5.js";const t=""+new URL("review.CkGWtyWZ.svg",import.meta.url).href;export{t as _};
