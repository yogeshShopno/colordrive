import"./C5icPxR5.js";const o=""+new URL("cta-mob.D9CvMBG5.webp",import.meta.url).href;export{o as _};
