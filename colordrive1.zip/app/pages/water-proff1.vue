<script setup></script>

<template>
  <!-- main banner start -->
  <section
    id="blog-new"
    class="py-100 px-3 mb-50px"
    data-v-inspector="app/pages/blog.vue:5:3"
    data-v-1bac7c7d=""
  >
    <div
      class="container mx-auto"
      data-v-inspector="app/pages/blog.vue:6:5"
      data-v-1bac7c7d=""
    >
      <!-- <h1>Blog</h1> -->
      <div class="text-center">
        <h2 class="text font-bold">Estimate Waterproofing cost</h2>
        <div class="flex items-center gap-2 justify-center mt-3">
          <a href="index.vue">
            <p class="text-gray-500">Home</p>
          </a>
          <i class="fa-solid fa-chevron-right text-gray-500"></i>
          <p class="pink-txt">Estimate Waterproofing cost</p>
        </div>
      </div>
    </div>
  </section>
  <!-- main banner end -->

  <!-- service Post section start -->
  <section id="service-post" class="pb-200 mt-50px px-4 px-md-0">
    <div class="container mx-auto">
      <div class="max-w-4xl mx-auto">
        <div class="firstsecdiv">
          <div class="bg-white mainboxshadoww rounded-2xl p-5">
            <div>
              <div class="calcseccardsdiv mt-5">
                <div class="calcspace">
                  <div class="calccardtitle flex justify-between mb-3">
                    <h5 class="font-bold">
                      Select surface needs waterproofing
                    </h5>
                    <div class="searchdiv">
                      <i class="fa-solid fa-magnifying-glass"></i>
                    </div>
                  </div>
                  <div class="calccardspacemini sliderdiv text1">
                    <Swiper
                      class="catalogue"
                      :slides-per-view="1"
                      :loop="true"
                      :breakpoints="{
                        425: { slidesPerView: 2 }, 
                        768: { slidesPerView: 3 },
                        1024: { slidesPerView: 5 },
                      }"
                      :modules="[
                        SwiperAutoplay,
                        SwiperEffectCreative,
                        SwiperNavigation,
                      ]"
                      :autoplay="{
                        delay: 3000,
                        disableOnInteraction: true,
                      }"
                      :pauseAutoplayOnMouseEnter="true"
                      :navigation="true"
                      :pagination="{
                        clickable: true,
                      }"
                    >
                      <SwiperSlide class="h-100">
                        <div class="m-4 text-center pt-6 h-100">
                          <div class="calccardspacemini0">
                            <a
                              href=""
                              class="imgcalcdiv align-center bg-gray-300 flex justify-center p-4 rounded-md"
                            >
                              <img
                                src="assets/images/calculator/icn1.png"
                                alt="Interior Painting"
                                width=""
                                class="br-16 max-w-full h-auto"
                              />
                            </a>
                            <div class="lablediv mt-2 text-center">
                              <p class="text-sm">Interior</p>
                            </div>
                          </div>
                          <!-- <div
                            class="bg-white shadow-mds p-3 sm:p-5 rounded-2xl relative h-100"
                          >
                          </div> -->
                        </div>
                      </SwiperSlide>
                      <SwiperSlide class="h-100">
                        <div class="m-4 text-center pt-6 h-100">
                          <div class="calccardspacemini0">
                            <a
                              href=""
                              class="imgcalcdiv align-center bg-gray-300 flex justify-center p-4 rounded-md"
                            >
                              <img
                                src="assets/images/calculator/icn2.png"
                                alt="Interior Painting"
                                width=""
                                class="br-16 max-w-full h-auto"
                              />
                            </a>
                            <div class="lablediv mt-2 text-center">
                              <p class="text-sm">Interior</p>
                            </div>
                          </div>
                          <!-- <div
                            class="bg-white shadow-mds p-3 sm:p-5 rounded-2xl relative h-100"
                          >
                          </div> -->
                        </div>
                      </SwiperSlide>
                      <SwiperSlide class="h-100">
                        <div class="m-4 text-center pt-6 h-100">
                          <div class="calccardspacemini0">
                            <a
                              href=""
                              class="imgcalcdiv align-center bg-gray-300 flex justify-center p-4 rounded-md"
                            >
                              <img
                                src="assets/images/calculator/icn3.png"
                                alt="Interior Painting"
                                width=""
                                class="br-16 max-w-full h-auto"
                              />
                            </a>
                            <div class="lablediv mt-2 text-center">
                              <p class="text-sm">Interior</p>
                            </div>
                          </div>
                          <!-- <div
                            class="bg-white shadow-mds p-3 sm:p-5 rounded-2xl relative h-100"
                          >
                          </div> -->
                        </div>
                      </SwiperSlide>
                      <SwiperSlide class="h-100">
                        <div class="m-4 text-center pt-6 h-100">
                          <div class="calccardspacemini0">
                            <a
                              href=""
                              class="imgcalcdiv align-center bg-gray-300 flex justify-center p-4 rounded-md"
                            >
                              <img
                                src="assets/images/calculator/icn4.png"
                                alt="Interior Painting"
                                width=""
                                class="br-16 max-w-full h-auto"
                              />
                            </a>
                            <div class="lablediv mt-2 text-center">
                              <p class="text-sm">Interior</p>
                            </div>
                          </div>
                          <!-- <div
                            class="bg-white shadow-mds p-3 sm:p-5 rounded-2xl relative h-100"
                          >
                          </div> -->
                        </div>
                      </SwiperSlide>
                      <SwiperSlide class="h-100">
                        <div class="m-4 text-center pt-6 h-100">
                          <div class="calccardspacemini0">
                            <a
                              href=""
                              class="imgcalcdiv align-center bg-gray-300 flex justify-center p-4 rounded-md"
                            >
                              <img
                                src="assets/images/calculator/icn5.png"
                                alt="Interior Painting"
                                width=""
                                class="br-16 max-w-full h-auto"
                              />
                            </a>
                            <div class="lablediv mt-2 text-center">
                              <p class="text-sm">Interior</p>
                            </div>
                          </div>
                          <!-- <div
                            class="bg-white shadow-mds p-3 sm:p-5 rounded-2xl relative h-100"
                          >
                          </div> -->
                        </div>
                      </SwiperSlide>
                      <SwiperSlide class="h-100">
                        <div class="m-4 text-center pt-6 h-100">
                          <div class="calccardspacemini0">
                            <a
                              href=""
                              class="imgcalcdiv align-center bg-gray-300 flex justify-center p-4 rounded-md"
                            >
                              <img
                                src="assets/images/calculator/icn1.png"
                                alt="Interior Painting"
                                width=""
                                class="br-16 max-w-full h-auto"
                              />
                            </a>
                            <div class="lablediv mt-2 text-center">
                              <p class="text-sm">Interior</p>
                            </div>
                          </div>
                          <!-- <div
                            class="bg-white shadow-mds p-3 sm:p-5 rounded-2xl relative h-100"
                          >
                          </div> -->
                        </div>
                      </SwiperSlide>
                    </Swiper>
                  </div>
                </div>
              </div>
              <div class="calcseccardsdiv mt-5">
                <div class="calcspace">
                  <div class="calccardtitle mb-3">
                    <h5 class="font-bold">Type of construction</h5>
                  </div>
                </div>
                <div class="toggledivcalspace">
                  <div class="mt-4 flex gap-4 items-center space-y-6">
                    <div class="flex items-center gap-x-3">
                      <input
                        id="roof-terrace"
                        name="construction-type"
                        type="radio"
                        checked
                        class="relative size-4 appearance-none rounded-full border border-gray-300 bg-white before:absolute before:inset-1 before:rounded-full before:bg-white not-checked:before:hidden checked:border-pink-600 checked:bg-pink-600 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-pink-600 disabled:border-gray-300 disabled:bg-gray-100 disabled:before:bg-gray-400 forced-colors:appearance-auto forced-colors:before:hidden"
                      />
                      <label
                        for="roof-terrace"
                        class="block text-sm/6 font-medium text-gray-900"
                        >Roof (Terrace)</label
                      >
                    </div>
                    <div
                      class="flex mt-0 items-center gap-x-3"
                      style="margin: 0"
                    >
                      <input
                        id="under-construction"
                        name="construction-type"
                        type="radio"
                        class="relative size-4 appearance-none rounded-full border border-gray-300 bg-white before:absolute before:inset-1 before:rounded-full before:bg-white not-checked:before:hidden checked:border-pink-600 checked:bg-pink-600 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-pink-600 disabled:border-gray-300 disabled:bg-gray-100 disabled:before:bg-gray-400 forced-colors:appearance-auto forced-colors:before:hidden"
                      />
                      <label
                        for="under-construction"
                        class="block text-sm/6 font-medium text-gray-900"
                        >Under Construction</label
                      >
                    </div>
                  </div>
                </div>
              </div>

              <div class="calcseccardsdiv mt-5">
                <div class="calcspace">
                  <div class="calccardtitle mb-3">
                    <h5 class="font-bold">Age of building</h5>
                  </div>
                </div>
                <div class="toggledivcalspace">
                  <div class="mt-4 flex gap-4 items-center space-y-6">
                    <div class="flex items-center gap-x-3">
                      <input
                        id="age-0-15"
                        name="building-age"
                        type="radio"
                        checked
                        class="relative size-4 appearance-none rounded-full border border-gray-300 bg-white before:absolute before:inset-1 before:rounded-full before:bg-white not-checked:before:hidden checked:border-pink-600 checked:bg-pink-600 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-pink-600 disabled:border-gray-300 disabled:bg-gray-100 disabled:before:bg-gray-400 forced-colors:appearance-auto forced-colors:before:hidden"
                      />
                      <label
                        for="age-0-15"
                        class="block text-sm/6 font-medium text-gray-900"
                        >0 - 15 Years</label
                      >
                    </div>
                    <div
                      class="flex mt-0 items-center gap-x-3"
                      style="margin: 0"
                    >
                      <input
                        id="age-15-plus"
                        name="building-age"
                        type="radio"
                        class="relative size-4 appearance-none rounded-full border border-gray-300 bg-white before:absolute before:inset-1 before:rounded-full before:bg-white not-checked:before:hidden checked:border-pink-600 checked:bg-pink-600 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-pink-600 disabled:border-gray-300 disabled:bg-gray-100 disabled:before:bg-gray-400 forced-colors:appearance-auto forced-colors:before:hidden"
                      />
                      <label
                        for="age-15-plus"
                        class="block text-sm/6 font-medium text-gray-900"
                        >15+ Years</label
                      >
                    </div>
                  </div>
                </div>
              </div>
              <div class="calcseccardsdiv mt-5">
                <div class="calcspace">
                  <div class="calccardtitle mb-3">
                    <h5 class="font-bold">Select roof surface made of</h5>
                  </div>
                  <div class="calccardspacemini">
                    <div
                      class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-4"
                    >
                      <div class="row-span-6">
                        <div class="calccardspacemini0">
                          <a
                            href=""
                            class="imgcalcdiv align-center bg-gray-300 flex justify-center p-4 rounded-md"
                          >
                            <img
                              src="assets/images/calculator/icn6.png"
                              alt="Interior Painting"
                              width=""
                              class="br-16 max-w-full h-auto"
                            />
                          </a>
                          <div class="lablediv mt-2 text-center">
                            <p class="text-sm">Clay tiles</p>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-6">
                        <div class="calccardspacemini0">
                          <a
                            href=""
                            class="imgcalcdiv align-center bg-gray-300 flex justify-center p-4 rounded-md"
                          >
                            <img
                              src="assets/images/calculator/icn5.png"
                              alt="Interior Painting"
                              width=""
                              class="br-16 max-w-full h-auto rounded"
                            />
                          </a>
                          <div class="lablediv mt-2 text-center">
                            <p class="text-sm">Tiles</p>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-6">
                        <div class="calccardspacemini0">
                          <a
                            href=""
                            class="imgcalcdiv align-center bg-gray-300 flex justify-center p-4 rounded-md"
                          >
                            <img
                              src="assets/images/calculator/icn8.png"
                              alt="Interior Painting"
                              width=""
                              class="br-16 max-w-full h-auto"
                            />
                          </a>
                          <div class="lablediv mt-2 text-center">
                            <p class="text-sm">Cement/Screed/IPS</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="calcseccardsdiv mt-5">
                <div class="calcspace">
                  <div class="calccardtitle mb-3">
                    <h5 class="font-bold">
                      Enter the area in sqft or dimension of the surface
                    </h5>
                  </div>
                </div>
                <div class="toggledivcalspace">
                  <div class="mt-4 flex gap-4 items-center space-y-6">
                    <div class="flex items-center gap-x-3">
                      <input
                        id="surface1"
                        name="surface"
                        type="radio"
                        checked
                        class="relative size-4 appearance-none rounded-full border border-gray-300 bg-white before:absolute before:inset-1 before:rounded-full before:bg-white not-checked:before:hidden checked:border-pink-600 checked:bg-pink-600 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-pink-600 disabled:border-gray-300 disabled:bg-gray-100 disabled:before:bg-gray-400 forced-colors:appearance-auto forced-colors:before:hidden"
                      />
                      <label
                        for="surface1"
                        class="block text-sm/6 font-medium text-gray-900"
                        >Dimension ( Length * Breadth )</label
                      >
                    </div>
                    <div
                      class="flex mt-0 items-center gap-x-3"
                      style="margin: 0"
                    >
                      <input
                        id="surface2"
                        name="surface"
                        type="radio"
                        class="relative size-4 appearance-none rounded-full border border-gray-300 bg-white before:absolute before:inset-1 before:rounded-full before:bg-white not-checked:before:hidden checked:border-pink-600 checked:bg-pink-600 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-pink-600 disabled:border-gray-300 disabled:bg-gray-100 disabled:before:bg-gray-400 forced-colors:appearance-auto forced-colors:before:hidden"
                      />
                      <label
                        for="surface2"
                        class="block text-sm/6 font-medium text-gray-900"
                        >Area in Sqft</label
                      >
                    </div>
                  </div>
                </div>
              </div>
              <div class="calcseccardsdiv mt-5">
                <div class="calcspace">
                  <div class="calccardspacemini">
                    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                      <div class="inptselectnumbdiv">
                        <div class="calccardtitle mb-3">
                          <h5 class="font-bold">Length</h5>
                        </div>
                        <div class="flex items-center space-x-2">
                          <input
                            type="number"
                            value="400"
                            class="w-full custsselect rounded-md p-3 text-sm"
                            min="0"
                            max="10000"
                            step="1"
                          />
                        </div>
                      </div>
                      <div class="inptselectnumbdiv">
                        <div class="calccardtitle mb-3">
                          <h5 class="font-bold">Breadth</h5>
                        </div>
                        <div class="flex items-center space-x-2">
                          <input
                            type="number"
                            value="400"
                            class="w-full custsselect rounded-md p-3 text-sm"
                            min="0"
                            max="10000"
                            step="1"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="calcseccardsdiv mt-5">
                <div class="calcspace">
                  <div class="calccardtitle mb-3">
                    <h5 class="font-bold">
                      Any waterproofing done on the roof earlier?
                    </h5>
                  </div>
                  <div class="calccardspacemini">
                    <div
                      class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-4"
                    >
                      <div class="row-span-6">
                        <div class="calccardspacemini0">
                          <a
                            href=""
                            class="imgcalcdiv align-center bg-gray-300 flex justify-center p-4 rounded-md"
                          >
                            <img
                              src="assets/images/calculator/ion9.png"
                              alt="Interior Painting"
                              width=""
                              class="br-16 max-w-full h-auto"
                            />
                          </a>
                          <div class="lablediv mt-2 text-center">
                            <p class="text-sm">No</p>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-6">
                        <div class="calccardspacemini0">
                          <a
                            href=""
                            class="imgcalcdiv align-center bg-gray-300 flex justify-center p-4 rounded-md"
                          >
                            <img
                              src="assets/images/calculator/ion10.png"
                              alt="Interior Painting"
                              width=""
                              class="br-16 max-w-full h-auto rounded"
                            />
                          </a>
                          <div class="lablediv mt-2 text-center">
                            <p class="text-sm">YES, Bitumen</p>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-6">
                        <div class="calccardspacemini0">
                          <a
                            href=""
                            class="imgcalcdiv align-center bg-gray-300 flex justify-center p-4 rounded-md"
                          >
                            <img
                              src="assets/images/calculator/ion11.png"
                              alt="Interior Painting"
                              width=""
                              class="br-16 max-w-full h-auto"
                            />
                          </a>
                          <div class="lablediv mt-2 text-center">
                            <p class="text-sm">YES, Coating</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="calcseccardsdiv mt-5">
                <div class="calcspace">
                  <div class="calccardtitle mb-3">
                    <h5 class="font-bold">
                      Any waterproofing done on the roof earlier?
                    </h5>
                  </div>
                  <div class="calccardspacemini">
                    <div
                      class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-4"
                    >
                      <div class="row-span-6">
                        <div class="calccardspacemini0">
                          <a
                            href=""
                            class="imgcalcdiv align-center bg-gray-300 flex justify-center p-4 rounded-md"
                          >
                            <img
                              src="assets/images/calculator/icn12.png"
                              alt="Interior Painting"
                              width=""
                              class="br-16 max-w-full h-auto"
                            />
                          </a>
                          <div class="lablediv mt-2 text-center">
                            <p class="text-sm">
                              No Cracks and Hollowness Observed
                            </p>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-6">
                        <div class="calccardspacemini0">
                          <a
                            href=""
                            class="imgcalcdiv align-center bg-gray-300 flex justify-center p-4 rounded-md"
                          >
                            <img
                              src="assets/images/calculator/icn13.png"
                              alt="Interior Painting"
                              width=""
                              class="br-16 max-w-full h-auto rounded"
                            />
                          </a>
                          <div class="lablediv mt-2 text-center">
                            <p class="text-sm">
                              Minor Cracks and Hollowness Observed
                            </p>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-6">
                        <div class="calccardspacemini0">
                          <a
                            href=""
                            class="imgcalcdiv align-center bg-gray-300 flex justify-center p-4 rounded-md"
                          >
                            <img
                              src="assets/images/calculator/icn14.png"
                              alt="Interior Painting"
                              width=""
                              class="br-16 max-w-full h-auto"
                            />
                          </a>
                          <div class="lablediv mt-2 text-center">
                            <p class="text-sm">
                              Major Cracks and Hollowness Observed
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="calcseccardsdiv mt-5">
                <div class="calcspace">
                  <div class="calccardtitle mb-3">
                    <h5 class="font-bold">
                      Any water logging or ponding observed on the roof?
                    </h5>
                  </div>
                </div>
                <div class="toggledivcalspace">
                  <div class="mt-4 flex gap-4 flex-col sm:flex-row items-start sm:items-center space-y-6">
                    <div class="flex items-center gap-x-3">
                      <input
                        id="obs1"
                        name="obs"
                        type="radio"
                        checked
                        class="relative size-4 appearance-none rounded-full border border-gray-300 bg-white before:absolute before:inset-1 before:rounded-full before:bg-white not-checked:before:hidden checked:border-pink-600 checked:bg-pink-600 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-pink-600 disabled:border-gray-300 disabled:bg-gray-100 disabled:before:bg-gray-400 forced-colors:appearance-auto forced-colors:before:hidden"
                      />
                      <label
                        for="obs1"
                        class="block text-sm/6 font-medium text-gray-900"
                        >No Water Logging</label
                      >
                    </div>
                    <div
                      class="flex mt-0 items-center gap-x-3"
                      style="margin: 0"
                    >
                      <input
                        id="obs2"
                        name="obs"
                        type="radio"
                        class="relative size-4 appearance-none rounded-full border border-gray-300 bg-white before:absolute before:inset-1 before:rounded-full before:bg-white not-checked:before:hidden checked:border-pink-600 checked:bg-pink-600 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-pink-600 disabled:border-gray-300 disabled:bg-gray-100 disabled:before:bg-gray-400 forced-colors:appearance-auto forced-colors:before:hidden"
                      />
                      <label
                        for="obs2"
                        class="block text-sm/6 font-medium text-gray-900"
                        >Severe Water Logging</label
                      >
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- nextpre -->
          <div class="w-full max-w-4xl mx-auto mt-9">
            <!-- Carousel Container -->
            <div class="relative">
              <!-- Carousel Items -->
              <div class="flex justify-between align-center">
                <div class="buttonsnextprev invisible">
                  <a
                    href=""
                    id="prevBtn"
                    class="bg-white text-gray-800 border rounded-full px-8 py-2 focus:outline-none hover:bg-gray-100"
                  >
                    Prev
                  </a>
                </div>
                <div
                  id="carousel"
                  class="flex items-center gap-2 transition-transform duration-300 ease-in-out"
                  style="transform: translateX(0)"
                >
                  <a
                    href="/water-proff1"
                    class="w-3 h-3 bg-pink-500 rounded-full focus:outline-none"
                    onclick="goToSlide(0)"
                  ></a>
                  <a
                    href="/water-proff2"
                    class="w-3 h-3 bg-gray-300 rounded-full focus:outline-none"
                    onclick="goToSlide(1)"
                  ></a>
                  <a
                    href="/water-proff3"
                    class="w-3 h-3 bg-gray-300 rounded-full focus:outline-none"
                    onclick="goToSlide(2)"
                  ></a>
                </div>
                <div class="buttonsnextprev">
                  <a
                    href="/water-proff2"
                    id="nextBtn"
                    class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                  >
                    Next
                  </a>
                </div>
              </div>
              <!-- Navigation Buttons -->
            </div>
          </div>
        </div>
      </div>
      <div class="max-w-6xl mx-auto">
        <div class="textcontentdiv mt-9">
          <h2 class="font-bold text-center">
            More About Home Exterior Painting
          </h2>
          <p class="text-sm text-gray-500 mt-3">
            But nevertheless, Exterior Painting is more really difficult as
            compared to what it looks. Which means that it happens to be with
            great pleasure that many Household painters make up your mind that
            it is now time to hire an Exterior Painting Services to seek the
            services of the job. Let us really know what painting Exterior
            Painting Company do, would you like to hire them? ... Tips sharing
            by ColourDrive.
          </p>
          <hr class="my-5" />
          <div class="text-sm text-gray-700 mt-3">
            <div class="calcseccardsdiv mt-5">
              <div class="calcspace">
                <div class="calccardtitle mb-3">
                  <h5 class="font-semibold">Standard Procedure:</h5>
                </div>
                <div class="calccardspacemini mb-2">
                  <div
                    class="grid grid-cols-2 sm:grid-cols-1 md:grid-cols-2 gap-4"
                  >
                    <div class="row-span-6 h-full">
                      <div
                        class="servccarddiv bg-white h-full flex gap-2 custshadow product-card rounded-md p-4"
                      >
                        <div class="imgcalcdiv rounded">
                          <img
                            src="assets/images/calculator/icon1.png"
                            alt="Interior Painting"
                            width=""
                            class="max-w-full h-auto"
                          />
                        </div>
                        <div class="lablediv">
                          <h6 class="font-bold pink-txt mb-2">
                            Exterior repainting procedure
                          </h6>
                          <p class="text-sm text-gray-500">
                            Exterior repainting procedure includes exterior wall
                            cleaning by jet machine, crack filling by Dr. Fixit
                            then one coat of exterior primer followed by two
                            coat of paint.
                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="row-span-6 h-full">
                      <div
                        class="servccarddiv h-full bg-white flex gap-2 custshadow product-card rounded-md p-4"
                      >
                        <div class="imgcalcdiv rounded">
                          <img
                            src="assets/images/calculator/icn15.png"
                            alt="Interior Painting"
                            width=""
                            class="max-w-full h-auto"
                          />
                        </div>
                        <div class="lablediv">
                          <h6 class="font-bold pink-txt mb-2">
                            Exterior fresh painting procedure
                          </h6>
                          <p class="text-sm text-gray-500">
                            Exterior fresh painting procedure includes one coat
                            of exterior primer and two coat of paint.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <hr class="my-5" />
          <h5 class="font-semibold">
            What Is Actually an Exterior Painting Services company?
          </h5>
          <p class="text-sm text-gray-500 mt-3">
            An Exterior Painting contractor can work as a sub-Exterior Paint
            Colours company, or sub-contractor, under a general Residential
            Exterior Painting contractor , or can retain the services of itself
            out directly to the owner of the house. For the most part, the
            painting contractor is a relatively smaller sized operation, ranging
            from the one-man exceptional proprietor up to 25 or 45 painters
            doing work for an insignificant company.
          </p>
          <hr class="my-5" />
          <h5 class="font-semibold">What Will ColourDrive Do?</h5>
          <p class="text-sm text-gray-500 mt-3">
            Virtually all painting contractors will take on any kind of
            profession, from merely painting you are your window trim to a
            full-house paint profession. But let us believe that they are
            painting them your exterior. You can actually usually expect to have
            from ColourDrive
          </p>
          <ul class="list-disc custom-list ps-6 mt-3">
            <li class="text-sm mb-1 text-gray-500">
              Coverage of all destinations that will be multi-colored, including
              floors, residential windows, kitchen space counters, storage
              units, etc.
            </li>
            <li class="text-sm mb-1 text-gray-500">
              Inconsequential surface getting prepared prior to repainting,
              which means illuminate sanding and scraping away do will manage to
              win paint, tapping in a few overhanging nails, cleaning off
              woodworking, with the use of sackcloth in some areas. The
              important thing here is “minor,” as the service provider will
              assume that the accommodate is mostly in Exterior Fresh Painting
              overall condition.
            </li>
            <li class="text-sm mb-1 text-gray-500">
              Reduction of electrical plates, equipment and lighting, doors, and
              other obstructions.
            </li>
            <li class="text-sm mb-1 text-gray-500">
              Moving accessories away for better access to the elements to be
              painted. This is such really a painter’s job, which means you
              would need to confirm this, in the beginning, such as Painting The
              Outside Of Your House. Priming new drywall or alternatively the
              current paint with an exterior latex primer.
            </li>
            <li class="text-sm mb-1 text-gray-500">
              Not one but two colour coats of exterior furnishing latex paint on
              the walls.
            </li>
            <li class="text-sm mb-1 text-gray-500">
              Two or three coats of ceiling paint. Painting on the trim and
              molding (baseboards, windowpane accessories, window mentions, etc
              .)
            </li>
            <li class="text-sm mb-1 text-gray-500">
              Touchups of greatly noticed spots.
            </li>
            <li class="text-sm mb-1 text-gray-500">
              Cleanups for unpleasant incidents ( no matter how good the payment
              or reimbursement with drop-cloths, a handful of drips will
              happen).
            </li>
            <li class="text-sm mb-1 text-gray-500">
              A final evaluation between Express Exterior Painting foreman and
              home-owner.
            </li>
          </ul>
          <hr class="my-5" />
          <h5 class="font-semibold">Our exterior house painting procedure</h5>
          <p class="text-sm text-gray-500 mt-3">
            Our first and fore mostly priority is to always make sure we don’t
            totally affect your day. During the time you book your painting on
            the job, our immediate down line will set up a get in touch with
            before your assignment date to go over all suggestions:
          </p>
          <ul class="list-disc custom-list ps-6 mt-3">
            <li class="text-sm mb-1 text-gray-500">
              Confirm demonstrate colour and suggestions,
            </li>
            <li class="text-sm mb-1 text-gray-500">
              Ask the prospective cardholder to move patio home furnishings and
              potted plants, and
            </li>
            <li class="text-sm mb-1 text-gray-500">
              Respond to the questions you have about your repainting project.
            </li>
          </ul>
          <p class="text-sm text-gray-500 mt-3">
            Check once our Free Exterior quotation for Per sqft rates for
            Exterior Painting, Dustless Exterior Painting and Exterior Fresh
            Painting, Just mark your requirement on support@colourdrive.in
          </p>
        </div>
        <div class="calccardspacemini sliderdiv text1 pt-100">
          <h2 class="text-center font-bold mb-5">
            Best Interior Paint Products
          </h2>
          <Swiper
            class="catalogue"
            :slides-per-view="1"
            :loop="true"
            :breakpoints="{
              640: { slidesPerView: 1 },
              768: { slidesPerView: 1 },
              1024: { slidesPerView: 1 },
            }"
            :modules="[SwiperAutoplay, SwiperEffectCreative, SwiperNavigation]"
            :autoplay="{
              delay: 3000,
              disableOnInteraction: true,
            }"
            :pauseAutoplayOnMouseEnter="true"
            :navigation="true"
            :pagination="{
              clickable: true,
            }"
          >
            <SwiperSlide class="h-100">
              <div class="m-4 bg-pink rounded-2xl text-center p-4 h-100">
                <div class="calccardspacemini00 flex gap-3">
                  <div
                    href=""
                    class="imgcalcdiv bg-white align-center flex justify-center basis-1/3 items-center p-4 rounded-md"
                  >
                    <img
                      src="assets/images/calculator/paintbucket.png"
                      alt="Interior Painting"
                      width=""
                      class="br-16 max-w-full h-auto"
                    />
                  </div>
                  <div class="lablediv content-center">
                    <p class="text-md text-white text-start">
                      Apcolite Premium Emulsion gives matt and satin finish to
                      your walls. It works on all wall conditions. Apcolite
                      Premium Emulsion is having anti fungus qualities. Apcolite
                      Premium Emulsion is type of Interior Paints which contains
                      long lasting film due to that your house looks new for
                      long time. It is semi washable. Apcolite Premium Emulsion
                      contains special stainguard technology that keeps your
                      walls stain free.
                    </p>
                  </div>
                </div>
                <!-- <div
                                      class="bg-white shadow-mds p-3 sm:p-5 rounded-2xl relative h-100"
                                    >
                                    </div> -->
              </div>
            </SwiperSlide>
            <SwiperSlide class="h-100">
              <div class="m-4 bg-pink rounded-2xl text-center p-4 h-100">
                <div class="calccardspacemini00 flex gap-3">
                  <div
                    href=""
                    class="imgcalcdiv bg-white align-center flex justify-center basis-1/3 items-center p-4 rounded-md"
                  >
                    <img
                      src="assets/images/calculator/paintbucket.png"
                      alt="Interior Painting"
                      width=""
                      class="br-16 max-w-full h-auto"
                    />
                  </div>
                  <div class="lablediv content-center">
                    <p class="text-md text-white text-start">
                      Apcolite Premium Emulsion gives matt and satin finish to
                      your walls. It works on all wall conditions. Apcolite
                      Premium Emulsion is having anti fungus qualities. Apcolite
                      Premium Emulsion is type of Interior Paints which contains
                      long lasting film due to that your house looks new for
                      long time. It is semi washable. Apcolite Premium Emulsion
                      contains special stainguard technology that keeps your
                      walls stain free.
                    </p>
                  </div>
                </div>
                <!-- <div
                                      class="bg-white shadow-mds p-3 sm:p-5 rounded-2xl relative h-100"
                                    >
                                    </div> -->
              </div>
            </SwiperSlide>
            <SwiperSlide class="h-100">
              <div class="m-4 bg-pink rounded-2xl text-center p-4 h-100">
                <div class="calccardspacemini00 flex gap-3">
                  <div
                    href=""
                    class="imgcalcdiv bg-white align-center flex justify-center basis-1/3 items-center p-4 rounded-md"
                  >
                    <img
                      src="assets/images/calculator/paintbucket.png"
                      alt="Interior Painting"
                      width=""
                      class="br-16 max-w-full h-auto"
                    />
                  </div>
                  <div class="lablediv content-center">
                    <p class="text-md text-white text-start">
                      Apcolite Premium Emulsion gives matt and satin finish to
                      your walls. It works on all wall conditions. Apcolite
                      Premium Emulsion is having anti fungus qualities. Apcolite
                      Premium Emulsion is type of Interior Paints which contains
                      long lasting film due to that your house looks new for
                      long time. It is semi washable. Apcolite Premium Emulsion
                      contains special stainguard technology that keeps your
                      walls stain free.
                    </p>
                  </div>
                </div>
                <!-- <div
                                      class="bg-white shadow-mds p-3 sm:p-5 rounded-2xl relative h-100"
                                    >
                                    </div> -->
              </div>
            </SwiperSlide>
          </Swiper>
        </div>
        <section id="faq" class="px-4 pt-100">
          <div class="container mx-auto">
            <h2 class="text-center font-bold mb-5">FAQs</h2>
            <div class="accordion flex flex-col items-center justify-center">
              <!--  Panel 1  -->
              <div class="w-full lg:w-1/2 shadow11 mb-4">
                <input
                  type="checkbox"
                  name="panel"
                  id="panel-1"
                  class="hidden"
                />
                <label
                  for="panel-1"
                  class="relative block bg-white text-black p-4 rounded-2xl"
                  >Questions text goes here</label
                >
                <div class="accordion__content overflow-hidden">
                  <p class="accordion__body p-4 text-black" id="panel1">
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a
                    type specimen.
                  </p>
                </div>
              </div>
              <!--  Panel 2  -->
              <div class="w-full lg:w-1/2 shadow11 mb-4">
                <input
                  type="checkbox"
                  name="panel"
                  id="panel-2"
                  class="hidden"
                />
                <label
                  for="panel-2"
                  class="relative block bg-white text-black p-4 rounded-2xl"
                  >Questions text goes here</label
                >
                <div class="accordion__content overflow-hidden">
                  <p class="accordion__body p-4 text-black" id="panel1">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Iusto possimus at a cum saepe molestias modi illo facere
                    ducimus voluptatibus praesentium deleniti fugiat ab error
                    quia sit perspiciatis velit necessitatibus.Lorem ipsum dolor
                    sit amet, consectetur adipisicing elit. Lorem ipsum dolor
                    sit amet.
                  </p>
                </div>
              </div>
              <!--  Panel 3  -->
              <div class="w-full lg:w-1/2 shadow11 mb-4">
                <input
                  type="checkbox"
                  name="panel"
                  id="panel-3"
                  class="hidden"
                />
                <label
                  for="panel-3"
                  class="relative block bg-white text-black p-4 rounded-2xl"
                  >Questions text goes here</label
                >
                <div class="accordion__content overflow-hidden">
                  <p class="accordion__body p-4 text-black" id="panel1">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Iusto possimus at a cum saepe molestias modi illo facere
                    ducimus voluptatibus praesentium deleniti fugiat ab error
                    quia sit perspiciatis velit necessitatibus.Lorem ipsum dolor
                    sit amet, consectetur adipisicing elit. Lorem ipsum dolor
                    sit amet.
                  </p>
                </div>
              </div>
              <!--  Panel 4  -->
              <div class="w-full lg:w-1/2 shadow11 mb-4">
                <input
                  type="checkbox"
                  name="panel"
                  id="panel-4"
                  class="hidden"
                />
                <label
                  for="panel-4"
                  class="relative block bg-white text-black p-4 rounded-2xl"
                  >Questions text goes here</label
                >
                <div class="accordion__content overflow-hidden">
                  <p class="accordion__body p-4 text-black" id="panel1">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Iusto possimus at a cum saepe molestias modi illo facere
                    ducimus voluptatibus praesentium deleniti fugiat ab error
                    quia sit perspiciatis velit necessitatibus.Lorem ipsum dolor
                    sit amet, consectetur adipisicing elit. Lorem ipsum dolor
                    sit amet.
                  </p>
                </div>
              </div>
              <!--  Panel 5  -->
              <div class="w-full lg:w-1/2 shadow11 mb-4">
                <input
                  type="checkbox"
                  name="panel"
                  id="panel-5"
                  class="hidden"
                />
                <label
                  for="panel-5"
                  class="relative block bg-white text-black p-4 rounded-2xl"
                  >Questions text goes here</label
                >
                <div class="accordion__content overflow-hidden">
                  <p class="accordion__body p-4 text-black" id="panel1">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Iusto possimus at a cum saepe molestias modi illo facere
                    ducimus voluptatibus praesentium deleniti fugiat ab error
                    quia sit perspiciatis velit necessitatibus.Lorem ipsum dolor
                    sit amet, consectetur adipisicing elit. Lorem ipsum dolor
                    sit amet.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </section>
  <!-- service Post section end -->
</template>

<style scoped>
@import "../assets/css/service.css";
</style>
