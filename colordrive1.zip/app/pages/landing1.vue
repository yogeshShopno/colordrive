<script>
//add javascript of this template only
</script>

<template>
<div>

    <!-- slider start -->
    <section id="main-hero" class="px-4">
        <div class="container flex flex-col lg:flex-row mx-auto items-end">

            <div class="w-full lg:w-7/12 xl:w-7/12 py-100">
                <div class="border p-5 border-black rounded-2xl">
                    <h3>What are you looking for?</h3>
                    <div class="mt-4">
                        <div class="grid gap-x-8 gap-y-4 grid-cols-2 md:grid-cols-4">
                            <div>
                                <a href="/calculator">
                                    <div class="box1 justify-center flex rounded-2xl py-3 items-center shadow-none transition-shadow duration-300 cursor-pointer hover:shadow-lg hover:shadow-pink-2"></div>
                                    <h5 class="text-center mt-2">Interior Painting </h5>
                                </a>
                            </div>
                            <div>
                                <a href="/exterior-cal1">
                                    <div class="box2 justify-center flex rounded-2xl py-3 items-center shadow-none transition-shadow duration-300 cursor-pointer hover:shadow-lg hover:shadow-pink-2">
                                        <img src="assets/images/Exterior Painting.svg" alt="Exterior Painting" />
                                    </div>
                                    <h5 class="text-center mt-2">Exterior Painting</h5>
                                </a>
                            </div>
                            <div>
                                <a href="">
                                    <div class="box2 justify-center flex rounded-2xl py-3 items-center shadow-none transition-shadow duration-300 cursor-pointer hover:shadow-lg hover:shadow-pink-2">
                                        <img src="assets/images/Wall Design Painting.svg" alt="Wall Design Painting" />
                                    </div>
                                    <h5 class="text-center mt-2">Wall Design Painting</h5>
                                </a>
                            </div>
                            <div>
                                <a href="/water-proff1">
                                    <div class="box2 justify-center flex rounded-2xl py-3 items-center shadow-none transition-shadow duration-300 cursor-pointer hover:shadow-lg hover:shadow-pink-2">
                                        <img src="assets/images/Waterproofing Solutions.svg" alt="Waterproofing Solutions" />
                                    </div>
                                    <h5 class="text-center mt-2">Waterproofing Solutions</h5>
                                </a>
                            </div>
                        </div>
                        <div class="grid gap-x-8 gap-y-4 grid-cols-2 md:grid-cols-4 mt-5">
                            <div>
                                <a href="">
                                    <div class="box2 justify-center flex rounded-2xl py-3 items-center shadow-none transition-shadow duration-300 cursor-pointer hover:shadow-lg hover:shadow-pink-2">
                                        <img alt="Fasle Ceiling Designs" src="assets/images/Rental Painting.svg" />
                                    </div>
                                    <h5 class="text-center mt-2">Fasle Ceiling Designs</h5>
                                </a>
                            </div>
                            <div>
                                <a href="">
                                    <div class="box2 justify-center flex rounded-2xl py-3 items-center shadow-none transition-shadow duration-300 cursor-pointer hover:shadow-lg hover:shadow-pink-2">
                                        <img src="assets/images/Fasle Ceiling Designs.svg" alt="House Wallpaper" />
                                    </div>
                                    <h5 class="text-center mt-2">House Wallpaper</h5>
                                </a>
                            </div>
                            <div>
                                <a href="">
                                    <div class="box2 justify-center flex rounded-2xl py-3 items-center shadow-none transition-shadow duration-300 cursor-pointer hover:shadow-lg hover:shadow-gray-200">
                                        <img src="assets/images/House Wallpaper.svg" alt="Fasle Ceiling Designs" />
                                    </div>
                                    <h5 class="text-center mt-2">Fasle Ceiling Designs</h5>
                                </a>
                            </div>
                            <div class="more-services">
                                <a href="">
                                    <div class="box2 justify-center flex rounded-2xl py-3 items-center shadow-none transition-shadow duration-300 cursor-pointer hover:shadow-lg hover:shadow-pink-2">
                                        <h5 class="text-center">More Services</h5>
                                    </div>
                                </a>
                            </div>

                            <div class="service-new hidden">
                                <a href="/calculator">
                                    <div class="box1 justify-center flex rounded-2xl py-3 items-center shadow-none transition-shadow duration-300 cursor-pointer hover:shadow-lg hover:shadow-pink-2"></div>
                                    <h5 class="text-center mt-2">Interior Painting</h5>
                                </a>
                            </div>
                            <div class="service-new hidden">
                                <a href="/exterior-cal1">
                                    <div class="box2 justify-center flex rounded-2xl py-3 items-center shadow-none transition-shadow duration-300 cursor-pointer hover:shadow-lg hover:shadow-pink-2">
                                        <img src="assets/images/Exterior Painting.svg" alt="Exterior Painting" />
                                    </div>
                                    <h5 class="text-center mt-2">Exterior Painting</h5>
                                </a>
                            </div>
                            <div class="service-new hidden">
                                <a href="">
                                    <div class="box2 justify-center flex rounded-2xl py-3 items-center shadow-none transition-shadow duration-300 cursor-pointer hover:shadow-lg hover:shadow-pink-2">
                                        <img src="assets/images/Wall Design Painting.svg" alt="Wall Design Painting" />
                                    </div>
                                    <h5 class="text-center mt-2">Wall Design Painting</h5>
                                </a>
                            </div>
                            <div class="service-new hidden">
                                <a href="/water-proff1">
                                    <div class="box2 justify-center flex rounded-2xl py-3 items-center shadow-none transition-shadow duration-300 cursor-pointer hover:shadow-lg hover:shadow-pink-2">
                                        <img src="assets/images/Waterproofing Solutions.svg" alt="Waterproofing Solutions" />
                                    </div>
                                    <h5 class="text-center mt-2">Waterproofing Solutions</h5>
                                </a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="mt-10 text-center sm:text-start">
                    <h2>Looking For </h2>
                    <h1 class="font-bold">Home Renovation</h1>
                </div>
                <div class="mt-4">
                    <div class="grid gap-x-8 gap-y-4 sm:grid-cols-2 md:grid-cols-3">
                        <div class="flex items-center">
                            <img src="assets/images/google.svg" alt="google" />
                            <div class="ms-3">
                                <h4>4.8</h4>
                                <p>Google Rating</p>
                            </div>
                        </div>
                        <div class="flex items-center">
                            <img src="assets/images/warranty.svg" alt="google" />
                            <div class="ms-3">
                                <h4>2 Year</h4>
                                <p>Warranty</p>
                            </div>
                        </div>
                        <div class="flex items-center">
                            <img src="assets/images/home_nicely_painted.svg" alt="google" />
                            <div class="ms-3">
                                <h4 id="home-painted-count">0</h4>
                                <p>Homes Nicely Painted</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="w-full lg:w-5/12 xl:w-5/12 justify-center flex relative mt-6 lg:mt-0">
                <div class="absolute" id="inquire">
                    <h1>ENQUIRE NOW</h1>
                </div>
                <div class="p-5 bg-white rounded-tlb lg:w-10/12 xl:w-8/12">
                    <!-- success message -->
                    <div class="flex items-center message-form  justify-center rounded-lg p-2">
                        <img src="assets/images/right.svg" alt="right">
                        <h4 class="ms-2">Your form has been submitted.</h4>
                    </div>
                    <!-- success message -->
                    <!-- error message -->
                    <div class="flex items-center error-message mt-5 justify-center rounded-lg p-2 mb-3">
                        <img src="assets/images/close.svg" alt="right">
                        <h4 class="ms-2">Unable to Submit form</h4>
                    </div>
                    <!-- error message -->
                    <h6 class="font-semibold text-xl">
                        Create your dream home with our painting experts
                    </h6>
                    <p class="my-3 text-gray-200 text-sm">
                        Fill the form below to book a free site evaluation by a Beautiful
                        Homes Painting Service expert.
                    </p>
                    <div>
                        <form id="enquiryForm">
                            <div class="sm:flex sm:flex-wrap">
                                <div class="mb-5 sm:w-1/2 px-1">
                                    <label for="fname" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                        Name</label>
                                    <input type="text" id="fname" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Name" required />
                                </div>
                                <div class="mb-5 sm:w-1/2 px-1">
                                    <label for="email" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                        Email</label>
                                    <input type="email" id="email" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Email" required />
                                </div>
                                <div class="mb-5 w-full">
                                    <label for="phone-input" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Mobile</label>
                                    <input type="text" id="phone-input" aria-describedby="helper-text-explanation" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Mobile" required />
                                </div>
                                <div class="mb-5 w-full">
                                    <label for="default" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Select City</label>
                                    <select id="default" class="z-10 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                        <option selected>Select City</option>
                                        <option value="US">United States</option>
                                        <option value="CA">Canada</option>
                                        <option value="FR">France</option>
                                        <option value="DE">Germany</option>
                                    </select>
                                </div>
                                <div class="mb-5 w-full">
                                    <label for="default" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Service customer
                                    </label>
                                    <select id="default" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                        <option selected>Choose a Services</option>
                                        <option value="US">Interior Painting</option>
                                        <option value="CA">Exterior Painting</option>
                                        <option value="FR">Wall Design Painting</option>
                                        <option value="DE">Waterproofing Solutions</option>
                                        <option value="DE">Rental Painting</option>
                                        <option value="DE">Fasle Ceiling Designs</option>
                                        <option value="DE">House Wallpaper</option>
                                    </select>
                                </div>
                            </div>
                            <div class="flex items-start mb-5">
                                <div class="flex items-center h-5">
                                    <input id="remember" type="checkbox" value="" class="w-4 h-4 border border-gray-300 rounded bg-gray-50 focus:ring-3 focus:ring-blue-300 dark:bg-gray-700 dark:border-gray-600 dark:focus:ring-blue-600 dark:ring-offset-gray-800 dark:focus:ring-offset-gray-800" required />
                                </div>
                                <label for="remember" class="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300">T&C and Privacy Policy</label>
                            </div>
                            <button type="submit" class="text-white main-btn font-medium rounded-lg text-sm w-full px-5 py-2.5 text-center before:ease relative overflow-hidden transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40">
                                <span relative="relative z-10">Book Enquiry</span>
                            </button>

                        </form>

                        <!-- Success and error messages -->
                        <!-- <div id="message" class="mt-4 hidden text-center"></div> -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- slider end -->

    <!-- Testimonials start -->
    <section id="testimonials " class="py-100 z-0">
        <div class="container mx-auto">
            <h2 class="text-center font-bold mb-4">Testimonials</h2>

            <Swiper class="text1" :slides-per-view="1" :loop="true" :breakpoints="{
            640: { slidesPerView: 1 },
            768: { slidesPerView: 2 },
            1024: { slidesPerView: 3 },
          }" :modules="[SwiperAutoplay, SwiperEffectCreative, SwiperNavigation]" :autoplay="{
            delay: 3000,
            disableOnInteraction: true,
          }" :pauseAutoplayOnMouseEnter="true" :navigation="true">
                <SwiperSlide class="h-100">
                    <div class="m-3 text-center pt-7 h-100">
                        <div class="bg-white shadow-mds p-5 rounded-2xl relative h-100">
                            <div class="flex justify-center absolute review1">
                                <!-- <img src="assets/images/Review1.webp" alt="Review1" class="w-22" /> -->
                                <div class="review-content">
                                    R
                                </div>
                            </div>
                            <div class="mt-7">
                                <h5 class="font-semibold text-xl mb-1">Raman Mohan</h5>
                                <p class="text-gray">September 20, 2024</p>
                                <div class="flex justify-center">
                                    <img src="assets/images/stars.svg" alt="stars" class="my-4 star" />
                                </div>
                                <p class="review-txt">
                                    I could not find anything that would limit my rating of
                                    their work to four stars. This was our fourth experience
                                    with them. Their workmen are experts in their job. They
                                    won’t settle for the second best in whatever you choose for
                                    your home painting. Great job. Thanks team AapkaPainter.com.
                                    Good luck!
                                </p>
                            </div>
                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide class="h-100">
                    <div class="m-3 text-center pt-7 h-100">
                        <div class="bg-white shadow-mds p-5 rounded-2xl relative h-100">
                            <div class="flex justify-center absolute review1">
                                <!-- <img src="assets/images/Review2.webp" alt="Review1" class="w-22" /> -->
                                <div class="review-content">
                                    A
                                </div>
                            </div>
                            <div class="mt-7">
                                <h5 class="font-semibold text-xl mb-1">Adil Khan</h5>
                                <p class="text-gray">September 20, 2024</p>
                                <div class="flex justify-center">
                                    <img src="assets/images/stars.svg" alt="stars" class="my-4 star" />
                                </div>
                                <p class="review-txt">
                                    Smooth services given by apka painter team, great work by Mr
                                    Shishir project manager and Mr Veerpal who has taken care
                                    the work smoothly within given timeframe. They are happy to
                                    give any further help post completion of work. Highly
                                    recommended.
                                </p>
                            </div>
                        </div>
                    </div>
                </SwiperSlide>

                <SwiperSlide class="h-100">
                    <div class="m-3 text-center pt-7 h-100">
                        <div class="bg-white shadow-mds p-5 rounded-2xl relative h-100">
                            <div class="flex justify-center absolute review1">
                                <!-- <img src="assets/images/Review3.webp" alt="Review1" class="w-22" /> -->
                                <div class="review-content">
                                    G
                                </div>
                            </div>
                            <div class="mt-7">
                                <h5 class="font-semibold text-xl mb-1">
                                    Gurusubrahmaniyan Sri
                                </h5>
                                <p class="text-gray">September 20, 2024</p>
                                <div class="flex justify-center">
                                    <img src="assets/images/stars.svg" alt="stars" class="my-4 star" />
                                </div>
                                <p class="review-txt">
                                    Overall verygood work. The site supervisor Mr. Ranjit is
                                    very kind and accomotative. Well done and please do get the
                                    job thro them as they are sincere and does their work to the
                                    full satisfaction of the customer.
                                </p>
                            </div>
                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide class="h-100">
                    <div class="m-3 text-center pt-7 h-100">
                        <div class="bg-white shadow-mds p-5 rounded-2xl relative h-100">
                            <div class="flex justify-center absolute review1">
                                <!-- <img src="assets/images/Review2.webp" alt="Review1" class="w-22" /> -->
                                <div class="review-content">
                                    A
                                </div>
                            </div>
                            <div class="mt-7">
                                <h5 class="font-semibold text-xl mb-1">Adil Khan</h5>
                                <p class="text-gray">September 20, 2024</p>
                                <div class="flex justify-center">
                                    <img src="assets/images/stars.svg" alt="stars" class="my-4 star" />
                                </div>
                                <p class="review-txt">
                                    Smooth services given by apka painter team, great work by Mr
                                    Shishir project manager and Mr Veerpal who has taken care
                                    the work smoothly within given timeframe. They are happy to
                                    give any further help post completion of work. Highly
                                    recommended.
                                </p>
                            </div>
                        </div>
                    </div>
                </SwiperSlide>
            </Swiper>
        </div>
    </section>
    <!-- Testimonials end -->

    <!-- Quick links start -->
    <section class="px-4" id="quick-link">
        <div class="container mx-auto">
            <h2 class="text-center font-bold mb-4">Quick links</h2>
            <div class="grid gap-x-8 gap-y-4 sm:grid-cols-2 md:grid-cols-3">
                <div class="flex items-center bg-light rounded-2xl">
                    <img src="assets/images/Calculate Price.webp" alt="Calculate Price" class="br-2xl" />
                    <div class="ms-3">
                        <li><a href="/calculator">calculator</a>
                            <h4>Calculate Price</h4></li>
                  
                        <!-- <p> Google Rating </p> -->
                    </div>
                </div>
                <div class="flex items-center bg-light rounded-2xl">
                    <img src="assets/images/Colour Consultancy.webp" alt="Colour Consultancy" class="br-2xl" />
                    <div class="ms-3">
                        <h4>Colour Consultancy</h4>
                        <!-- <p> Google Rating </p> -->
                    </div>
                </div>
                <div class="flex items-center bg-light rounded-2xl">
                    <img src="assets/images/Explore design ideas.webp" alt="Explore design ideas" class="br-2xl" />
                    <div class="ms-3">
                        <h4>Explore design ideas</h4>
                        <!-- <p> Google Rating </p> -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Quick links end -->

    <!-- Catalogue Design start -->
    <section class="py-100 px-4" id="gallery">
        <div class="container mx-auto">
            <h2 class="text-center font-bold mb-4">Catalogue Design</h2>
            <Swiper class="catalogue" :slides-per-view="1" :loop="true" :breakpoints="{
            640: { slidesPerView: 1 },
            768: { slidesPerView: 2 },
            1024: { slidesPerView: 4 },
          }" :space-between="30" :modules="[SwiperAutoplay, SwiperEffectCreative, SwiperNavigation]" :autoplay="{
            delay: 5000,
            disableOnInteraction: true,
          }" :pauseAutoplayOnMouseEnter="true" :navigation="true" :pagination="{
            clickable: true,
          }">
                <SwiperSlide class="h-100">
                    <div class="relative">
                        <div class="w-full relative mx-auto h-auto overflow-hidden br-20">
                            <img src="assets/images/gallery1.webp" alt="Wall Texture Gallery" class="gallery-img transition-all duration-300 hover:scale-110 relative" width="100%" />
                        </div>
                        <div class="bg-gallery p-4 sm:p-2 lg:p-4 absolute w-full text-center text-white text-xl">
                            <h4>Wall Texture Gallery</h4>
                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide class="h-100">
                    <div class="relative">
                        <div class="w-full relative mx-auto h-auto overflow-hidden br-20">
                            <img src="assets/images/gallery2.webp" alt="Stencil Designs" class="gallery-img transition-all duration-300 hover:scale-110 relative" width="100%" />
                        </div>
                        <div class="bg-gallery p-4 sm:p-2 lg:p-4 absolute w-full text-center text-white text-xl">
                            <h4>Stencil Designs</h4>
                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide class="h-100">
                    <div class="relative">
                        <div class="w-full relative mx-auto h-auto overflow-hidden br-20">
                            <img src="assets/images/gallery3.webp" alt="Interior Painting" class="gallery-img transition-all duration-300 hover:scale-110 relative" width="100%" />
                        </div>
                        <div class="bg-gallery p-4 sm:p-2 lg:p-4 absolute w-full text-center text-white text-xl">
                            <h4>Interior Painting</h4>
                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide class="h-100">
                    <div class="relative">
                        <div class="w-full relative mx-auto h-auto overflow-hidden br-20">
                            <img src="assets/images/gallery4.webp" alt="Exterior Painting" class="gallery-img transition-all duration-300 hover:scale-110 relative" width="100%" />
                        </div>
                        <div class="bg-gallery p-4 sm:p-2 lg:p-4 absolute w-full text-center text-white text-xl">
                            <h4>Exterior Painting</h4>
                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide class="h-100">
                    <div class="relative">
                        <div class="w-full relative mx-auto h-auto overflow-hidden br-20">
                            <img src="assets/images/gallery1.webp" alt="Wall Texture Gallery" class="gallery-img transition-all duration-300 hover:scale-110 relative" width="100%" />
                        </div>
                        <div class="bg-gallery p-4 sm:p-2 lg:p-4 absolute w-full text-center text-white text-xl">
                            <h4>Wall Texture Gallery</h4>
                        </div>
                    </div>
                </SwiperSlide>
            </Swiper>
        </div>
    </section>
    <!-- Catalogue Design end -->

    <!-- How We Work Start -->
    <section id="work" class="px-4 hidden sm:block">
        <div class="container mx-auto">
            <h2 class="text-center font-bold mb-4">How We Work?</h2>
            <div class="grid gap-x-8 gap-y-4 sm:grid-cols-3 md:grid-cols-6">
                <div>
                    <div class="flex justify-center relative">
                        <img src="assets/images/work1.svg" alt="gallery1" class="work1" />
                        <img src="assets/images/arrow.svg" alt="arrow" class="arrow" />
                    </div>
                    <div class="pt-3 w-full text-center text-xl">
                        <h4>Booking</h4>
                    </div>
                </div>
                <div>
                    <div class="flex justify-center relative">
                        <img src="assets/images/work2.svg" alt="gallery1" class="work1" />
                        <img src="assets/images/arrow.svg" alt="arrow" class="arrow arrow2" />
                    </div>
                    <div class="pt-3 w-full text-center text-xl">
                        <h4>Mesurement</h4>
                    </div>
                </div>
                <div>
                    <div class="flex justify-center relative">
                        <img src="assets/images/work3.svg" alt="gallery1" class="work1" />
                        <img src="assets/images/arrow.svg" alt="arrow" class="arrow d-none" />
                    </div>
                    <div class="pt-3 w-full text-center text-xl">
                        <h4>Product Selection</h4>
                    </div>
                </div>
                <div>
                    <div class="flex justify-center relative">
                        <img src="assets/images/work4.svg" alt="gallery1" class="work1" />
                        <img src="assets/images/arrow.svg" alt="arrow" class="arrow arrow4" />
                    </div>
                    <div class="pt-3 w-full text-center text-xl">
                        <h4>Cost Estimation</h4>
                    </div>
                </div>
                <div>
                    <div class="flex justify-center relative">
                        <img src="assets/images/work5.svg" alt="gallery1" class="work1" />
                        <img src="assets/images/arrow.svg" alt="arrow" class="arrow" />
                    </div>
                    <div class="pt-3 w-full text-center text-xl">
                        <h4>Work Completion</h4>
                    </div>
                </div>
                <div>
                    <div class="flex justify-center relative">
                        <img src="assets/images/work6.svg" alt="gallery1" class="work1" />
                    </div>
                    <div class="pt-3 w-full text-center text-xl">
                        <h4>Customer Satisfaction</h4>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="work" class="px-4  sm:hidden">
        <div class="container mx-auto">
            <h2 class="text-center font-bold mb-4">How We Work?</h2>
            <div class="grid gap-x-8 gap-y-4 sm:grid-cols-3 md:grid-cols-6">
                <div>
                    <div class="flex justify-center ">
                        <img src="assets/images/work1.svg" alt="gallery1" class="work1" />
                    </div>
                    <div class="pt-3 w-full text-center text-xl">
                        <h4>Booking</h4>
                    </div>
                </div>
                <div class="flex justify-center">

                    <img src="assets/images/arrow-mb.svg" alt="gallery1" width="5%" />
                </div>
                <div>
                    <div class="flex justify-center ">
                        <img src="assets/images/work2.svg" alt="gallery1" class="work1" />

                    </div>
                    <div class="pt-3 w-full text-center text-xl">
                        <h4>Mesurement</h4>
                    </div>
                </div>
                <div class="flex justify-center">

                    <img src="assets/images/arrow-mb.svg" alt="gallery1" width="5%" />
                </div>

                <div>
                    <div class="flex justify-center">
                        <img src="assets/images/work3.svg" alt="gallery1" class="work1" />

                    </div>
                    <div class="pt-3 w-full text-center text-xl">
                        <h4>Product Selection</h4>
                    </div>
                </div>
                <div class="flex justify-center">

                    <img src="assets/images/arrow-mb.svg" alt="gallery1" width="5%" />
                </div>
                <div>
                    <div class="flex justify-center">
                        <img src="assets/images/work4.svg" alt="gallery1" class="work1" />

                    </div>
                    <div class="pt-3 w-full text-center text-xl">
                        <h4>Cost Estimation</h4>
                    </div>
                </div>
                <div class="flex justify-center">

                    <img src="assets/images/arrow-mb.svg" alt="gallery1" width="5%" />
                </div>
                <div>
                    <div class="flex justify-center">
                        <img src="assets/images/work5.svg" alt="gallery1" class="work1" />
                    </div>
                    <div class="pt-3 w-full text-center text-xl">
                        <h4>Work Completion</h4>
                    </div>
                </div>
                <div class="flex justify-center">

                    <img src="assets/images/arrow-mb.svg" alt="gallery1" width="5%" />
                </div>
                <div>
                    <div class="flex justify-center">
                        <img src="assets/images/work6.svg" alt="gallery1" class="work1" />
                    </div>
                    <div class="pt-3 w-full text-center text-xl">
                        <h4>Customer Satisfaction</h4>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- How We Work end -->

    <!-- Colour Drive Assurance Shields start -->
    <section id="assurance" class="py-100 px-4">
        <div class="container mx-auto">
            <h2 class="text-center font-bold mb-4">
                Colour Drive Assurance Shields
            </h2>
            <div class="grid gap-x-8 gap-y-4 sm:grid-cols-2 md:grid-cols-3">
                <div class="relative">
                    <img src="assets/images/assurance1.webp" alt="assurance1" class="assurance-img" />
                    <div class="bg-assurance p-2 lg:p-4 absolute w-full text-center text-white text-xl">
                        <h4>Before Painting and After Painting</h4>
                    </div>
                </div>
                <div class="relative">
                    <img src="assets/images/assurance2.webp" alt="assurance1" class="assurance-img" />
                    <div class="bg-assurance p-2 lg:p-4 absolute w-full text-center text-white text-xl">
                        <h4>Before Waterproofing and After Waterproofing</h4>
                    </div>
                </div>
                <div class="relative">
                    <img src="assets/images/assurance3.webp" alt="assurance1" class="assurance-img" />
                    <div class="bg-assurance p-2 lg:p-4 absolute w-full text-center text-white text-xl">
                        <h4>
                            Before Normal Painting and After Design Painting on one wall
                        </h4>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Colour Drive Assurance Shields  end-->

    <!-- Home Design Inspiration Gallery -->
    <section id="inspiration-img" class="px-4">
        <div class="container mx-auto relative">
            <div class="gallery-design">
                <div class="absolute design-inspiration">
                    <h2 class="text-center font-bold">
                        Home Design Inspiration Gallery
                    </h2>
                    <p class="text-center mb-4">
                        Give your home a new look with these interior design ideas curated
                        for you
                    </p>
                </div>

                <div class="flex items-center gap-4">
                    <div class="w-5/12">
                        <div class="flex items-end gap-4 mb-4">
                            <div class="w-5/12 relative">
                                <div class="w-full relative mx-auto h-auto overflow-hidden br-20">
                                    <img src="assets/images/inspiration1.webp" alt="Inspiration" class="inspiration transition-all duration-300 hover:scale-110 relative" />
                                </div>
                                <div class="inspiration-btn px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                                    <h6>Master Room</h6>
                                </div>
                            </div>
                            <div class="w-7/12 relative">
                                <div class="w-full relative mx-auto h-auto overflow-hidden br-20">
                                    <img src="assets/images/inspiration2.webp" alt="Inspiration" class="inspiration transition-all duration-300 hover:scale-110 relative" />
                                </div>
                                <div class="inspiration-btn px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                                    <h6>Living Room</h6>
                                </div>
                            </div>
                        </div>
                        <div class="flex gap-4">
                            <div class="w-7/12 relative">
                                <div class="w-full relative mx-auto h-auto overflow-hidden br-20">
                                    <img src="assets/images/inspiration6.webp" alt="Inspiration" class="inspiration transition-all duration-300 hover:scale-110 relative" />
                                </div>
                                <div class="inspiration-btn px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                                    <h6>Home By Livspace</h6>
                                </div>
                            </div>
                            <div class="w-5/12 relative">
                                <div class="w-full relative mx-auto h-auto overflow-hidden br-20">
                                    <img src="assets/images/inspiration7.webp" alt="Inspiration" class="inspiration transition-all duration-300 hover:scale-110 relative" />
                                </div>
                                <div class="inspiration-btn1 px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                                    <h6>Kitchen</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="w-2/12 relative">
                        <div class="w-full relative mx-auto h-auto overflow-hidden br-20">
                            <img src="assets/images/inspiration3.webp" alt="Inspiration" class="inspiration transition-all duration-300 hover:scale-110 relative" />
                        </div>
                        <div class="inspiration-btn px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                            <h6>False Ceiling</h6>
                        </div>
                    </div>
                    <div class="w-5/12">
                        <div class="flex items-end gap-4 mb-4">
                            <div class="w-7/12 relative">
                                <div class="w-full relative mx-auto h-auto overflow-hidden br-20">
                                    <img src="assets/images/inspiration4.webp" alt="Inspiration" class="inspiration transition-all duration-300 hover:scale-110 relative" />
                                </div>
                                <div class="inspiration-btn px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                                    <h6>Kids Room</h6>
                                </div>
                            </div>
                            <div class="w-5/12 relative">
                                <div class="w-full relative mx-auto h-auto overflow-hidden br-20">
                                    <img src="assets/images/inspiration5.webp" alt="Inspiration" class="inspiration transition-all duration-300 hover:scale-110 relative" />
                                </div>
                                <div class="inspiration-btn px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                                    <h6>Home Office</h6>
                                </div>
                            </div>
                        </div>
                        <div class="flex gap-4">
                            <div class="w-5/12 relative">
                                <div class="w-full relative mx-auto h-auto overflow-hidden br-20">
                                    <img src="assets/images/inspiration8.webp" alt="Inspiration" class="inspiration transition-all duration-300 hover:scale-110 relative" />
                                </div>
                                <div class="inspiration-btn px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                                    <h6>Wardrobe</h6>
                                </div>
                            </div>
                            <div class="w-7/12 relative">
                                <div class="w-full relative mx-auto h-auto overflow-hidden br-20">
                                    <img src="assets/images/inspiration9.webp" alt="Inspiration" class="inspiration transition-all duration-300 hover:scale-110 relative" />
                                </div>
                                <div class="inspiration-btn2 px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                                    <h6>Dining Room</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="gallery-design-block">
                <div>
                    <h2 class="text-center font-bold mb-3 sm:mb-0">
                        Home Design Inspiration Gallery
                    </h2>
                    <p class="text-center mb-4">
                        Give your home a new look with these interior design ideas curated
                        for you
                    </p>
                </div>

                <div class="grid gap-x-8 gap-y-4 sm:grid-cols-2 md:grid-cols-3 items-center">
                    <div class="relative mx-auto h-auto overflow-hidden br-20">
                        <img src="assets/images/res-gallery.webp" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                        <div class="inspiration-btn px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                            <h6>Dining Room</h6>
                        </div>
                    </div>
                    <div class="relative mx-auto h-auto overflow-hidden br-20">
                        <img src="assets/images/res-gallery2.webp" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                        <div class="inspiration-btn px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                            <h6>Wardrobe</h6>
                        </div>
                    </div>
                    <div class="relative mx-auto h-auto overflow-hidden br-20">
                        <img src="assets/images/res-galler3.webp" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                        <div class="inspiration-btn px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                            <h6>Kitchen</h6>
                        </div>
                    </div>
                    <div class="relative mx-auto h-auto overflow-hidden br-20">
                        <img src="assets/images/res-galler4.webp" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                        <div class="inspiration-btn px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                            <h6>Home By Livspace</h6>
                        </div>
                    </div>
                    <div class="relative mx-auto h-auto overflow-hidden br-20">
                        <img src="assets/images/res-galler5.webp" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                        <div class="inspiration-btn px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                            <h6>Kids Room</h6>
                        </div>
                    </div>
                    <div class="relative mx-auto h-auto overflow-hidden br-20">
                        <img src="assets/images/res-gallery6.webp" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                        <div class="inspiration-btn px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                            <h6>False Ceiling</h6>
                        </div>
                    </div>
                    <div class="relative mx-auto h-auto overflow-hidden br-20">
                        <img src="assets/images/res-gallery7.webp" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                        <div class="inspiration-btn px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                            <h6>Living Room</h6>
                        </div>
                    </div>
                    <div class="relative mx-auto h-auto overflow-hidden br-20">
                        <img src="assets/images/res-galler8.webp" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                        <div class="inspiration-btn px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                            <h6>Master Room</h6>
                        </div>
                    </div>
                    <div class="relative mx-auto h-auto overflow-hidden br-20">
                        <img src="assets/images/res-gallery9.webp" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                        <div class="inspiration-btn px-4 py-1 xl:py-2 absolute text-center text-white text-xl">
                            <h6>Home Office</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Home Design Inspiration Gallery -->

    <!-- CTA start -->
    <section class="py-100 px-4">
        <div class="container mx-auto" id="cta-bg">
            <div class="grid gap-x-8 gap-y-4 grid-cols-2 items-center flex-column">
                <div>
                    <img src="assets/images/ctag-img.webp" alt="cta" class="hidden lg:block" />
                    <img src="assets/images/cta-mob.webp" alt="cta" class="block lg:hidden rounded-2xl" />
                </div>
                <div class="text-center md:text-start mx-3 md-mx-0">
                    <h5 class="text-white">Unable To Decide Upon a Colour?</h5>
                    <h2 class="text-white font-semibold">
                        Get Quotation (Calculate Price)
                    </h2>
                    <h4>Self serve</h4>
                    <button type="submit" class="mb-4 xl:mb-0 mt-4 text-black bg-yellow cta-btn font-medium rounded-lg text-sm px-5 py-2.5 text-center before:ease relative overflow-hidden transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40">
                        <span relative="relative z-10">Estimate Cost</span>
                    </button>
                </div>
            </div>
        </div>
    </section>
    <!-- CTA start -->

    <!--Video Testimonials start -->
    <section id="video-testimonials">
        <div class="container mx-auto">
            <h2 class="text-center font-bold mb-4">Video Testimonials</h2>

            <Swiper class="catalogue" :slides-per-view="1" :breakpoints="{
            640: { slidesPerView: 1 },
            768: { slidesPerView: 2 },
            1024: { slidesPerView: 3 },
          }" :loop="true" :modules="[SwiperAutoplay, SwiperEffectCreative, SwiperNavigation]" :autoplay="{
            delay: 3000,
            disableOnInteraction: true,
          }" :pauseAutoplayOnMouseEnter="true" :navigation="true" :pagination="{
            clickable: true,
          }">
                <SwiperSlide class="h-100">
                    <div class="bg-white p-5 video-box rounded-2xl m-3">
                        <div class="relative cursor-pointer" onclick="toggleModal4()">
                            <img src="assets/images/video-testimonial1.webp" alt="video-box" class="rounded-2xl" />
                            <div class="absolute play-btn">
                                <img src="assets/images/play-btn.svg" alt="play-btn" />
                            </div>
                        </div>

                        <div class="mt-4">
                            <div class="flex items-center">
                                <img src="assets/images/user-img.webp" alt="user" class="w-22" />
                                <div class="ms-3">
                                    <h5 class="font-bold text-xl">Darin Nguyen</h5>
                                    <p>@staking</p>
                                </div>
                            </div>
                            <p class="text-xl text-black mt-3">
                                Faucibus eu condimentum maecenas sollicitudin vitae.
                            </p>

                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide class="h-100">
                    <div class="bg-white p-5 video-box rounded-2xl m-3">
                        <div class="relative cursor-pointer" onclick="toggleModal4()">
                            <img src="assets/images/video-testimonial1.webp" alt="video-box" class="rounded-2xl" />
                            <div class="absolute play-btn">
                                <img src="assets/images/play-btn.svg" alt="play-btn" />
                            </div>
                        </div>

                        <div class="mt-4">
                            <div class="flex items-center">
                                <img src="assets/images/user-img.webp" alt="user" class="w-22" />
                                <div class="ms-3">
                                    <h5 class="font-bold text-xl">Darin Nguyen</h5>
                                    <p>@staking</p>
                                </div>
                            </div>
                            <p class="text-xl text-black mt-3">
                                Faucibus eu condimentum maecenas sollicitudin vitae.
                            </p>

                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide class="h-100">
                    <div class="bg-white p-5 video-box rounded-2xl m-3">
                        <div class="relative cursor-pointer" onclick="toggleModal4()">
                            <img src="assets/images/video-testimonial1.webp" alt="video-box" class="rounded-2xl" />
                            <div class="absolute play-btn">
                                <img src="assets/images/play-btn.svg" alt="play-btn" />
                            </div>
                        </div>

                        <div class="mt-4">
                            <div class="flex items-center">
                                <img src="assets/images/user-img.webp" alt="user" class="w-22" />
                                <div class="ms-3">
                                    <h5 class="font-bold text-xl">Darin Nguyen</h5>
                                    <p>@staking</p>
                                </div>
                            </div>
                            <p class="text-xl text-black mt-3">
                                Faucibus eu condimentum maecenas sollicitudin vitae.
                            </p>

                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide class="h-100">
                    <div class="bg-white p-5 video-box rounded-2xl m-3">
                        <div class="relative cursor-pointer" onclick="toggleModal4()">
                            <img src="assets/images/video-testimonial1.webp" alt="video-box" class="rounded-2xl" />
                            <div class="absolute play-btn">
                                <img src="assets/images/play-btn.svg" alt="play-btn" />
                            </div>
                        </div>

                        <div class="mt-4">
                            <div class="flex items-center">
                                <img src="assets/images/user-img.webp" alt="user" class="w-22" />
                                <div class="ms-3">
                                    <h5 class="font-bold text-xl">Darin Nguyen</h5>
                                    <p>@staking</p>
                                </div>
                            </div>
                            <p class="text-xl text-black mt-3">
                                Faucibus eu condimentum maecenas sollicitudin vitae.
                            </p>

                        </div>
                    </div>
                </SwiperSlide>

            </Swiper>
        </div>
    </section>
    <div id="video-popup" class="px-2 md:px-0 fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center hidden ">

        <div class="bg-white w-10/12 lg:w-7/12 relative br-20">
            <button type="button" class="text-white mr-2 absolute btn-position close-btn z-50" onclick="toggleModal4()">
                <i class="fas fa-times"></i>
            </button>

            <div class="br-20">
                <iframe width="100%" class="br-20" height="500" src="https://www.youtube.com/embed/KPJ5fRcfQBI?si=bIjdW5Az1Ocnbqn8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
            </div>
        </div>
    </div>
    <!-- Video Testimonials end -->

    <!-- Why You should choose CD -->
    <section class="py-100 px-4" id="cd">
        <div class="container mx-auto">
            <div class="flex gap-4 mb-4 flex-col md:flex-row">
                <div class="w-full lg:w-4/12 xl:w-6/12 shadow1 p-6">
                    <h2 class="font-semibold">Why You should choose CD</h2>
                    <p class="my-3 text-center sm:text-start">
                        Lorem Ipsum is simply dummy text of the printing and typesetting
                        industry. Lorem Ipsum has been the industry's standard dummy text
                        ever since the 1500s, when an unknown printer took a galley of
                        type and scrambled it to make a type specimen.
                    </p>
                    <div class="justify-center flex sm:justify-start">
                        <button class="m-0 rounded-lg px-5 py-2.5 main-btngreen before:ease relative overflow-hidden text-white shadow-2xl transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-green-500 hover:before:-translate-x-40">
                            <span relative="relative z-10">Book Series</span>
                        </button>
                    </div>

                </div>
                <div class="w-full lg:w-4/12 xl:w-3/12 shadow1 p-6">
                    <img src="assets/images/cd1.svg" alt="cd" />
                    <h5 class="my-3 text-xl font-semibold">
                        Get 8000+ Colour Shades Suggestions
                    </h5>
                    <p>
                        Lorem Ipsum is simply dummy text of the printing and typesetting
                        industry.
                    </p>
                </div>
                <div class="w-full lg:w-4/12 xl:w-3/12 shadow1 p-6">
                    <img src="assets/images/cd2.svg" alt="cd" />
                    <h5 class="my-3 text-xl font-semibold">
                        Home Wall Design Painting Ideas
                    </h5>
                    <p>
                        Lorem Ipsum is simply dummy text of the printing and typesetting
                        industry.
                    </p>
                </div>
            </div>
            <div class="flex gap-4 flex-col md:flex-row">
                <div class="w-full lg:w-4/12 xl:w-4/12 shadow1 p-6">
                    <img src="assets/images/cd3.svg" alt="cd" />
                    <h5 class="my-3 text-xl font-semibold">
                        ColourDrive Painters Vs Local Painters
                    </h5>
                    <p>
                        Lorem Ipsum is simply dummy text of the printing and typesetting
                        industry Lorem Ipsum is simply dummy text of the printing and
                        typesetting industry.
                    </p>
                </div>
                <div class="w-full lg:w-4/12 xl:w-4/12 shadow1 p-6">
                    <img src="assets/images/cd4.svg" alt="cd" />
                    <h5 class="my-3 text-xl font-semibold">
                        Home Wall Design Painting Ideas
                    </h5>
                    <p>
                        Lorem Ipsum is simply dummy text of the printing and typesetting
                        industry Lorem Ipsum is simply dummy text of the printing and
                        typesetting industry.
                    </p>
                </div>
                <div class="w-full lg:w-4/12 xl:w-4/12 shadow1 p-6">
                    <img src="assets/images/cd5.svg" alt="cd" />
                    <h5 class="my-3 text-xl font-semibold">
                        Get 8000+ Colour Shades Suggestions
                    </h5>
                    <p>
                        Lorem Ipsum is simply dummy text of the printing and typesetting
                        industry Lorem Ipsum is simply dummy text of the printing and
                        typesetting industry.
                    </p>
                </div>
            </div>
        </div>
    </section>
    <!-- Why You should choose CD -->

    <!-- Suppliers brand -->
    <section class="mx-3">
        <!-- <div class="container mx-auto"> -->
        <h2 class="text-center font-bold mb-5">Suppliers brand</h2>

        <Swiper class="brand mx-2" :slides-per-view="1" :loop="true" :space-between="30" :breakpoints="{
            640: { slidesPerView: 1 },
            768: { slidesPerView: 2 },
            1024: { slidesPerView: 6.5 },
          }" :modules="[SwiperAutoplay, SwiperEffectCreative]" :autoplay="{
            delay: 1000,
            disableOnInteraction: true,
          }" :pauseAutoplayOnMouseEnter="true" ,>
            <SwiperSlide class="h-100">
                <div class="w-full relative mx-auto h-auto overflow-hidden br-20 shadow11 m-3">
                    <img src="assets/images/brand1.webp" alt="brand" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                </div>
            </SwiperSlide>
            <SwiperSlide class="h-100">
                <div class="w-full relative mx-auto h-auto overflow-hidden br-20 shadow11 m-3">
                    <img src="assets/images/brand2.webp" alt="brand" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                </div>
            </SwiperSlide>
            <SwiperSlide class="h-100">
                <div class="w-full relative mx-auto h-auto overflow-hidden br-20 shadow11 m-3">
                    <img src="assets/images/brand3.webp" alt="brand" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                </div>
            </SwiperSlide>
            <SwiperSlide class="h-100">
                <div class="w-full relative mx-auto h-auto overflow-hidden br-20 shadow11 m-3">
                    <img src="assets/images/brand4.webp" alt="brand" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                </div>
            </SwiperSlide>
            <SwiperSlide class="h-100">
                <div class="w-full relative mx-auto h-auto overflow-hidden br-20 shadow11 m-3">
                    <img src="assets/images/brand5.webp" alt="brand" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                </div>
            </SwiperSlide>
            <SwiperSlide class="h-100">
                <div class="w-full relative mx-auto h-auto overflow-hidden br-20 shadow11 justify-center m-3">
                    <img src="assets/images/brand6.webp" alt="brand" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                </div>
            </SwiperSlide>
            <SwiperSlide class="h-100">
                <div class="w-full relative mx-auto h-auto overflow-hidden br-20 shadow11 m-3">
                    <img src="assets/images/brand7.webp" alt="brand" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                </div>
            </SwiperSlide>
            <SwiperSlide class="h-100">
                <div class="w-full relative mx-auto h-auto overflow-hidden br-20 shadow11 m-3">
                    <img src="assets/images/brand8.webp" alt="brand" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                </div>
            </SwiperSlide>
            <SwiperSlide class="h-100">
                <div class="w-full relative mx-auto h-auto overflow-hidden br-20 shadow11 m-3">
                    <img src="assets/images/brand10.webp" alt="brand" class="rounded-2xl transition-all duration-300 hover:scale-110 relative" />
                </div>
            </SwiperSlide>
        </Swiper>
        <!-- </div> -->

    </section>
    <!-- Suppliers brand -->

    <!-- blog -->
    <section id="blog" class="py-100">
        <div class="container mx-auto">
            <h2 class="text-center font-bold mb-0 mb-sm-5">Recent Projects</h2>
            <Swiper class="catalogue" :slides-per-view="1" :loop="true" :breakpoints="{
            640: { slidesPerView: 1 },
            768: { slidesPerView: 2 },
            1024: { slidesPerView: 3 },
          }" :modules="[SwiperAutoplay, SwiperEffectCreative]" :autoplay="{
            delay: 3000,
            disableOnInteraction: true,
          }" :pauseAutoplayOnMouseEnter="true" :navigation="true" :pagination="{
            clickable: true,
          }">
                <SwiperSlide class="h-100">
                    <div class="item m-4">
                        <div class="blog-box rounded-2xl">
                            <div class="relative">
                                <img src="assets/images/blog1.webp" width="100%" alt="Blog" class="blog" />
                                <div class="blog-btn px-4 py-2 absolute text-center text-white text-xl flex items-center">
                                    <svg width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13.6 1.99272H12.8V1.21999C12.8 0.756357 12.48 0.447266 12 0.447266C11.52 0.447266 11.2 0.756357 11.2 1.21999V1.99272H4.8V1.21999C4.8 0.756357 4.48 0.447266 4 0.447266C3.52 0.447266 3.2 0.756357 3.2 1.21999V1.99272H2.4C1.04 1.99272 0 2.99727 0 4.3109V15.1291C0 16.4427 1.04 17.4473 2.4 17.4473H13.6C14.96 17.4473 16 16.4427 16 15.1291V4.3109C16 3.07454 14.96 1.99272 13.6 1.99272ZM4 14.3564C3.52 14.3564 3.2 14.0473 3.2 13.5836C3.2 13.12 3.52 12.8109 4 12.8109C4.48 12.8109 4.8 13.12 4.8 13.5836C4.8 14.0473 4.48 14.3564 4 14.3564ZM4 11.2654C3.52 11.2654 3.2 10.9564 3.2 10.4927C3.2 10.0291 3.52 9.71999 4 9.71999C4.48 9.71999 4.8 10.0291 4.8 10.4927C4.8 10.9564 4.48 11.2654 4 11.2654ZM8 14.3564C7.52 14.3564 7.2 14.0473 7.2 13.5836C7.2 13.12 7.52 12.8109 8 12.8109C8.48 12.8109 8.8 13.12 8.8 13.5836C8.8 14.0473 8.48 14.3564 8 14.3564ZM8 11.2654C7.52 11.2654 7.2 10.9564 7.2 10.4927C7.2 10.0291 7.52 9.71999 8 9.71999C8.48 9.71999 8.8 10.0291 8.8 10.4927C8.8 10.9564 8.48 11.2654 8 11.2654ZM12 14.3564C11.52 14.3564 11.2 14.0473 11.2 13.5836C11.2 13.12 11.52 12.8109 12 12.8109C12.48 12.8109 12.8 13.12 12.8 13.5836C12.8 14.0473 12.48 14.3564 12 14.3564ZM12 11.2654C11.52 11.2654 11.2 10.9564 11.2 10.4927C11.2 10.0291 11.52 9.71999 12 9.71999C12.48 9.71999 12.8 10.0291 12.8 10.4927C12.8 10.9564 12.48 11.2654 12 11.2654ZM14.4 6.62908H1.6V4.3109C1.6 3.84727 1.92 3.53817 2.4 3.53817H3.2V4.3109C3.2 4.77454 3.52 5.08363 4 5.08363C4.48 5.08363 4.8 4.77454 4.8 4.3109V3.53817H11.2V4.3109C11.2 4.77454 11.52 5.08363 12 5.08363C12.48 5.08363 12.8 4.77454 12.8 4.3109V3.53817H13.6C14.08 3.53817 14.4 3.84727 14.4 4.3109V6.62908Z" fill="white" />
                                    </svg>
                                    <h6 class="ms-3">Feb 20, 2024</h6>
                                </div>
                            </div>
                            <div class="p-4">
                                <ul class="m-0 p-0">
                                    <li class="flex items-center">
                                        <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M17.5331 8.74538V14.3572C17.5331 14.5599 17.4545 14.7352 17.2974 14.8833C17.1403 15.0314 16.9542 15.1055 16.7392 15.1055H11.9756V10.616H8.79982V15.1055H4.03621C3.82119 15.1055 3.63511 15.0314 3.47798 14.8833C3.32084 14.7352 3.24228 14.5599 3.24228 14.3572V8.74538C3.24228 8.73758 3.24435 8.72589 3.24848 8.7103C3.25262 8.69471 3.25468 8.68302 3.25468 8.67523L10.3877 3.13353L17.5207 8.67523C17.529 8.69082 17.5331 8.7142 17.5331 8.74538ZM20.2995 7.93867L19.5304 8.80383C19.4642 8.87398 19.3774 8.91685 19.2698 8.93244H19.2326C19.1251 8.93244 19.0383 8.90516 18.9721 8.8506L10.3877 2.10469L1.80327 8.8506C1.70403 8.91295 1.60479 8.94023 1.50555 8.93244C1.39803 8.91685 1.3112 8.87398 1.24504 8.80383L0.47591 7.93867C0.409749 7.86073 0.380804 7.76915 0.389074 7.66393C0.397344 7.5587 0.44283 7.47492 0.525531 7.41256L9.4449 0.409444C9.70954 0.206794 10.0238 0.105469 10.3877 0.105469C10.7516 0.105469 11.0658 0.206794 11.3305 0.409444L14.3574 2.79448V0.514666C14.3574 0.405547 14.3946 0.315913 14.469 0.245765C14.5435 0.175617 14.6386 0.140543 14.7543 0.140543H17.1361C17.2519 0.140543 17.347 0.175617 17.4215 0.245765C17.4959 0.315913 17.5331 0.405547 17.5331 0.514666V5.28474L20.2499 7.41256C20.3326 7.47492 20.378 7.5587 20.3863 7.66393C20.3946 7.76915 20.3656 7.86073 20.2995 7.93867Z" fill="#6A6D70" />
                                        </svg>
                                        <h5 class="ms-3">Panduranganagar Bannerghatta Road</h5>
                                    </li>
                                    <li class="flex items-center">
                                        <svg width="16" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M7.8877 0.105469C5.89857 0.105469 3.99092 0.856196 2.58439 2.1925C1.17787 3.5288 0.387695 5.34122 0.387695 7.23103C0.387695 12.4881 7.30436 18.7349 7.60436 18.9961C7.68185 19.0663 7.7848 19.1055 7.89186 19.1055C7.99892 19.1055 8.10187 19.0663 8.17936 18.9961C8.47103 18.7349 15.3877 12.4881 15.3877 7.23103C15.3877 5.34122 14.5975 3.5288 13.191 2.1925C11.7845 0.856196 9.87682 0.105469 7.8877 0.105469ZM7.8877 11.1897C7.06361 11.1897 6.25802 10.9575 5.57282 10.5225C4.88761 10.0875 4.35356 9.46929 4.0382 8.74594C3.72283 8.02259 3.64032 7.22664 3.80109 6.45874C3.96186 5.69084 4.3587 4.98547 4.94142 4.43185C5.52414 3.87822 6.26656 3.5012 7.07482 3.34845C7.88307 3.19571 8.72085 3.2741 9.48221 3.57372C10.2436 3.87334 10.8943 4.38073 11.3522 5.03173C11.81 5.68272 12.0544 6.44809 12.0544 7.23103C12.0544 7.75089 11.9466 8.26566 11.7372 8.74594C11.5278 9.22623 11.2209 9.66263 10.834 10.0302C10.4471 10.3978 9.98773 10.6894 9.48221 10.8883C8.97669 11.0873 8.43487 11.1897 7.8877 11.1897Z" fill="#6A6D70" />
                                        </svg>

                                        <h5 class="ms-3">Bangalore</h5>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide class="h-100">
                    <div class="item m-4">
                        <div class="blog-box rounded-2xl">
                            <div class="relative">
                                <img src="assets/images/blog2.webp" width="100%" alt="Blog" class="blog" />
                                <div class="blog-btn px-4 py-2 absolute text-center text-white text-xl flex items-center">
                                    <svg width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13.6 1.99272H12.8V1.21999C12.8 0.756357 12.48 0.447266 12 0.447266C11.52 0.447266 11.2 0.756357 11.2 1.21999V1.99272H4.8V1.21999C4.8 0.756357 4.48 0.447266 4 0.447266C3.52 0.447266 3.2 0.756357 3.2 1.21999V1.99272H2.4C1.04 1.99272 0 2.99727 0 4.3109V15.1291C0 16.4427 1.04 17.4473 2.4 17.4473H13.6C14.96 17.4473 16 16.4427 16 15.1291V4.3109C16 3.07454 14.96 1.99272 13.6 1.99272ZM4 14.3564C3.52 14.3564 3.2 14.0473 3.2 13.5836C3.2 13.12 3.52 12.8109 4 12.8109C4.48 12.8109 4.8 13.12 4.8 13.5836C4.8 14.0473 4.48 14.3564 4 14.3564ZM4 11.2654C3.52 11.2654 3.2 10.9564 3.2 10.4927C3.2 10.0291 3.52 9.71999 4 9.71999C4.48 9.71999 4.8 10.0291 4.8 10.4927C4.8 10.9564 4.48 11.2654 4 11.2654ZM8 14.3564C7.52 14.3564 7.2 14.0473 7.2 13.5836C7.2 13.12 7.52 12.8109 8 12.8109C8.48 12.8109 8.8 13.12 8.8 13.5836C8.8 14.0473 8.48 14.3564 8 14.3564ZM8 11.2654C7.52 11.2654 7.2 10.9564 7.2 10.4927C7.2 10.0291 7.52 9.71999 8 9.71999C8.48 9.71999 8.8 10.0291 8.8 10.4927C8.8 10.9564 8.48 11.2654 8 11.2654ZM12 14.3564C11.52 14.3564 11.2 14.0473 11.2 13.5836C11.2 13.12 11.52 12.8109 12 12.8109C12.48 12.8109 12.8 13.12 12.8 13.5836C12.8 14.0473 12.48 14.3564 12 14.3564ZM12 11.2654C11.52 11.2654 11.2 10.9564 11.2 10.4927C11.2 10.0291 11.52 9.71999 12 9.71999C12.48 9.71999 12.8 10.0291 12.8 10.4927C12.8 10.9564 12.48 11.2654 12 11.2654ZM14.4 6.62908H1.6V4.3109C1.6 3.84727 1.92 3.53817 2.4 3.53817H3.2V4.3109C3.2 4.77454 3.52 5.08363 4 5.08363C4.48 5.08363 4.8 4.77454 4.8 4.3109V3.53817H11.2V4.3109C11.2 4.77454 11.52 5.08363 12 5.08363C12.48 5.08363 12.8 4.77454 12.8 4.3109V3.53817H13.6C14.08 3.53817 14.4 3.84727 14.4 4.3109V6.62908Z" fill="white" />
                                    </svg>
                                    <h6 class="ms-3">Feb 20, 2024</h6>
                                </div>
                            </div>
                            <div class="p-4">
                                <ul class="m-0 p-0">
                                    <li class="flex items-center">
                                        <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M17.5331 8.74538V14.3572C17.5331 14.5599 17.4545 14.7352 17.2974 14.8833C17.1403 15.0314 16.9542 15.1055 16.7392 15.1055H11.9756V10.616H8.79982V15.1055H4.03621C3.82119 15.1055 3.63511 15.0314 3.47798 14.8833C3.32084 14.7352 3.24228 14.5599 3.24228 14.3572V8.74538C3.24228 8.73758 3.24435 8.72589 3.24848 8.7103C3.25262 8.69471 3.25468 8.68302 3.25468 8.67523L10.3877 3.13353L17.5207 8.67523C17.529 8.69082 17.5331 8.7142 17.5331 8.74538ZM20.2995 7.93867L19.5304 8.80383C19.4642 8.87398 19.3774 8.91685 19.2698 8.93244H19.2326C19.1251 8.93244 19.0383 8.90516 18.9721 8.8506L10.3877 2.10469L1.80327 8.8506C1.70403 8.91295 1.60479 8.94023 1.50555 8.93244C1.39803 8.91685 1.3112 8.87398 1.24504 8.80383L0.47591 7.93867C0.409749 7.86073 0.380804 7.76915 0.389074 7.66393C0.397344 7.5587 0.44283 7.47492 0.525531 7.41256L9.4449 0.409444C9.70954 0.206794 10.0238 0.105469 10.3877 0.105469C10.7516 0.105469 11.0658 0.206794 11.3305 0.409444L14.3574 2.79448V0.514666C14.3574 0.405547 14.3946 0.315913 14.469 0.245765C14.5435 0.175617 14.6386 0.140543 14.7543 0.140543H17.1361C17.2519 0.140543 17.347 0.175617 17.4215 0.245765C17.4959 0.315913 17.5331 0.405547 17.5331 0.514666V5.28474L20.2499 7.41256C20.3326 7.47492 20.378 7.5587 20.3863 7.66393C20.3946 7.76915 20.3656 7.86073 20.2995 7.93867Z" fill="#6A6D70" />
                                        </svg>
                                        <h5 class="ms-3">Panduranganagar Bannerghatta Road</h5>
                                    </li>
                                    <li class="flex items-center">
                                        <svg width="16" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M7.8877 0.105469C5.89857 0.105469 3.99092 0.856196 2.58439 2.1925C1.17787 3.5288 0.387695 5.34122 0.387695 7.23103C0.387695 12.4881 7.30436 18.7349 7.60436 18.9961C7.68185 19.0663 7.7848 19.1055 7.89186 19.1055C7.99892 19.1055 8.10187 19.0663 8.17936 18.9961C8.47103 18.7349 15.3877 12.4881 15.3877 7.23103C15.3877 5.34122 14.5975 3.5288 13.191 2.1925C11.7845 0.856196 9.87682 0.105469 7.8877 0.105469ZM7.8877 11.1897C7.06361 11.1897 6.25802 10.9575 5.57282 10.5225C4.88761 10.0875 4.35356 9.46929 4.0382 8.74594C3.72283 8.02259 3.64032 7.22664 3.80109 6.45874C3.96186 5.69084 4.3587 4.98547 4.94142 4.43185C5.52414 3.87822 6.26656 3.5012 7.07482 3.34845C7.88307 3.19571 8.72085 3.2741 9.48221 3.57372C10.2436 3.87334 10.8943 4.38073 11.3522 5.03173C11.81 5.68272 12.0544 6.44809 12.0544 7.23103C12.0544 7.75089 11.9466 8.26566 11.7372 8.74594C11.5278 9.22623 11.2209 9.66263 10.834 10.0302C10.4471 10.3978 9.98773 10.6894 9.48221 10.8883C8.97669 11.0873 8.43487 11.1897 7.8877 11.1897Z" fill="#6A6D70" />
                                        </svg>

                                        <h5 class="ms-3">Bangalore</h5>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide class="h-100">
                    <div class="item m-4">
                        <div class="blog-box rounded-2xl">
                            <div class="relative">
                                <img src="assets/images/blog3.webp" width="100%" alt="Blog" class="blog" />
                                <div class="blog-btn px-4 py-2 absolute text-center text-white text-xl flex items-center">
                                    <svg width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13.6 1.99272H12.8V1.21999C12.8 0.756357 12.48 0.447266 12 0.447266C11.52 0.447266 11.2 0.756357 11.2 1.21999V1.99272H4.8V1.21999C4.8 0.756357 4.48 0.447266 4 0.447266C3.52 0.447266 3.2 0.756357 3.2 1.21999V1.99272H2.4C1.04 1.99272 0 2.99727 0 4.3109V15.1291C0 16.4427 1.04 17.4473 2.4 17.4473H13.6C14.96 17.4473 16 16.4427 16 15.1291V4.3109C16 3.07454 14.96 1.99272 13.6 1.99272ZM4 14.3564C3.52 14.3564 3.2 14.0473 3.2 13.5836C3.2 13.12 3.52 12.8109 4 12.8109C4.48 12.8109 4.8 13.12 4.8 13.5836C4.8 14.0473 4.48 14.3564 4 14.3564ZM4 11.2654C3.52 11.2654 3.2 10.9564 3.2 10.4927C3.2 10.0291 3.52 9.71999 4 9.71999C4.48 9.71999 4.8 10.0291 4.8 10.4927C4.8 10.9564 4.48 11.2654 4 11.2654ZM8 14.3564C7.52 14.3564 7.2 14.0473 7.2 13.5836C7.2 13.12 7.52 12.8109 8 12.8109C8.48 12.8109 8.8 13.12 8.8 13.5836C8.8 14.0473 8.48 14.3564 8 14.3564ZM8 11.2654C7.52 11.2654 7.2 10.9564 7.2 10.4927C7.2 10.0291 7.52 9.71999 8 9.71999C8.48 9.71999 8.8 10.0291 8.8 10.4927C8.8 10.9564 8.48 11.2654 8 11.2654ZM12 14.3564C11.52 14.3564 11.2 14.0473 11.2 13.5836C11.2 13.12 11.52 12.8109 12 12.8109C12.48 12.8109 12.8 13.12 12.8 13.5836C12.8 14.0473 12.48 14.3564 12 14.3564ZM12 11.2654C11.52 11.2654 11.2 10.9564 11.2 10.4927C11.2 10.0291 11.52 9.71999 12 9.71999C12.48 9.71999 12.8 10.0291 12.8 10.4927C12.8 10.9564 12.48 11.2654 12 11.2654ZM14.4 6.62908H1.6V4.3109C1.6 3.84727 1.92 3.53817 2.4 3.53817H3.2V4.3109C3.2 4.77454 3.52 5.08363 4 5.08363C4.48 5.08363 4.8 4.77454 4.8 4.3109V3.53817H11.2V4.3109C11.2 4.77454 11.52 5.08363 12 5.08363C12.48 5.08363 12.8 4.77454 12.8 4.3109V3.53817H13.6C14.08 3.53817 14.4 3.84727 14.4 4.3109V6.62908Z" fill="white" />
                                    </svg>
                                    <h6 class="ms-3">Feb 20, 2024</h6>
                                </div>
                            </div>
                            <div class="p-4">
                                <ul class="m-0 p-0">
                                    <li class="flex items-center">
                                        <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M17.5331 8.74538V14.3572C17.5331 14.5599 17.4545 14.7352 17.2974 14.8833C17.1403 15.0314 16.9542 15.1055 16.7392 15.1055H11.9756V10.616H8.79982V15.1055H4.03621C3.82119 15.1055 3.63511 15.0314 3.47798 14.8833C3.32084 14.7352 3.24228 14.5599 3.24228 14.3572V8.74538C3.24228 8.73758 3.24435 8.72589 3.24848 8.7103C3.25262 8.69471 3.25468 8.68302 3.25468 8.67523L10.3877 3.13353L17.5207 8.67523C17.529 8.69082 17.5331 8.7142 17.5331 8.74538ZM20.2995 7.93867L19.5304 8.80383C19.4642 8.87398 19.3774 8.91685 19.2698 8.93244H19.2326C19.1251 8.93244 19.0383 8.90516 18.9721 8.8506L10.3877 2.10469L1.80327 8.8506C1.70403 8.91295 1.60479 8.94023 1.50555 8.93244C1.39803 8.91685 1.3112 8.87398 1.24504 8.80383L0.47591 7.93867C0.409749 7.86073 0.380804 7.76915 0.389074 7.66393C0.397344 7.5587 0.44283 7.47492 0.525531 7.41256L9.4449 0.409444C9.70954 0.206794 10.0238 0.105469 10.3877 0.105469C10.7516 0.105469 11.0658 0.206794 11.3305 0.409444L14.3574 2.79448V0.514666C14.3574 0.405547 14.3946 0.315913 14.469 0.245765C14.5435 0.175617 14.6386 0.140543 14.7543 0.140543H17.1361C17.2519 0.140543 17.347 0.175617 17.4215 0.245765C17.4959 0.315913 17.5331 0.405547 17.5331 0.514666V5.28474L20.2499 7.41256C20.3326 7.47492 20.378 7.5587 20.3863 7.66393C20.3946 7.76915 20.3656 7.86073 20.2995 7.93867Z" fill="#6A6D70" />
                                        </svg>
                                        <h5 class="ms-3">Panduranganagar Bannerghatta Road</h5>
                                    </li>
                                    <li class="flex items-center">
                                        <svg width="16" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M7.8877 0.105469C5.89857 0.105469 3.99092 0.856196 2.58439 2.1925C1.17787 3.5288 0.387695 5.34122 0.387695 7.23103C0.387695 12.4881 7.30436 18.7349 7.60436 18.9961C7.68185 19.0663 7.7848 19.1055 7.89186 19.1055C7.99892 19.1055 8.10187 19.0663 8.17936 18.9961C8.47103 18.7349 15.3877 12.4881 15.3877 7.23103C15.3877 5.34122 14.5975 3.5288 13.191 2.1925C11.7845 0.856196 9.87682 0.105469 7.8877 0.105469ZM7.8877 11.1897C7.06361 11.1897 6.25802 10.9575 5.57282 10.5225C4.88761 10.0875 4.35356 9.46929 4.0382 8.74594C3.72283 8.02259 3.64032 7.22664 3.80109 6.45874C3.96186 5.69084 4.3587 4.98547 4.94142 4.43185C5.52414 3.87822 6.26656 3.5012 7.07482 3.34845C7.88307 3.19571 8.72085 3.2741 9.48221 3.57372C10.2436 3.87334 10.8943 4.38073 11.3522 5.03173C11.81 5.68272 12.0544 6.44809 12.0544 7.23103C12.0544 7.75089 11.9466 8.26566 11.7372 8.74594C11.5278 9.22623 11.2209 9.66263 10.834 10.0302C10.4471 10.3978 9.98773 10.6894 9.48221 10.8883C8.97669 11.0873 8.43487 11.1897 7.8877 11.1897Z" fill="#6A6D70" />
                                        </svg>

                                        <h5 class="ms-3">Bangalore</h5>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </SwiperSlide>
                <SwiperSlide class="h-100">
                    <div class="item m-4">
                        <div class="blog-box rounded-2xl">
                            <div class="relative">
                                <img src="assets/images/blog3.webp" width="100%" alt="Blog" class="blog" />
                                <div class="blog-btn px-4 py-2 absolute text-center text-white text-xl flex items-center">
                                    <svg width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13.6 1.99272H12.8V1.21999C12.8 0.756357 12.48 0.447266 12 0.447266C11.52 0.447266 11.2 0.756357 11.2 1.21999V1.99272H4.8V1.21999C4.8 0.756357 4.48 0.447266 4 0.447266C3.52 0.447266 3.2 0.756357 3.2 1.21999V1.99272H2.4C1.04 1.99272 0 2.99727 0 4.3109V15.1291C0 16.4427 1.04 17.4473 2.4 17.4473H13.6C14.96 17.4473 16 16.4427 16 15.1291V4.3109C16 3.07454 14.96 1.99272 13.6 1.99272ZM4 14.3564C3.52 14.3564 3.2 14.0473 3.2 13.5836C3.2 13.12 3.52 12.8109 4 12.8109C4.48 12.8109 4.8 13.12 4.8 13.5836C4.8 14.0473 4.48 14.3564 4 14.3564ZM4 11.2654C3.52 11.2654 3.2 10.9564 3.2 10.4927C3.2 10.0291 3.52 9.71999 4 9.71999C4.48 9.71999 4.8 10.0291 4.8 10.4927C4.8 10.9564 4.48 11.2654 4 11.2654ZM8 14.3564C7.52 14.3564 7.2 14.0473 7.2 13.5836C7.2 13.12 7.52 12.8109 8 12.8109C8.48 12.8109 8.8 13.12 8.8 13.5836C8.8 14.0473 8.48 14.3564 8 14.3564ZM8 11.2654C7.52 11.2654 7.2 10.9564 7.2 10.4927C7.2 10.0291 7.52 9.71999 8 9.71999C8.48 9.71999 8.8 10.0291 8.8 10.4927C8.8 10.9564 8.48 11.2654 8 11.2654ZM12 14.3564C11.52 14.3564 11.2 14.0473 11.2 13.5836C11.2 13.12 11.52 12.8109 12 12.8109C12.48 12.8109 12.8 13.12 12.8 13.5836C12.8 14.0473 12.48 14.3564 12 14.3564ZM12 11.2654C11.52 11.2654 11.2 10.9564 11.2 10.4927C11.2 10.0291 11.52 9.71999 12 9.71999C12.48 9.71999 12.8 10.0291 12.8 10.4927C12.8 10.9564 12.48 11.2654 12 11.2654ZM14.4 6.62908H1.6V4.3109C1.6 3.84727 1.92 3.53817 2.4 3.53817H3.2V4.3109C3.2 4.77454 3.52 5.08363 4 5.08363C4.48 5.08363 4.8 4.77454 4.8 4.3109V3.53817H11.2V4.3109C11.2 4.77454 11.52 5.08363 12 5.08363C12.48 5.08363 12.8 4.77454 12.8 4.3109V3.53817H13.6C14.08 3.53817 14.4 3.84727 14.4 4.3109V6.62908Z" fill="white" />
                                    </svg>
                                    <h6 class="ms-3">Feb 20, 2024</h6>
                                </div>
                            </div>
                            <div class="p-4">
                                <ul class="m-0 p-0">
                                    <li class="flex items-center">
                                        <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M17.5331 8.74538V14.3572C17.5331 14.5599 17.4545 14.7352 17.2974 14.8833C17.1403 15.0314 16.9542 15.1055 16.7392 15.1055H11.9756V10.616H8.79982V15.1055H4.03621C3.82119 15.1055 3.63511 15.0314 3.47798 14.8833C3.32084 14.7352 3.24228 14.5599 3.24228 14.3572V8.74538C3.24228 8.73758 3.24435 8.72589 3.24848 8.7103C3.25262 8.69471 3.25468 8.68302 3.25468 8.67523L10.3877 3.13353L17.5207 8.67523C17.529 8.69082 17.5331 8.7142 17.5331 8.74538ZM20.2995 7.93867L19.5304 8.80383C19.4642 8.87398 19.3774 8.91685 19.2698 8.93244H19.2326C19.1251 8.93244 19.0383 8.90516 18.9721 8.8506L10.3877 2.10469L1.80327 8.8506C1.70403 8.91295 1.60479 8.94023 1.50555 8.93244C1.39803 8.91685 1.3112 8.87398 1.24504 8.80383L0.47591 7.93867C0.409749 7.86073 0.380804 7.76915 0.389074 7.66393C0.397344 7.5587 0.44283 7.47492 0.525531 7.41256L9.4449 0.409444C9.70954 0.206794 10.0238 0.105469 10.3877 0.105469C10.7516 0.105469 11.0658 0.206794 11.3305 0.409444L14.3574 2.79448V0.514666C14.3574 0.405547 14.3946 0.315913 14.469 0.245765C14.5435 0.175617 14.6386 0.140543 14.7543 0.140543H17.1361C17.2519 0.140543 17.347 0.175617 17.4215 0.245765C17.4959 0.315913 17.5331 0.405547 17.5331 0.514666V5.28474L20.2499 7.41256C20.3326 7.47492 20.378 7.5587 20.3863 7.66393C20.3946 7.76915 20.3656 7.86073 20.2995 7.93867Z" fill="#6A6D70" />
                                        </svg>
                                        <h5 class="ms-3">Panduranganagar Bannerghatta Road</h5>
                                    </li>
                                    <li class="flex items-center">
                                        <svg width="16" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M7.8877 0.105469C5.89857 0.105469 3.99092 0.856196 2.58439 2.1925C1.17787 3.5288 0.387695 5.34122 0.387695 7.23103C0.387695 12.4881 7.30436 18.7349 7.60436 18.9961C7.68185 19.0663 7.7848 19.1055 7.89186 19.1055C7.99892 19.1055 8.10187 19.0663 8.17936 18.9961C8.47103 18.7349 15.3877 12.4881 15.3877 7.23103C15.3877 5.34122 14.5975 3.5288 13.191 2.1925C11.7845 0.856196 9.87682 0.105469 7.8877 0.105469ZM7.8877 11.1897C7.06361 11.1897 6.25802 10.9575 5.57282 10.5225C4.88761 10.0875 4.35356 9.46929 4.0382 8.74594C3.72283 8.02259 3.64032 7.22664 3.80109 6.45874C3.96186 5.69084 4.3587 4.98547 4.94142 4.43185C5.52414 3.87822 6.26656 3.5012 7.07482 3.34845C7.88307 3.19571 8.72085 3.2741 9.48221 3.57372C10.2436 3.87334 10.8943 4.38073 11.3522 5.03173C11.81 5.68272 12.0544 6.44809 12.0544 7.23103C12.0544 7.75089 11.9466 8.26566 11.7372 8.74594C11.5278 9.22623 11.2209 9.66263 10.834 10.0302C10.4471 10.3978 9.98773 10.6894 9.48221 10.8883C8.97669 11.0873 8.43487 11.1897 7.8877 11.1897Z" fill="#6A6D70" />
                                        </svg>

                                        <h5 class="ms-3">Bangalore</h5>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </SwiperSlide>
            </Swiper>
        </div>
    </section>
    <!-- blog -->

    <!-- faq -->
    <section id="faq" class="pb-200 px-4 md-px-0">
        <div class="container mx-auto">
            <h2 class="text-center font-bold mb-5">FAQs</h2>
            <div class="accordion flex flex-col items-center justify-center">
                <!--  Panel 1  -->
                <div class="w-full lg:w-1/2 shadow11 mb-4">
                    <input type="checkbox" name="panel" id="panel-1" class="hidden" />
                    <label for="panel-1" class="relative block bg-white text-black p-4 rounded-2xl">Questions text goes here</label>
                    <div class="accordion__content overflow-hidden">
                        <p class="accordion__body p-4 text-black" id="panel1">
                            Lorem Ipsum is simply dummy text of the printing and typesetting
                            industry. Lorem Ipsum has been the industry's standard dummy
                            text ever since the 1500s, when an unknown printer took a galley
                            of type and scrambled it to make a type specimen.
                        </p>
                    </div>
                </div>
                <!--  Panel 2  -->
                <div class="w-full lg:w-1/2 shadow11 mb-4">
                    <input type="checkbox" name="panel" id="panel-2" class="hidden" />
                    <label for="panel-2" class="relative block bg-white text-black p-4 rounded-2xl">Questions text goes here</label>
                    <div class="accordion__content overflow-hidden">
                        <p class="accordion__body p-4 text-black" id="panel1">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto
                            possimus at a cum saepe molestias modi illo facere ducimus
                            voluptatibus praesentium deleniti fugiat ab error quia sit
                            perspiciatis velit necessitatibus.Lorem ipsum dolor sit amet,
                            consectetur adipisicing elit. Lorem ipsum dolor sit amet.
                        </p>
                    </div>
                </div>
                <!--  Panel 3  -->
                <div class="w-full lg:w-1/2 shadow11 mb-4">
                    <input type="checkbox" name="panel" id="panel-3" class="hidden" />
                    <label for="panel-3" class="relative block bg-white text-black p-4 rounded-2xl">Questions text goes here</label>
                    <div class="accordion__content overflow-hidden">
                        <p class="accordion__body p-4 text-black" id="panel1">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto
                            possimus at a cum saepe molestias modi illo facere ducimus
                            voluptatibus praesentium deleniti fugiat ab error quia sit
                            perspiciatis velit necessitatibus.Lorem ipsum dolor sit amet,
                            consectetur adipisicing elit. Lorem ipsum dolor sit amet.
                        </p>
                    </div>
                </div>
                <!--  Panel 4  -->
                <div class="w-full lg:w-1/2 shadow11 mb-4">
                    <input type="checkbox" name="panel" id="panel-4" class="hidden" />
                    <label for="panel-4" class="relative block bg-white text-black p-4 rounded-2xl">Questions text goes here</label>
                    <div class="accordion__content overflow-hidden">
                        <p class="accordion__body p-4 text-black" id="panel1">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto
                            possimus at a cum saepe molestias modi illo facere ducimus
                            voluptatibus praesentium deleniti fugiat ab error quia sit
                            perspiciatis velit necessitatibus.Lorem ipsum dolor sit amet,
                            consectetur adipisicing elit. Lorem ipsum dolor sit amet.
                        </p>
                    </div>
                </div>
                <!--  Panel 5  -->
                <div class="w-full lg:w-1/2 shadow11 mb-4">
                    <input type="checkbox" name="panel" id="panel-5" class="hidden" />
                    <label for="panel-5" class="relative block bg-white text-black p-4 rounded-2xl">Questions text goes here</label>
                    <div class="accordion__content overflow-hidden">
                        <p class="accordion__body p-4 text-black" id="panel1">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto
                            possimus at a cum saepe molestias modi illo facere ducimus
                            voluptatibus praesentium deleniti fugiat ab error quia sit
                            perspiciatis velit necessitatibus.Lorem ipsum dolor sit amet,
                            consectetur adipisicing elit. Lorem ipsum dolor sit amet.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- faq -->
</div>
</template>

<style scoped>
@import '../assets/css/main.css';
</style>
