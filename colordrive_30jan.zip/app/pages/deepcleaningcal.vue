<script></script>

<template>
    <!-- main banner start -->
    <section id="blog-new" class="py-100 px-3 mb-50px" data-v-inspector="app/pages/blog.vue:5:3" data-v-1bac7c7d="">
        <div class="flex items-center justify-center gap-2">
            <a href="/texturepaint">
                <p>Home</p>
            </a>
            <i class="fa-solid fa-chevron-right" style="color: #000000"></i>
            <p class="pink-txt">Texture Name</p>
        </div>
        <div class="container mx-auto" data-v-inspector="app/pages/blog.vue:6:5" data-v-1bac7c7d="">
            <!-- <h1>Blog</h1> -->
            <div class="text-center">
                <h2 class="text font-bold">Deep cleaing Calculator</h2>
                <div class="flex items-center justify-center gap-2">
                    <!-- <a href="/texturepaint"> <p>Home</p></a>
          <i class="fa-solid fa-chevron-right" style="color: #000000"></i> -->
                    <p class="text-gray-500">Get Free Painting Quotation</p>
                </div>
            </div>
        </div>
    </section>
    <!-- main banner end -->

    <!-- service Post section start -->
    <section id="service-post" class="pb-200 mt-50px px-4 px-md-0">
        <div class="container mx-auto">
            <div class="mx-auto">
                <div class="firstsecdiv">
                    <div class="tecctdiv">
                        <div>
                            <div class="calcseccardsdiv">
                                <div class="calcspace">
                                    <div class="calccardspacemini">
                                        <div class="flex flex-col xl:flex-row gap-8">
                                            <div class="basis-5/5 xl:basis-1/5">
                                                <div
                                                    class="calccardspacemini00 faqcustshadow p-4 rounded-lg sticky top-32">
                                                    <div class="calccardtitle mb-3">
                                                        <h5 class="font-bold">Select a service</h5>
                                                    </div>
                                                    <div class="calccardspacemini">
                                                        <div class="grid grid-cols-4 xl:grid-cols-3 md:grid-cols-7 sm:grid-cols-6 gap-4">
                                                            <div class="row-span-661">
                                                                <div class="calccardspacemini0">
                                                                    <a href="/calculatePrice"
                                                                        class="imgcalcdiv align-center flex justify-center rounded-md">
                                                                        <img src="assets/images/calculator/dc1.png"
                                                                            alt="Interior Painting" width=""
                                                                            class="w-full max-w-full h-auto" />
                                                                    </a>
                                                                    <div class="lablediv mt-2 text-center">
                                                                        <p class="text-sm">General
                                                                            Cleaning</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row-span-661">
                                                                <div class="calccardspacemini0">
                                                                    <a href="/exteriorcalculator"
                                                                        class="imgcalcdiv align-center flex justify-center rounded-md">
                                                                        <img src="assets/images/calculator/dc2.png"
                                                                            alt="Interior Painting" width=""
                                                                            class="w-full max-w-full h-auto" />
                                                                    </a>
                                                                    <div class="lablediv mt-2 text-center">
                                                                        <p class="text-sm">Living Room
                                                                            Cleaning</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row-span-661">
                                                                <div class="calccardspacemini0">
                                                                    <a href="/calculatePrice"
                                                                        class="imgcalcdiv align-center flex justify-center rounded-md">
                                                                        <img src="assets/images/calculator/dc3.png"
                                                                            alt="Interior Painting" width=""
                                                                            class="w-full max-w-full h-auto" />
                                                                    </a>
                                                                    <div class="lablediv mt-2 text-center">
                                                                        <p class="text-sm">Bed Room
                                                                            Cleaning</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row-span-661">
                                                                <div class="calccardspacemini0">
                                                                    <a href="/exteriorcalculator"
                                                                        class="imgcalcdiv align-center flex justify-center rounded-md">
                                                                        <img src="assets/images/calculator/dc4.png"
                                                                            alt="Interior Painting" width=""
                                                                            class="w-full max-w-full h-auto" />
                                                                    </a>
                                                                    <div class="lablediv mt-2 text-center">
                                                                        <p class="text-sm">Kitchen
                                                                            Cleaning</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row-span-661">
                                                                <div class="calccardspacemini0">
                                                                    <a href="/calculatePrice"
                                                                        class="imgcalcdiv align-center flex justify-center rounded-md">
                                                                        <img src="assets/images/calculator/dc5.png"
                                                                            alt="Interior Painting" width=""
                                                                            class="w-full max-w-full h-auto" />
                                                                    </a>
                                                                    <div class="lablediv mt-2 text-center">
                                                                        <p class="text-sm">Sofa
                                                                            Cleaning</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row-span-661">
                                                                <div class="calccardspacemini0">
                                                                    <a href="/exteriorcalculator"
                                                                        class="imgcalcdiv align-center flex justify-center rounded-md">
                                                                        <img src="assets/images/calculator/dc6.png"
                                                                            alt="Interior Painting" width=""
                                                                            class="w-full max-w-full h-auto" />
                                                                    </a>
                                                                    <div class="lablediv mt-2 text-center">
                                                                        <p class="text-sm">Carpet
                                                                            Cleaning</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="basis-5/5  xl:basis-4/5">
                                                <div class="calccardspacemini0 faqcustshadow p-8 rounded-lg">
                                                    <div class="flex gap-5 sm:flex-row flex-col items-center">
                                                        <div class="basis-1/2">
                                                            <h1 class="font-bold sm:text-5xl ">Premium Full House
                                                                Cleaning</h1>
                                                        </div>
                                                        <div
                                                            class="imgcalcdivv basis-1/2 align-center flex justify-center overflow-hidden rounded-2xl">
                                                            <img src="assets/images/calculator/dcmain.png"
                                                                alt="Interior Painting" width=""
                                                                class="w-full max-w-full h-auto" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="flex gap-3 flex-col md:flex-row mt-8 gap-8">
                                                    <div class="basis-3/3 md:basis-2/3">
                                                        <div
                                                            class="calccardspacemini00 faqcustshadow p-8 rounded-lg sticky top-32">
                                                            <h5 class="text-2xl font-bold mb-5">
                                                                Packages
                                                            </h5>
                                                            <div class="packegescardmain">
                                                                <div class="flex gap-5 flex-col">
                                                                    <div class="packegescard p-5 rounded-2xl">
                                                                        <div class="flex gap-3 justify-between w-full flex-col sm:flex-row">
                                                                            <div class="packcardleft">
                                                                                <h5 class="text-xl font-semibold mb-3">
                                                                                    Classic cleaning (2 bathrooms)
                                                                                </h5>
                                                                                <div
                                                                                    class="mb-3 reviewdivcard flex gap-3 items-center">
                                                                                    <i class="fa-solid fa-star"></i>
                                                                                    <p class="text-gray-500">4.383 (1.2M
                                                                                        reviews)</p>
                                                                                </div>
                                                                                <div
                                                                                    class="mb-3 pricedivmain flex gap-3">
                                                                                    <p class="pink-txt">₹785</p>
                                                                                    <p
                                                                                        class="text-gray-500 line-through">
                                                                                        ₹858</p>
                                                                                    <p class="text-gray-500 ">· 2 hrs
                                                                                    </p>
                                                                                </div>
                                                                                <div
                                                                                    class="mb-3 viewmoreivmain flex gap-3">
                                                                                    <a href="#"
                                                                                        class="text-gray-500 text-sm font-semibold">View
                                                                                        details</a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="packcardright">
                                                                                <div class="selectedinputdiv">
                                                                                    <div
                                                                                        class="selectednumbox bg-pink text-white text-center pt-3 pb-6 px-8 rounded-lg">
                                                                                        <h2
                                                                                            class="font-bold text-4xl mb-2">
                                                                                            2</h2>
                                                                                        <p class="uppercase">bathroom
                                                                                        </p>
                                                                                    </div>
                                                                                    <div
                                                                                        class="flex items-center shadow rounded-md w-fit mx-auto inptdiv bg-white mt-min-15px">
                                                                                        <!-- Minus Button -->
                                                                                        <button type="button"
                                                                                            class="px-3 py-2 focus:outline-none"
                                                                                            onclick="decreaseQty()">
                                                                                            −
                                                                                        </button>

                                                                                        <!-- Quantity Input -->
                                                                                        <input type="number"
                                                                                            id="qtyInput" value="1"
                                                                                            min="1"
                                                                                            class="w-16 text-center py-2 border-none" />

                                                                                        <!-- Plus Button -->
                                                                                        <button type="button"
                                                                                            class="px-3 py-2 focus:outline-none"
                                                                                            onclick="increaseQty()">
                                                                                            +
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="packegescard p-5 rounded-2xl">
                                                                        <div class="flex gap-3 justify-between w-full flex-col sm:flex-row">
                                                                            <div class="packcardleft">
                                                                                <h5 class="text-xl font-semibold mb-3">
                                                                                    Classic cleaning (2 bathrooms)
                                                                                </h5>
                                                                                <div
                                                                                    class="mb-3 reviewdivcard flex gap-3 items-center">
                                                                                    <i class="fa-solid fa-star"></i>
                                                                                    <p class="text-gray-500">4.383 (1.2M
                                                                                        reviews)</p>
                                                                                </div>
                                                                                <div
                                                                                    class="mb-3 pricedivmain flex gap-3">
                                                                                    <p class="pink-txt">₹785</p>
                                                                                    <p
                                                                                        class="text-gray-500 line-through">
                                                                                        ₹858</p>
                                                                                    <p class="text-gray-500 ">· 2 hrs
                                                                                    </p>
                                                                                </div>
                                                                                <div
                                                                                    class="mb-3 viewmoreivmain flex gap-3">
                                                                                    <a href="#"
                                                                                        class="text-gray-500 text-sm font-semibold">View
                                                                                        details</a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="packcardright">
                                                                                <div class="selectedinputdiv">
                                                                                    <div
                                                                                        class="selectednumbox bg-pink text-white text-center pt-3 pb-6 px-8 rounded-lg">
                                                                                        <h2
                                                                                            class="font-bold text-4xl mb-2">
                                                                                            2</h2>
                                                                                        <p class="uppercase">bathroom
                                                                                        </p>
                                                                                    </div>
                                                                                    <div
                                                                                        class="flex items-center shadow rounded-md w-fit mx-auto inptdiv bg-white mt-min-15px">
                                                                                        <!-- Minus Button -->
                                                                                        <button type="button"
                                                                                            class="px-3 py-2 focus:outline-none"
                                                                                            onclick="decreaseQty()">
                                                                                            −
                                                                                        </button>

                                                                                        <!-- Quantity Input -->
                                                                                        <input type="number"
                                                                                            id="qtyInput" value="1"
                                                                                            min="1"
                                                                                            class="w-16 text-center py-2 border-none" />

                                                                                        <!-- Plus Button -->
                                                                                        <button type="button"
                                                                                            class="px-3 py-2 focus:outline-none"
                                                                                            onclick="increaseQty()">
                                                                                            +
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="packegescard p-5 rounded-2xl">
                                                                        <div class="flex gap-3 justify-between w-full flex-col sm:flex-row">
                                                                            <div class="packcardleft">
                                                                                <h5 class="text-xl font-semibold mb-3">
                                                                                    Classic cleaning (2 bathrooms)
                                                                                </h5>
                                                                                <div
                                                                                    class="mb-3 reviewdivcard flex gap-3 items-center">
                                                                                    <i class="fa-solid fa-star"></i>
                                                                                    <p class="text-gray-500">4.383 (1.2M
                                                                                        reviews)</p>
                                                                                </div>
                                                                                <div
                                                                                    class="mb-3 pricedivmain flex gap-3">
                                                                                    <p class="pink-txt">₹785</p>
                                                                                    <p
                                                                                        class="text-gray-500 line-through">
                                                                                        ₹858</p>
                                                                                    <p class="text-gray-500 ">· 2 hrs
                                                                                    </p>
                                                                                </div>
                                                                                <div
                                                                                    class="mb-3 viewmoreivmain flex gap-3">
                                                                                    <a href="#"
                                                                                        class="text-gray-500 text-sm font-semibold">View
                                                                                        details</a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="packcardright">
                                                                                <div class="selectedinputdiv">
                                                                                    <div
                                                                                        class="selectednumbox bg-pink text-white text-center pt-3 pb-6 px-8 rounded-lg">
                                                                                        <h2
                                                                                            class="font-bold text-4xl mb-2">
                                                                                            2</h2>
                                                                                        <p class="uppercase">bathroom
                                                                                        </p>
                                                                                    </div>
                                                                                    <div
                                                                                        class="flex items-center shadow rounded-md w-fit mx-auto inptdiv bg-white mt-min-15px">
                                                                                        <!-- Minus Button -->
                                                                                        <button type="button"
                                                                                            class="px-3 py-2 focus:outline-none"
                                                                                            onclick="decreaseQty()">
                                                                                            −
                                                                                        </button>

                                                                                        <!-- Quantity Input -->
                                                                                        <input type="number"
                                                                                            id="qtyInput" value="1"
                                                                                            min="1"
                                                                                            class="w-16 text-center py-2 border-none" />

                                                                                        <!-- Plus Button -->
                                                                                        <button type="button"
                                                                                            class="px-3 py-2 focus:outline-none"
                                                                                            onclick="increaseQty()">
                                                                                            +
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="packegescard p-5 rounded-2xl">
                                                                        <div class="flex gap-3 justify-between w-full flex-col sm:flex-row">
                                                                            <div class="packcardleft">
                                                                                <h5 class="text-xl font-semibold mb-3">
                                                                                    Classic cleaning (2 bathrooms)
                                                                                </h5>
                                                                                <div
                                                                                    class="mb-3 reviewdivcard flex gap-3 items-center">
                                                                                    <i class="fa-solid fa-star"></i>
                                                                                    <p class="text-gray-500">4.383 (1.2M
                                                                                        reviews)</p>
                                                                                </div>
                                                                                <div
                                                                                    class="mb-3 pricedivmain flex gap-3">
                                                                                    <p class="pink-txt">₹785</p>
                                                                                    <p
                                                                                        class="text-gray-500 line-through">
                                                                                        ₹858</p>
                                                                                    <p class="text-gray-500 ">· 2 hrs
                                                                                    </p>
                                                                                </div>
                                                                                <div
                                                                                    class="mb-3 viewmoreivmain flex gap-3">
                                                                                    <a href="#"
                                                                                        class="text-gray-500 text-sm font-semibold">View
                                                                                        details</a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="packcardright">
                                                                                <div class="selectedinputdiv">
                                                                                    <div
                                                                                        class="selectednumbox bg-pink text-white text-center pt-3 pb-6 px-8 rounded-lg">
                                                                                        <h2
                                                                                            class="font-bold text-4xl mb-2">
                                                                                            2</h2>
                                                                                        <p class="uppercase">bathroom
                                                                                        </p>
                                                                                    </div>
                                                                                    <div
                                                                                        class="flex items-center shadow rounded-md w-fit mx-auto inptdiv bg-white mt-min-15px">
                                                                                        <!-- Minus Button -->
                                                                                        <button type="button"
                                                                                            class="px-3 py-2 focus:outline-none"
                                                                                            onclick="decreaseQty()">
                                                                                            −
                                                                                        </button>

                                                                                        <!-- Quantity Input -->
                                                                                        <input type="number"
                                                                                            id="qtyInput" value="1"
                                                                                            min="1"
                                                                                            class="w-16 text-center py-2 border-none" />

                                                                                        <!-- Plus Button -->
                                                                                        <button type="button"
                                                                                            class="px-3 py-2 focus:outline-none"
                                                                                            onclick="increaseQty()">
                                                                                            +
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="packegescard p-5 rounded-2xl">
                                                                        <div class="flex gap-3 justify-between w-full flex-col sm:flex-row">
                                                                            <div class="packcardleft">
                                                                                <h5 class="text-xl font-semibold mb-3">
                                                                                    Classic cleaning (2 bathrooms)
                                                                                </h5>
                                                                                <div
                                                                                    class="mb-3 reviewdivcard flex gap-3 items-center">
                                                                                    <i class="fa-solid fa-star"></i>
                                                                                    <p class="text-gray-500">4.383 (1.2M
                                                                                        reviews)</p>
                                                                                </div>
                                                                                <div
                                                                                    class="mb-3 pricedivmain flex gap-3">
                                                                                    <p class="pink-txt">₹785</p>
                                                                                    <p
                                                                                        class="text-gray-500 line-through">
                                                                                        ₹858</p>
                                                                                    <p class="text-gray-500 ">· 2 hrs
                                                                                    </p>
                                                                                </div>
                                                                                <div
                                                                                    class="mb-3 viewmoreivmain flex gap-3">
                                                                                    <a href="#"
                                                                                        class="text-gray-500 text-sm font-semibold">View
                                                                                        details</a>
                                                                                </div>
                                                                            </div>
                                                                            <div class="packcardright">
                                                                                <div class="selectedinputdiv">
                                                                                    <div
                                                                                        class="selectednumbox bg-pink text-white text-center pt-3 pb-6 px-8 rounded-lg">
                                                                                        <h2
                                                                                            class="font-bold text-4xl mb-2">
                                                                                            2</h2>
                                                                                        <p class="uppercase">bathroom
                                                                                        </p>
                                                                                    </div>
                                                                                    <div
                                                                                        class="flex items-center shadow rounded-md w-fit mx-auto inptdiv bg-white mt-min-15px">
                                                                                        <!-- Minus Button -->
                                                                                        <button type="button"
                                                                                            class="px-3 py-2 focus:outline-none"
                                                                                            onclick="decreaseQty()">
                                                                                            −
                                                                                        </button>

                                                                                        <!-- Quantity Input -->
                                                                                        <input type="number"
                                                                                            id="qtyInput" value="1"
                                                                                            min="1"
                                                                                            class="w-16 text-center py-2 border-none" />

                                                                                        <!-- Plus Button -->
                                                                                        <button type="button"
                                                                                            class="px-3 py-2 focus:outline-none"
                                                                                            onclick="increaseQty()">
                                                                                            +
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="basis-3/3 md:basis-1/3">
                                                        <div
                                                            class=" sticky top-32">
                                                            <div class="cartcardmain calccardspacemini00 faqcustshadow p-5 rounded-lg">
                                                                <div class="cartdiv">
                                                                    <h5 class="text-2xl pink-txt font-bold mb-5">
                                                                        Cart
                                                                    </h5>
                                                                    <div class="cartlistdiv flex flex-col gap-3">
                                                                        <div class="cartlistcard">
                                                                            <div
                                                                                class="flex justify-between gap-3 items-center">
                                                                                <p class="text-lg">Classic cleaning
                                                                                    (2 bathrooms)</p>
                                                                                <div
                                                                                    class="flex items-center w-fit mx-auto shadow-lg inptdiv bg-white border-pink rounded-md">
                                                                                    <!-- Minus Button -->
                                                                                    <button type="button"
                                                                                        class="px-3 py-2 focus:outline-none"
                                                                                        onclick="decreaseQty()">
                                                                                        −
                                                                                    </button>

                                                                                    <!-- Quantity Input -->
                                                                                    <input type="number" id="qtyInput"
                                                                                        value="1" min="1"
                                                                                        class="w-16 text-center py-2 border-none" />

                                                                                    <!-- Plus Button -->
                                                                                    <button type="button"
                                                                                        class="px-3 py-2 focus:outline-none"
                                                                                        onclick="increaseQty()">
                                                                                        +
                                                                                    </button>
                                                                                </div>
                                                                                <div
                                                                                    class="mb-3 pricedivmain flex-col items-start flex ">
                                                                                    <p class="pink-txt">₹785</p>
                                                                                    <p
                                                                                        class="text-gray-500 line-through">
                                                                                        ₹858</p>
                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                        <div class="cartlistcard">
                                                                            <div
                                                                                class="flex justify-between gap-3 items-center">
                                                                                <p class="text-lg">Classic cleaning
                                                                                    (2 bathrooms)</p>
                                                                                <div
                                                                                    class="flex items-center w-fit mx-auto shadow-lg inptdiv bg-white border-pink rounded-md">
                                                                                    <!-- Minus Button -->
                                                                                    <button type="button"
                                                                                        class="px-3 py-2 focus:outline-none"
                                                                                        onclick="decreaseQty()">
                                                                                        −
                                                                                    </button>

                                                                                    <!-- Quantity Input -->
                                                                                    <input type="number" id="qtyInput"
                                                                                        value="1" min="1"
                                                                                        class="w-16 text-center py-2 border-none" />

                                                                                    <!-- Plus Button -->
                                                                                    <button type="button"
                                                                                        class="px-3 py-2 focus:outline-none"
                                                                                        onclick="increaseQty()">
                                                                                        +
                                                                                    </button>
                                                                                </div>
                                                                                <div
                                                                                    class="mb-3 pricedivmain flex-col items-start flex ">
                                                                                    <p class="pink-txt">₹785</p>
                                                                                    <p
                                                                                        class="text-gray-500 line-through">
                                                                                        ₹858</p>
                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                        <div class="cartlistcard">
                                                                            <div
                                                                                class="flex justify-between gap-3 items-center">
                                                                                <p class="text-lg">Classic cleaning
                                                                                    (2 bathrooms)</p>
                                                                                <div
                                                                                    class="flex items-center w-fit mx-auto shadow-lg inptdiv bg-white border-pink rounded-md">
                                                                                    <!-- Minus Button -->
                                                                                    <button type="button"
                                                                                        class="px-3 py-2 focus:outline-none"
                                                                                        onclick="decreaseQty()">
                                                                                        −
                                                                                    </button>

                                                                                    <!-- Quantity Input -->
                                                                                    <input type="number" id="qtyInput"
                                                                                        value="1" min="1"
                                                                                        class="w-16 text-center py-2 border-none" />

                                                                                    <!-- Plus Button -->
                                                                                    <button type="button"
                                                                                        class="px-3 py-2 focus:outline-none"
                                                                                        onclick="increaseQty()">
                                                                                        +
                                                                                    </button>
                                                                                </div>
                                                                                <div
                                                                                    class="mb-3 pricedivmain flex-col items-start flex ">
                                                                                    <p class="pink-txt">₹785</p>
                                                                                    <p
                                                                                        class="text-gray-500 line-through">
                                                                                        ₹858</p>
                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                        <div class="cartvietotldiv bg-pink-100 rounded-xl px-4 py-3">
                                                                            <div class="flex justify-between items-center">
                                                                                <div
                                                                                    class="pricedivmain items-start flex gap-3 items-center">
                                                                                    <p class="pink-txt text-lg font-bold">₹2000</p>
                                                                                    <p class="text-gray-500 line-through">
                                                                                        ₹2600</p>
                                                                                </div>
                                                                                <a href="" class="viewcaartbtn font-semibold">View Cart</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div
                                                                class="calccardspacemini00 faqcustshadow p-5 rounded-lg mt-8">
                                                                <div class="offerscardss">
                                                                    <div class="dicmain flex  gap-2">
                                                                        <div class="discounticonimgdiv bg-gray-100 p-3 rounded-md">
                                                                            <img src="assets/images/calculator/discounticon.png"
                                                                                alt="Interior Painting" width=""
                                                                                class="w-full max-w-full h-auto" />
                                                                        </div> 
                                                                        <div class="textdiv">
                                                                            <p class="font-semibold">Assured reward from CRED</p>
                                                                            <p class="text-gray-500">Reward via online payment</p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="viewmoredisc mt-3">
                                                                        <a href="" class="viewmoredesc pink-txt font-semibold">
                                                                            View More Offers <i class="fa-solid fa-angle-down ms-1"></i>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="max-w-6xl mx-auto"></div>
        </div>
        <section id="faq" class="px-4 pt-100">
            <div class="container mx-auto">
              <h2 class="text-center font-bold mb-5">FAQs</h2>
              <div class="accordion flex flex-col items-center justify-center">
                <!--  Panel 1  -->
                <div class="w-full lg:w-1/2 shadow11 mb-4">
                  <input type="checkbox" name="panel" id="panel-1" class="hidden" />
                  <label for="panel-1" class="relative block bg-white text-black p-4 rounded-2xl">Questions text goes
                    here</label>
                  <div class="accordion__content overflow-hidden">
                    <p class="accordion__body p-4 text-black" id="panel1">
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting industry. Lorem Ipsum has been the industry's
                      standard dummy text ever since the 1500s, when an unknown
                      printer took a galley of type and scrambled it to make a
                      type specimen.
                    </p>
                  </div>
                </div>
                <!--  Panel 2  -->
                <div class="w-full lg:w-1/2 shadow11 mb-4">
                  <input type="checkbox" name="panel" id="panel-2" class="hidden" />
                  <label for="panel-2" class="relative block bg-white text-black p-4 rounded-2xl">Questions text goes
                    here</label>
                  <div class="accordion__content overflow-hidden">
                    <p class="accordion__body p-4 text-black" id="panel1">
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                      Iusto possimus at a cum saepe molestias modi illo facere
                      ducimus voluptatibus praesentium deleniti fugiat ab error
                      quia sit perspiciatis velit necessitatibus.Lorem ipsum dolor
                      sit amet, consectetur adipisicing elit. Lorem ipsum dolor
                      sit amet.
                    </p>
                  </div>
                </div>
                <!--  Panel 3  -->
                <div class="w-full lg:w-1/2 shadow11 mb-4">
                  <input type="checkbox" name="panel" id="panel-3" class="hidden" />
                  <label for="panel-3" class="relative block bg-white text-black p-4 rounded-2xl">Questions text goes
                    here</label>
                  <div class="accordion__content overflow-hidden">
                    <p class="accordion__body p-4 text-black" id="panel1">
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                      Iusto possimus at a cum saepe molestias modi illo facere
                      ducimus voluptatibus praesentium deleniti fugiat ab error
                      quia sit perspiciatis velit necessitatibus.Lorem ipsum dolor
                      sit amet, consectetur adipisicing elit. Lorem ipsum dolor
                      sit amet.
                    </p>
                  </div>
                </div>
                <!--  Panel 4  -->
                <div class="w-full lg:w-1/2 shadow11 mb-4">
                  <input type="checkbox" name="panel" id="panel-4" class="hidden" />
                  <label for="panel-4" class="relative block bg-white text-black p-4 rounded-2xl">Questions text goes
                    here</label>
                  <div class="accordion__content overflow-hidden">
                    <p class="accordion__body p-4 text-black" id="panel1">
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                      Iusto possimus at a cum saepe molestias modi illo facere
                      ducimus voluptatibus praesentium deleniti fugiat ab error
                      quia sit perspiciatis velit necessitatibus.Lorem ipsum dolor
                      sit amet, consectetur adipisicing elit. Lorem ipsum dolor
                      sit amet.
                    </p>
                  </div>
                </div>
                <!--  Panel 5  -->
                <div class="w-full lg:w-1/2 shadow11 mb-4">
                  <input type="checkbox" name="panel" id="panel-5" class="hidden" />
                  <label for="panel-5" class="relative block bg-white text-black p-4 rounded-2xl">Questions text goes
                    here</label>
                  <div class="accordion__content overflow-hidden">
                    <p class="accordion__body p-4 text-black" id="panel1">
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                      Iusto possimus at a cum saepe molestias modi illo facere
                      ducimus voluptatibus praesentium deleniti fugiat ab error
                      quia sit perspiciatis velit necessitatibus.Lorem ipsum dolor
                      sit amet, consectetur adipisicing elit. Lorem ipsum dolor
                      sit amet.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>
    </section>
    
    <!-- service Post section end -->
</template>

<style scoped>
    @import "../assets/css/service.css";
</style>