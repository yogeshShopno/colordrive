<script></script>

<template>
  <!-- main banner start -->
  <section
    id="blog-new"
    class="py-100 px-3 mb-50px"
    data-v-inspector="app/pages/blog.vue:5:3"
    data-v-1bac7c7d=""
  >
    <div
      class="container mx-auto"
      data-v-inspector="app/pages/blog.vue:6:5"
      data-v-1bac7c7d=""
    >
      <!-- <h1>Blog</h1> -->
      <div class="text-center">
        <h2 class="text font-bold">Wall Texture Painting Designs</h2>
        <div class="flex items-center justify-center gap-2">
          <a href="/texturepaint"> <p>Home</p></a>
          <i class="fa-solid fa-chevron-right" style="color: #000000"></i>
          <p class="pink-txt">Texture Name</p>
        </div>
      </div>
    </div>
  </section>
  <!-- main banner end -->

  <!-- service Post section start -->
  <section id="service-post" class="pb-200 mt-50px px-4 px-md-0">
    <div class="container mx-auto">
      <div class="mx-auto">
        <div class="firstsecdiv">
          <div class="tecctdiv">
            <div>
              <form action="" method="post">
                <div
                  class="flex items-center flex-col sm:flex-row justify-between gap-4"
                >
                  <div
                    class="flex gap-4 basis-3/3 sm:basis-2/3 flex-col sm:flex-row w-full"
                  >
                    <div class="basis-1/3 sm:basis-1/3">
                      <div class="grid grid-cols-1">
                        <select
                          id="country"
                          name="country"
                          autocomplete="country-name"
                          class="col-start-1 row-start-1 w-full appearance-none rounded-md custsselect py-2.5 pl-3 pr-8 text-base text-gray-700 sm:text-sm/6"
                        >
                          <option>Category</option>
                          <option>United States</option>
                          <option>Canada</option>
                          <option>Mexico</option>
                        </select>
                        <svg
                          class="pointer-events-none col-start-1 row-start-1 mr-2 size-5 self-center justify-self-end text-gray-500 sm:size-4"
                          viewBox="0 0 16 16"
                          fill="currentColor"
                          aria-hidden="true"
                          data-slot="icon"
                        >
                          <path
                            fill-rule="evenodd"
                            d="M4.22 6.22a.75.75 0 0 1 1.06 0L8 8.94l2.72-2.72a.75.75 0 1 1 1.06 1.06l-3.25 3.25a.75.75 0 0 1-1.06 0L4.22 7.28a.75.75 0 0 1 0-1.06Z"
                            clip-rule="evenodd"
                          />
                        </svg>
                      </div>
                    </div>
                    <!-- Dropdown 2 -->
                    <div class="basis-1/3 sm:basis-1/3">
                      <div class="grid grid-cols-1">
                        <select
                          id="country"
                          name="country"
                          autocomplete="country-name"
                          class="col-start-1 row-start-1 w-full appearance-none rounded-md custsselect py-2.5 pl-3 pr-8 text-base text-gray-700 sm:text-sm/6"
                        >
                          <option>Best For</option>
                          <option>United States</option>
                          <option>Canada</option>
                          <option>Mexico</option>
                        </select>
                        <svg
                          class="pointer-events-none col-start-1 row-start-1 mr-2 size-5 self-center justify-self-end text-gray-500 sm:size-4"
                          viewBox="0 0 16 16"
                          fill="currentColor"
                          aria-hidden="true"
                          data-slot="icon"
                        >
                          <path
                            fill-rule="evenodd"
                            d="M4.22 6.22a.75.75 0 0 1 1.06 0L8 8.94l2.72-2.72a.75.75 0 1 1 1.06 1.06l-3.25 3.25a.75.75 0 0 1-1.06 0L4.22 7.28a.75.75 0 0 1 0-1.06Z"
                            clip-rule="evenodd"
                          />
                        </svg>
                      </div>
                    </div>
                    <div class="basis-3/3 sm:basis-1/3">
                      <div class="flex-grow relative">
                        <input
                          type="text"
                          placeholder="Search By Design Name"
                          class="w-full px-4 py-2 w-full w-full appearance-none rounded-md custsselect py-2.5 pl-3 pr-8 text-base text-gray-700 sm:text-sm/6"
                        />
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          class="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400"
                          viewBox="0 0 20 20"
                          fill="currentColor"
                        >
                          <path
                            fill-rule="evenodd"
                            d="M12.9 14.32a8 8 0 111.414-1.414l3.387 3.386a1 1 0 01-1.415 1.415l-3.386-3.387zM8 14a6 6 0 100-12 6 6 0 000 12z"
                            clip-rule="evenodd"
                          />
                        </svg>
                      </div>
                    </div>
                    <!-- Search Input -->
                  </div>

                  <!-- Icons -->
                  <div
                    class="flex items-center sm:basis-1/3 justify-end w-full gap-4"
                  >
                    <button
                      class="p-2 text-gray-500 rounded-lg hover:bg-pink-100 focus:ring-2 focus:ring-blue-500"
                    >
                      <i class="fa-solid fa-arrows-rotate"></i>
                    </button>
                    <button
                      class="p-2 text-gray-500 rounded-lg hover:bg-pink-100 focus:ring-2 focus:ring-blue-500"
                    >
                      <svg
                        width="20"
                        height="20"
                        viewBox="0 0 29 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M9.00922 0C7.40367 0 6.03894 1.08375 5.59742 2.56889H1.94478C1.38283 2.56889 0.981445 3.01042 0.981445 3.57236C0.981445 4.1343 1.42297 4.57583 1.98492 4.57583H5.63756C6.03894 6.06097 7.4438 7.14472 9.04936 7.14472C10.6951 7.14472 12.0598 6.06097 12.5013 4.57583H27.3126C27.8745 4.57583 28.316 4.1343 28.316 3.57236C28.316 3.01042 27.8745 2.56889 27.3126 2.56889H12.5013C12.0196 1.08375 10.6549 0 9.00922 0ZM9.04936 2.00694C9.89228 2.00694 10.6148 2.68931 10.6148 3.57236C10.6148 4.45542 9.89228 5.13778 9.04936 5.13778C8.20644 5.13778 7.48394 4.45542 7.48394 3.57236C7.48394 2.68931 8.20644 2.00694 9.04936 2.00694Z"
                          fill="#6A6D70"
                        />
                        <path
                          d="M21.091 8.02344C19.4855 8.02344 18.1207 9.10719 17.6792 10.5923H1.98492C1.38283 10.5923 0.981445 11.0339 0.981445 11.5958C0.981445 12.1577 1.42297 12.5993 1.98492 12.5993H17.6792C18.0806 14.0844 19.4855 15.1682 21.091 15.1682C22.7367 15.1682 24.1014 14.0844 24.543 12.5993H27.3126C27.8745 12.5993 28.316 12.1577 28.316 11.5958C28.316 11.0339 27.8745 10.5923 27.3126 10.5923H24.543C24.1014 9.10719 22.7367 8.02344 21.091 8.02344ZM21.1312 10.0304C21.9741 10.0304 22.6966 10.7127 22.6966 11.5958C22.6966 12.4789 21.9741 13.1612 21.1312 13.1612C20.2882 13.1612 19.5657 12.4789 19.5657 11.5958C19.5657 10.7127 20.2481 10.0304 21.1312 10.0304Z"
                          fill="#6A6D70"
                        />
                        <path
                          d="M13.8259 16.8516C12.2203 16.8516 10.8556 17.9353 10.4141 19.4205H1.98492C1.38283 19.4205 0.981445 19.862 0.981445 20.4239C0.981445 20.9859 1.42297 21.4274 1.98492 21.4274H10.4542C10.8556 22.9125 12.2605 23.9963 13.866 23.9963C15.5117 23.9963 16.8764 22.9125 17.318 21.4274H27.3126C27.8745 21.4274 28.316 20.9859 28.316 20.4239C28.316 19.862 27.8745 19.4205 27.3126 19.4205H17.2778C16.8363 17.9353 15.4716 16.8516 13.8259 16.8516ZM13.866 18.8585C14.7089 18.8585 15.4314 19.5409 15.4314 20.4239C15.4314 21.307 14.7089 21.9893 13.866 21.9893C13.0231 21.9893 12.3006 21.307 12.3006 20.4239C12.3407 19.5409 13.0231 18.8585 13.866 18.8585Z"
                          fill="#6A6D70"
                        />
                      </svg>
                    </button>
                  </div>
                </div>
                <div class="colorfilterdiv mt-8 overflow-x-auto">
                  <div
                    class="flex space-x-5 items-center justify-start md:justify-center px-4"
                  >
                    <!-- Color Option -->
                    <div class="flex flex-col items-center">
                      <div
                        class="w-10 h-10 rounded-full bg-pink-500 hover:shadow-md"
                      ></div>
                      <span class="text-sm text-gray-900 mt-2">All</span>
                    </div>

                    <!-- Red -->
                    <div class="flex flex-col items-center">
                      <div
                        class="w-10 h-10 rounded-full bg-red-600 hover:shadow-md"
                      ></div>
                      <span class="text-sm text-gray-900 mt-2">Red</span>
                    </div>

                    <!-- Green -->
                    <div class="flex flex-col items-center">
                      <div
                        class="w-10 h-10 rounded-full bg-green-600 hover:shadow-md"
                      ></div>
                      <span class="text-sm text-gray-900 mt-2">Green</span>
                    </div>

                    <!-- Blue -->
                    <div class="flex flex-col items-center">
                      <div
                        class="w-10 h-10 rounded-full bg-blue-400 hover:shadow-md"
                      ></div>
                      <span class="text-sm text-gray-900 mt-2">Blue</span>
                    </div>

                    <!-- Pastel -->
                    <div class="flex flex-col items-center">
                      <div
                        class="w-10 h-10 rounded-full bg-rose-200 hover:shadow-md"
                      ></div>
                      <span class="text-sm text-gray-900 mt-2">Pastel</span>
                    </div>

                    <!-- Yellow -->
                    <div class="flex flex-col items-center">
                      <div
                        class="w-10 h-10 rounded-full bg-yellow-400 hover:shadow-md"
                      ></div>
                      <span class="text-sm text-gray-900 mt-2">Yellow</span>
                    </div>

                    <!-- Gray -->
                    <div class="flex flex-col items-center">
                      <div
                        class="w-10 h-10 rounded-full bg-gray-400 hover:shadow-md"
                      ></div>
                      <span class="text-sm text-gray-900 mt-2">Gray</span>
                    </div>

                    <!-- Purple -->
                    <div class="flex flex-col items-center">
                      <div
                        class="w-10 h-10 rounded-full bg-purple-500 hover:shadow-md"
                      ></div>
                      <span class="text-sm text-gray-900 mt-2">Purple</span>
                    </div>

                    <!-- Brown -->
                    <div class="flex flex-col items-center">
                      <div
                        class="w-10 h-10 rounded-full bg-amber-900 hover:shadow-md"
                      ></div>
                      <span class="text-sm text-gray-900 mt-2">Brown</span>
                    </div>

                    <!-- Pink -->
                    <div class="flex flex-col items-center">
                      <div
                        class="w-10 h-10 rounded-full bg-pink-300 hover:shadow-md"
                      ></div>
                      <span class="text-sm text-gray-900 mt-2">Pink</span>
                    </div>

                    <!-- Orange -->
                    <div class="flex flex-col items-center">
                      <div
                        class="w-10 h-10 rounded-full bg-orange-400 hover:shadow-md"
                      ></div>
                      <span class="text-sm text-gray-900 mt-2">Orange</span>
                    </div>

                    <!-- Beige -->
                    <div class="flex flex-col items-center">
                      <div
                        class="w-10 h-10 rounded-full bg-yellow-100 hover:shadow-md"
                      ></div>
                      <span class="text-sm text-gray-900 mt-2">Beige</span>
                    </div>
                  </div>
                </div>
              </form>

              <div class="calcseccardsdiv mt-50px">
                <div class="calcspace">
                  <!-- <div class="calccardtitle mb-3">
                                        <h5 class="font-bold">Select Painting Service Type</h5>
                                    </div> -->
                  <div class="calccardspacemini mb-2">
                    <div
                      class="grid grid-cols- sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4"
                    >
                      <div class="row-span-612">
                        <div
                          class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl"
                        >
                          <div class="imgcalcdivv border-none">
                            <img
                              src="assets/images/calculator/prod1.png"
                              alt="Interior Painting"
                              width=""
                              class="max-w-full w-full h-auto"
                            />
                          </div>
                          <div class="lablediv p-3">
                            <h5 class="text-xl font-bold">
                              Delta - Royale Play Metallic
                            </h5>
                            <div
                              class="flex justify-between items-center mt-3 h-10"
                            >
                              <div class="pricediv">
                                <p class="text-gray-500 font-semibold">
                                  *₹ 70/SqFt
                                </p>
                              </div>
                              <div class="btnviewsdiv">
                                <a
                                  href="/productpage"
                                  id=" "
                                  class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                                >
                                  View Details
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-612">
                        <div
                          class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl"
                        >
                          <div class="imgcalcdivv border-none">
                            <img
                              src="assets/images/calculator/prod2.png"
                              alt="Interior Painting"
                              width=""
                              class="max-w-full w-full h-auto"
                            />
                          </div>
                          <div class="lablediv p-3">
                            <h5 class="text-xl font-bold">
                              Delta - Royale Play Metallic
                            </h5>
                            <div
                              class="flex justify-between items-center mt-3 h-10"
                            >
                              <div class="pricediv">
                                <p class="text-gray-500 font-semibold">
                                  *₹ 70/SqFt
                                </p>
                              </div>
                              <div class="btnviewsdiv">
                                <a
                                  href="/productpage"
                                  id=" "
                                  class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                                >
                                  View Details
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-612">
                        <div
                          class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl"
                        >
                          <div class="imgcalcdivv border-none">
                            <img
                              src="assets/images/calculator/prod3.png"
                              alt="Interior Painting"
                              width=""
                              class="max-w-full w-full h-auto"
                            />
                          </div>
                          <div class="lablediv p-3">
                            <h5 class="text-xl font-bold">
                              Delta - Royale Play Metallic
                            </h5>
                            <div
                              class="flex justify-between items-center mt-3 h-10"
                            >
                              <div class="pricediv">
                                <p class="text-gray-500 font-semibold">
                                  *₹ 70/SqFt
                                </p>
                              </div>
                              <div class="btnviewsdiv">
                                <a
                                  href="/productpage"
                                  id=" "
                                  class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                                >
                                  View Details
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-612">
                        <div
                          class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl"
                        >
                          <div class="imgcalcdivv border-none">
                            <img
                              src="assets/images/calculator/prod1.png"
                              alt="Interior Painting"
                              width=""
                              class="max-w-full w-full h-auto"
                            />
                          </div>
                          <div class="lablediv p-3">
                            <h5 class="text-xl font-bold">
                              Delta - Royale Play Metallic
                            </h5>
                            <div
                              class="flex justify-between items-center mt-3 h-10"
                            >
                              <div class="pricediv">
                                <p class="text-gray-500 font-semibold">
                                  *₹ 70/SqFt
                                </p>
                              </div>
                              <div class="btnviewsdiv">
                                <a
                                  href="/productpage"
                                  id=" "
                                  class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                                >
                                  View Details
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-612">
                        <div
                          class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl"
                        >
                          <div class="imgcalcdivv border-none">
                            <img
                              src="assets/images/calculator/prod2.png"
                              alt="Interior Painting"
                              width=""
                              class="max-w-full w-full h-auto"
                            />
                          </div>
                          <div class="lablediv p-3">
                            <h5 class="text-xl font-bold">
                              Delta - Royale Play Metallic
                            </h5>
                            <div
                              class="flex justify-between items-center mt-3 h-10"
                            >
                              <div class="pricediv">
                                <p class="text-gray-500 font-semibold">
                                  *₹ 70/SqFt
                                </p>
                              </div>
                              <div class="btnviewsdiv">
                                <a
                                  href="/productpage"
                                  id=" "
                                  class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                                >
                                  View Details
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-612">
                        <div
                          class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl"
                        >
                          <div class="imgcalcdivv border-none">
                            <img
                              src="assets/images/calculator/prod3.png"
                              alt="Interior Painting"
                              width=""
                              class="max-w-full w-full h-auto"
                            />
                          </div>
                          <div class="lablediv p-3">
                            <h5 class="text-xl font-bold">
                              Delta - Royale Play Metallic
                            </h5>
                            <div
                              class="flex justify-between items-center mt-3 h-10"
                            >
                              <div class="pricediv">
                                <p class="text-gray-500 font-semibold">
                                  *₹ 70/SqFt
                                </p>
                              </div>
                              <div class="btnviewsdiv">
                                <a
                                  href="/productpage"
                                  id=" "
                                  class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                                >
                                  View Details
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-612">
                        <div
                          class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl"
                        >
                          <div class="imgcalcdivv border-none">
                            <img
                              src="assets/images/calculator/prod2.png"
                              alt="Interior Painting"
                              width=""
                              class="max-w-full w-full h-auto"
                            />
                          </div>
                          <div class="lablediv p-3">
                            <h5 class="text-xl font-bold">
                              Delta - Royale Play Metallic
                            </h5>
                            <div
                              class="flex justify-between items-center mt-3 h-10"
                            >
                              <div class="pricediv">
                                <p class="text-gray-500 font-semibold">
                                  *₹ 70/SqFt
                                </p>
                              </div>
                              <div class="btnviewsdiv">
                                <a
                                  href="/productpage"
                                  id=" "
                                  class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                                >
                                  View Details
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-612">
                        <div
                          class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl"
                        >
                          <div class="imgcalcdivv border-none">
                            <img
                              src="assets/images/calculator/prod1.png"
                              alt="Interior Painting"
                              width=""
                              class="max-w-full w-full h-auto"
                            />
                          </div>
                          <div class="lablediv p-3">
                            <h5 class="text-xl font-bold">
                              Delta - Royale Play Metallic
                            </h5>
                            <div
                              class="flex justify-between items-center mt-3 h-10"
                            >
                              <div class="pricediv">
                                <p class="text-gray-500 font-semibold">
                                  *₹ 70/SqFt
                                </p>
                              </div>
                              <div class="btnviewsdiv">
                                <a
                                  href="/productpage"
                                  id=" "
                                  class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                                >
                                  View Details
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-612">
                        <div
                          class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl"
                        >
                          <div class="imgcalcdivv border-none">
                            <img
                              src="assets/images/calculator/prod1.png"
                              alt="Interior Painting"
                              width=""
                              class="max-w-full w-full h-auto"
                            />
                          </div>
                          <div class="lablediv p-3">
                            <h5 class="text-xl font-bold">
                              Delta - Royale Play Metallic
                            </h5>
                            <div
                              class="flex justify-between items-center mt-3 h-10"
                            >
                              <div class="pricediv">
                                <p class="text-gray-500 font-semibold">
                                  *₹ 70/SqFt
                                </p>
                              </div>
                              <div class="btnviewsdiv">
                                <a
                                  href="/productpage"
                                  id=" "
                                  class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                                >
                                  View Details
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-612">
                        <div
                          class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl"
                        >
                          <div class="imgcalcdivv border-none">
                            <img
                              src="assets/images/calculator/prod2.png"
                              alt="Interior Painting"
                              width=""
                              class="max-w-full w-full h-auto"
                            />
                          </div>
                          <div class="lablediv p-3">
                            <h5 class="text-xl font-bold">
                              Delta - Royale Play Metallic
                            </h5>
                            <div
                              class="flex justify-between items-center mt-3 h-10"
                            >
                              <div class="pricediv">
                                <p class="text-gray-500 font-semibold">
                                  *₹ 70/SqFt
                                </p>
                              </div>
                              <div class="btnviewsdiv">
                                <a
                                  href="/productpage"
                                  id=" "
                                  class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                                >
                                  View Details
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-612">
                        <div
                          class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl"
                        >
                          <div class="imgcalcdivv border-none">
                            <img
                              src="assets/images/calculator/prod3.png"
                              alt="Interior Painting"
                              width=""
                              class="max-w-full w-full h-auto"
                            />
                          </div>
                          <div class="lablediv p-3">
                            <h5 class="text-xl font-bold">
                              Delta - Royale Play Metallic
                            </h5>
                            <div
                              class="flex justify-between items-center mt-3 h-10"
                            >
                              <div class="pricediv">
                                <p class="text-gray-500 font-semibold">
                                  *₹ 70/SqFt
                                </p>
                              </div>
                              <div class="btnviewsdiv">
                                <a
                                  href="/productpage"
                                  id=" "
                                  class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                                >
                                  View Details
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-612">
                        <div
                          class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl"
                        >
                          <div class="imgcalcdivv border-none">
                            <img
                              src="assets/images/calculator/prod1.png"
                              alt="Interior Painting"
                              width=""
                              class="max-w-full w-full h-auto"
                            />
                          </div>
                          <div class="lablediv p-3">
                            <h5 class="text-xl font-bold">
                              Delta - Royale Play Metallic
                            </h5>
                            <div
                              class="flex justify-between items-center mt-3 h-10"
                            >
                              <div class="pricediv">
                                <p class="text-gray-500 font-semibold">
                                  *₹ 70/SqFt
                                </p>
                              </div>
                              <div class="btnviewsdiv">
                                <a
                                  href="/productpage"
                                  id=" "
                                  class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                                >
                                  View Details
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-612">
                        <div
                          class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl"
                        >
                          <div class="imgcalcdivv border-none">
                            <img
                              src="assets/images/calculator/prod2.png"
                              alt="Interior Painting"
                              width=""
                              class="max-w-full w-full h-auto"
                            />
                          </div>
                          <div class="lablediv p-3">
                            <h5 class="text-xl font-bold">
                              Delta - Royale Play Metallic
                            </h5>
                            <div
                              class="flex justify-between items-center mt-3 h-10"
                            >
                              <div class="pricediv">
                                <p class="text-gray-500 font-semibold">
                                  *₹ 70/SqFt
                                </p>
                              </div>
                              <div class="btnviewsdiv">
                                <a
                                  href="/productpage"
                                  id=" "
                                  class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                                >
                                  View Details
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-612">
                        <div
                          class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl"
                        >
                          <div class="imgcalcdivv border-none">
                            <img
                              src="assets/images/calculator/prod3.png"
                              alt="Interior Painting"
                              width=""
                              class="w-full max-w-full h-auto"
                            />
                          </div>
                          <div class="lablediv p-3">
                            <h5 class="text-xl font-bold">
                              Delta - Royale Play Metallic
                            </h5>
                            <div
                              class="flex justify-between items-center mt-3 h-10"
                            >
                              <div class="pricediv">
                                <p class="text-gray-500 font-semibold">
                                  *₹ 70/SqFt
                                </p>
                              </div>
                              <div class="btnviewsdiv">
                                <a
                                  href="/productpage"
                                  id=" "
                                  class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                                >
                                  View Details
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-6">
                        <div
                          class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl"
                        >
                          <div class="imgcalcdivv border-none">
                            <img
                              src="assets/images/calculator/prod2.png"
                              alt="Interior Painting"
                              width=""
                              class="max-w-full w-full h-auto"
                            />
                          </div>
                          <div class="lablediv p-3">
                            <h5 class="text-xl font-bold">
                              Delta - Royale Play Metallic
                            </h5>
                            <div
                              class="flex justify-between items-center mt-3 h-10"
                            >
                              <div class="pricediv">
                                <p class="text-gray-500 font-semibold">
                                  *₹ 70/SqFt
                                </p>
                              </div>
                              <div class="btnviewsdiv">
                                <a
                                  href="/productpage"
                                  id=" "
                                  class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                                >
                                  View Details
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row-span-612">
                        <div
                          class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl"
                        >
                          <div class="imgcalcdivv border-none">
                            <img
                              src="assets/images/calculator/prod1.png"
                              alt="Interior Painting"
                              width=""
                              class="max-w-full w-full h-auto"
                            />
                          </div>
                          <div class="lablediv p-3">
                            <h5 class="text-xl font-bold">
                              Delta - Royale Play Metallic
                            </h5>
                            <div
                              class="flex justify-between items-center mt-3 h-10"
                            >
                              <div class="pricediv">
                                <p class="text-gray-500 font-semibold">
                                  *₹ 70/SqFt
                                </p>
                              </div>
                              <div class="btnviewsdiv">
                                <a
                                  href="/productpage"
                                  id=" "
                                  class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                                >
                                  View Details
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="prodviewmoredivbtn mt-50px text-center">
                      <a
                        href="/calculator-2"
                        id=" "
                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none"
                      >
                        View More
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              <div class="contentdiv-filterpage">
                <div class="textcontentdiv pt-100">
                  <h2 class="font-bold text-center">
                    Top Paints Wall Texture Categories
                  </h2>
                  <div class="rowcontentdivcontent flex flex-col gap-10 mt-10">
                    <div
                      class="rowcontentdiv flex items-start flex-col sm:flex-row xl:items-center gap-4"
                    >
                      <div class="rowcontentdivimg basis-1/2">
                        <img
                          src="assets/images/calculator/contimg.png"
                          alt="Interior Painting"
                          width=""
                          class="max-w-full w-full h-auto"
                        />
                      </div>
                      <div class="rowcontentdivlable basis-1/2">
                        <h5 class="text-xl font-bold pink-txt mb-4">
                          Royale Play Infinitex Category
                        </h5>
                        <p class="text-sm text-gray-500 mt-4">
                          Royale Play Infinitex is the range of interior wall
                          texture paint.it has six special effects ranges like
                          pebbles, breeze, ripple, shale, and crossroad. All of
                          these effects would make you feel nature's lap
                          ambiance.
                        </p>
                        <p class="text-sm text-gray-500 mt-4">
                          Its water-based soluble property makes it ideal for
                          painting interior walls. Due to these features, it is
                          non-toxic, non-flammable, and odorless. It covers 8-10
                          sq. ft wall's surface in approximately one-liter
                          paint. It is available in a 1,5,20 kg bucket container
                          for use within one year from the date of manufacturing
                          shelf life. It is not suitable for painting on
                          dampness and seepage wall surfaces. This paint needs
                          almost three coats to create special effects on walls.
                          after the first coat leave the surface to dry for at
                          least 2-4 hours, then after the second coat again
                          leave it to dry for 2-4 hours thereafter final
                          coat/topcoat leaves the surface for drying 8-10 hours.
                        </p>
                      </div>
                    </div>
                    <div
                      class="rowcontentdiv flex items-start flex-col xl:items-center sm:flex-row-reverse gap-4"
                    >
                      <div class="rowcontentdivimg basis-1/2">
                        <img
                          src="assets/images/calculator/contimg2.png"
                          alt="Interior Painti32g"
                          width=""
                          class="max-w-full w-full h-auto"
                        />
                      </div>
                      <div class="rowcontentdivlable basis-1/2">
                        <h5 class="text-xl font-bold pink-txt mb-4">
                          Royale Play Neu Category
                        </h5>
                        <p class="text-sm text-gray-500 mt-4">
                          Asian Paint Royale Play Neu is a revamped version of
                          Special Effects Paint. This is a mix-match special
                          effect finish look that creates a magical feeling on
                          the walls by painting a base coat with Asian Paints
                          Royale Luxury Emulsion and Top Coat. The new version
                          includes 4 new special effects inspired by the beauty
                          of nature such as torrent, seashell, fizz, and delta
                          of painting design.
                        </p>
                        <p class="text-sm text-gray-500 mt-4">
                          Asian Paint Royale Play Neu brings youthfulness and
                          natural aesthetic touch to the surface of the walls,
                          adding a soothing, and stylish elegance to the
                          interior design of the home. Various textured nap
                          paint roller tools create special effects on the
                          surface of the walls.
                        </p>
                        <p class="text-sm text-gray-500 mt-4">
                          Asian Paint Royale Play Neu Special Effects Paint has
                          been formulated keeping in mind the characteristics of
                          a healthy and eco-friendly paint product such as
                          non-toxic, lead-free, non-flammable, odorless paint.
                        </p>
                      </div>
                    </div>
                    <div
                      class="rowcontentdiv flex items-start flex-col sm:flex-row xl:items-center gap-4"
                    >
                      <div class="rowcontentdivimg basis-1/2">
                        <img
                          src="assets/images/calculator/contimg3.png"
                          alt="Interior Painting"
                          width=""
                          class="max-w-full w-full h-auto"
                        />
                      </div>
                      <div class="rowcontentdivlable basis-1/2">
                        <h5 class="text-xl font-bold pink-txt mb-4">
                          Royale Play Metallic Category
                        </h5>
                        <p class="text-sm text-gray-500 mt-4">
                          Royale Play Metallic is a water-based interior paint.
                          It is available in a variety of shades and special
                          effect textures. You can give your wall a special
                          effect with daily needs things as texture effects such
                          as combing, spatula, crinkle in clothes, sponging,
                          dapple, weaving, canvas, color wash, brushing, and
                          ragging by using a variety of texture design tools. It
                          provides a metallic effect that creates elegant and
                          stylish effects on the wall surface.
                        </p>
                        <p class="text-sm text-gray-500 mt-4">
                          Royale Play Metallic is suitable for painting smooth
                          wall surfaces. It is best suitable for kid's room,
                          kitchen, and dining room for having features like
                          abrasion-resistant, non-flammable, non-toxic, and
                          odorless.
                        </p>
                        <p class="text-sm text-gray-500 mt-4">
                          It covers 100-175 sq. ft wall's surface for painting a
                          single coat in approximately one-liter paint. It is
                          available in a 200 ml and 1-liter bucket container for
                          use within 2 years from the date of manufacturing
                          shelf life.
                        </p>
                        <p class="text-sm text-gray-500 mt-4">
                          Paint containers should be kept away from direct
                          sunlight and excessive heat temperature. Maintain 2-4
                          hours drying duration between the application of first
                          coat and top coat paint. For best thinning stability
                          use the poured paint within 24 hours.
                        </p>
                      </div>
                    </div>
                    <div
                      class="rowcontentdiv flex items-start flex-col xl:items-center sm:flex-row-reverse gap-4"
                    >
                      <div class="rowcontentdivimg basis-1/2">
                        <img
                          src="assets/images/calculator/contimg4.png"
                          alt="Interior Painti32g"
                          width=""
                          class="max-w-full w-full h-auto"
                        />
                      </div>
                      <div class="rowcontentdivlable basis-1/2">
                        <h5 class="text-xl font-bold pink-txt mb-4">
                          Royale Play Dune Category
                        </h5>
                        <p class="text-sm text-gray-500 mt-4">
                          Royale Play Metallic is a water-based interior paint.
                          It is available in a variety of shades and special
                          effect textures. You can give your wall a special
                          effect with daily needs things as texture effects such
                          as combing, spatula, crinkle in clothes, sponging,
                          dapple, weaving, canvas, color wash, brushing, and
                          ragging by using a variety of texture design tools. It
                          provides a metallic effect that creates elegant and
                          stylish effects on the wall surface.As the name
                          suggests Royale play dune is inspired by the Namib
                          Desert Mountain Range of Africa. A dune is a landform
                          composed of wind- or water-driven sand. It typically
                          takes the form of a mound, ridge, or hill. Therefore
                          this theme of paint collection consists of silver and
                          gold metallic pigments that leave sand dunes texture
                          impact on the painted wall surface.
                        </p>
                        <p class="text-sm text-gray-500 mt-4">
                          You can decorate interior walls by using various
                          painting tools to create special effects such as Halo,
                          Drizzle, and Whirl texture, and enjoy the elegant and
                          stylish look of interior walls.
                        </p>
                        <p class="text-sm text-gray-500 mt-4">
                          Royale play dune is available in six natural color
                          shades: amalgam, bronzer, firebrand, black and
                          ferment, and medallion introducing the impact of
                          vibrant colors of sand dune and deserts of the African
                          continent to your home walls.
                        </p>
                        <p class="text-sm text-gray-500 mt-4">
                          This paint is available in a 1-liter pack. Paint
                          containers should be kept away from direct sunlight
                          and excessive heat temperature. Depending on the
                          humidity in the weather, it is advisable to maintain a
                          time interval of about 24 hours between the first
                          coating of the paints and the final coating.
                        </p>
                      </div>
                    </div>
                    <div
                      class="rowcontentdiv flex items-start flex-col sm:flex-row xl:items-center gap-4"
                    >
                      <div class="rowcontentdivimg basis-1/2">
                        <img
                          src="assets/images/calculator/contimg5.png"
                          alt="Interior Painting"
                          width=""
                          class="max-w-full w-full h-auto"
                        />
                      </div>
                      <div class="rowcontentdivlable basis-1/2">
                        <h5 class="text-xl font-bold pink-txt mb-4">
                          Royale Play Stucco Category
                        </h5>
                        <p class="text-sm text-gray-500 mt-4">
                          Royale Play stucco is a lime-based plaster-like paint.
                          It is inspired by various stone themes. If you have
                          the desire to create a marble finish look on the
                          interior wall surface, then no need to spend money on
                          marbles, Asian royale play stucco designer paint is
                          the right choice.
                        </p>
                        <p class="text-sm text-gray-500 mt-4">
                          It is available in five colors of marble and other
                          stone surfaces like shades such as igneous, slate,
                          cobbled, and quartz with features of high sheen marble
                          finish and easily washable performance. It is best for
                          a high-useability area like a kid's room, kitchen, or
                          dining room as the stains and dust are easily
                          removable with a dry cloth or sponge.
                        </p>
                        <p class="text-sm text-gray-500 mt-4">
                          A variety of painting tools is used to create special
                          effects on marble and other stone surfaces with a high
                          sheen smooth finish look.
                        </p>
                        <p class="text-sm text-gray-500 mt-4">
                          Asian paints royale play stucco is environment
                          friendly with non-toxic, lead-free, non-flammable, and
                          odorless.
                        </p>
                        <p class="text-sm text-gray-500 mt-4">
                          Royale Play Stucco is available in 1 and 5 kg packs.
                          Paint containers should be kept away from direct
                          sunlight and excessive heat temperature.
                        </p>
                        <p class="text-sm text-gray-500 mt-4">
                          To create the marble finish effect, royale paint
                          stucco needs three coats of paint. After the first
                          coat of paint leaves the wall surface for 4- 6 hours
                          to fully dry, recoat the second coat by leaving the
                          surface dry for 1-2 hours, and then recoat the third
                          and final coat of paint which will take approximately
                          half an hour to dry depending on the humidity in the
                          weather.
                        </p>
                      </div>
                    </div>
                  </div>
                  <hr class="my-10" />
                  <div class="contentpara">
                    <h5 class="font-semibold pink-txt">
                      Royale Play Safari Category
                    </h5>
                    <p class="text-sm text-gray-500 mt-3">
                      Asian paint royale play safari is inspired by the theme of
                      an epic expanse of plains, grassland of Africa, An
                      expedition to observe the rare dotted skin animals,
                      rainstorm, waves of oceans, hailstorms, a rainstorm of
                      natures originality.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      So as the name of the paint suggests, Asian Paint Royal
                      play Safari is available in five special effects namely
                      Classic, Sleet, Rainstorm, Ocean wave, and Frost Form.
                      This paint has coarse particles of gold and silver paint
                      to add to the pigmented texture effect of the natural
                      safari theme.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      It takes about one liter of paint to cover 40-60 square
                      feet of well-prepared smooth wall surface to paint a
                      single coat. It is available in 1-liter containers for use
                      within 2 years from the date of manufacture's shelf life.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      The pre-painting process involves cleaning and curing a
                      fresh masonry surface and for best results, it is
                      necessary to allow the surface to dry for 2 to 4 days
                      before applying Royale Play Safari Paint. Being an
                      environmentally safe water-based paint, it is free from a
                      mixture of lead, mercury, and chromium compounds. It is
                      non-flammable, non-toxic, and odorless.
                    </p>
                  </div>
                  <hr class="my-10" />
                  <div class="contentpara">
                    <h5 class="font-semibold pink-txt">
                      Royale Play Safari Category
                    </h5>
                    <p class="text-sm text-gray-500 mt-3">
                      Asian paint royale play safari is inspired by the theme of
                      an epic expanse of plains, grassland of Africa, An
                      expedition to observe the rare dotted skin animals,
                      rainstorm, waves of oceans, hailstorms, a rainstorm of
                      natures originality.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      So as the name of the paint suggests, Asian Paint Royal
                      play Safari is available in five special effects namely
                      Classic, Sleet, Rainstorm, Ocean wave, and Frost Form.
                      This paint has coarse particles of gold and silver paint
                      to add to the pigmented texture effect of the natural
                      safari theme.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      It takes about one liter of paint to cover 40-60 square
                      feet of well-prepared smooth wall surface to paint a
                      single coat. It is available in 1-liter containers for use
                      within 2 years from the date of manufacture's shelf life.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      The pre-painting process involves cleaning and curing a
                      fresh masonry surface and for best results, it is
                      necessary to allow the surface to dry for 2 to 4 days
                      before applying Royale Play Safari Paint. Being an
                      environmentally safe water-based paint, it is free from a
                      mixture of lead, mercury, and chromium compounds. It is
                      non-flammable, non-toxic, and odorless.
                    </p>
                  </div>
                  <hr class="my-10" />
                  <div class="contentpara">
                    <h5 class="font-semibold pink-txt">
                      Royale Play Safari Category
                    </h5>
                    <p class="text-sm text-gray-500 mt-3">
                      Asian paint royale play safari is inspired by the theme of
                      an epic expanse of plains, grassland of Africa, An
                      expedition to observe the rare dotted skin animals,
                      rainstorm, waves of oceans, hailstorms, a rainstorm of
                      natures originality.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      So as the name of the paint suggests, Asian Paint Royal
                      play Safari is available in five special effects namely
                      Classic, Sleet, Rainstorm, Ocean wave, and Frost Form.
                      This paint has coarse particles of gold and silver paint
                      to add to the pigmented texture effect of the natural
                      safari theme.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      It takes about one liter of paint to cover 40-60 square
                      feet of well-prepared smooth wall surface to paint a
                      single coat. It is available in 1-liter containers for use
                      within 2 years from the date of manufacture's shelf life.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      The pre-painting process involves cleaning and curing a
                      fresh masonry surface and for best results, it is
                      necessary to allow the surface to dry for 2 to 4 days
                      before applying Royale Play Safari Paint. Being an
                      environmentally safe water-based paint, it is free from a
                      mixture of lead, mercury, and chromium compounds. It is
                      non-flammable, non-toxic, and odorless.
                    </p>
                  </div>
                  <hr class="my-10" />
                  <div class="contentpara">
                    <h5 class="font-semibold pink-txt">
                      Royale Play Safari Category
                    </h5>
                    <p class="text-sm text-gray-500 mt-3">
                      Asian paint royale play safari is inspired by the theme of
                      an epic expanse of plains, grassland of Africa, An
                      expedition to observe the rare dotted skin animals,
                      rainstorm, waves of oceans, hailstorms, a rainstorm of
                      natures originality.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      So as the name of the paint suggests, Asian Paint Royal
                      play Safari is available in five special effects namely
                      Classic, Sleet, Rainstorm, Ocean wave, and Frost Form.
                      This paint has coarse particles of gold and silver paint
                      to add to the pigmented texture effect of the natural
                      safari theme.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      It takes about one liter of paint to cover 40-60 square
                      feet of well-prepared smooth wall surface to paint a
                      single coat. It is available in 1-liter containers for use
                      within 2 years from the date of manufacture's shelf life.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      The pre-painting process involves cleaning and curing a
                      fresh masonry surface and for best results, it is
                      necessary to allow the surface to dry for 2 to 4 days
                      before applying Royale Play Safari Paint. Being an
                      environmentally safe water-based paint, it is free from a
                      mixture of lead, mercury, and chromium compounds. It is
                      non-flammable, non-toxic, and odorless.
                    </p>
                  </div>
                  <hr class="my-10" />
                  <div class="contentpara">
                    <h5 class="font-semibold pink-txt">
                      Royale Play Safari Category
                    </h5>
                    <p class="text-sm text-gray-500 mt-3">
                      Asian paint royale play safari is inspired by the theme of
                      an epic expanse of plains, grassland of Africa, An
                      expedition to observe the rare dotted skin animals,
                      rainstorm, waves of oceans, hailstorms, a rainstorm of
                      natures originality.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      So as the name of the paint suggests, Asian Paint Royal
                      play Safari is available in five special effects namely
                      Classic, Sleet, Rainstorm, Ocean wave, and Frost Form.
                      This paint has coarse particles of gold and silver paint
                      to add to the pigmented texture effect of the natural
                      safari theme.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      It takes about one liter of paint to cover 40-60 square
                      feet of well-prepared smooth wall surface to paint a
                      single coat. It is available in 1-liter containers for use
                      within 2 years from the date of manufacture's shelf life.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      The pre-painting process involves cleaning and curing a
                      fresh masonry surface and for best results, it is
                      necessary to allow the surface to dry for 2 to 4 days
                      before applying Royale Play Safari Paint. Being an
                      environmentally safe water-based paint, it is free from a
                      mixture of lead, mercury, and chromium compounds. It is
                      non-flammable, non-toxic, and odorless.
                    </p>
                  </div>
                  <hr class="my-10" />
                  <div class="contentpara">
                    <h5 class="font-semibold pink-txt">
                      Royale Play Safari Category
                    </h5>
                    <p class="text-sm text-gray-500 mt-3">
                      Asian paint royale play safari is inspired by the theme of
                      an epic expanse of plains, grassland of Africa, An
                      expedition to observe the rare dotted skin animals,
                      rainstorm, waves of oceans, hailstorms, a rainstorm of
                      natures originality.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      So as the name of the paint suggests, Asian Paint Royal
                      play Safari is available in five special effects namely
                      Classic, Sleet, Rainstorm, Ocean wave, and Frost Form.
                      This paint has coarse particles of gold and silver paint
                      to add to the pigmented texture effect of the natural
                      safari theme.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      It takes about one liter of paint to cover 40-60 square
                      feet of well-prepared smooth wall surface to paint a
                      single coat. It is available in 1-liter containers for use
                      within 2 years from the date of manufacture's shelf life.
                    </p>
                    <p class="text-sm text-gray-500 mt-3">
                      The pre-painting process involves cleaning and curing a
                      fresh masonry surface and for best results, it is
                      necessary to allow the surface to dry for 2 to 4 days
                      before applying Royale Play Safari Paint. Being an
                      environmentally safe water-based paint, it is free from a
                      mixture of lead, mercury, and chromium compounds. It is
                      non-flammable, non-toxic, and odorless.
                    </p>
                  </div>
                  <hr class="my-10" />
                  <section id="faq" class="px-4">
                    <div class="container mx-auto">
                      <h2 class="text-center font-bold mb-5">FAQs</h2>
                      <div
                        class="accordion flex flex-col items-center justify-center"
                      >
                        <!--  Panel 1  -->
                        <div class="w-full lg:w-1/2 shadow11 mb-4">
                          <input
                            type="checkbox"
                            name="panel"
                            id="panel-1"
                            class="hidden"
                          />
                          <label
                            for="panel-1"
                            class="relative block bg-white text-black p-4 rounded-2xl"
                            >Questions text goes here</label
                          >
                          <div class="accordion__content overflow-hidden">
                            <p
                              class="accordion__body p-4 text-black"
                              id="panel1"
                            >
                              Lorem Ipsum is simply dummy text of the printing
                              and typesetting industry. Lorem Ipsum has been the
                              industry's standard dummy text ever since the
                              1500s, when an unknown printer took a galley of
                              type and scrambled it to make a type specimen.
                            </p>
                          </div>
                        </div>
                        <!--  Panel 2  -->
                        <div class="w-full lg:w-1/2 shadow11 mb-4">
                          <input
                            type="checkbox"
                            name="panel"
                            id="panel-2"
                            class="hidden"
                          />
                          <label
                            for="panel-2"
                            class="relative block bg-white text-black p-4 rounded-2xl"
                            >Questions text goes here</label
                          >
                          <div class="accordion__content overflow-hidden">
                            <p
                              class="accordion__body p-4 text-black"
                              id="panel1"
                            >
                              Lorem ipsum dolor sit amet, consectetur
                              adipisicing elit. Iusto possimus at a cum saepe
                              molestias modi illo facere ducimus voluptatibus
                              praesentium deleniti fugiat ab error quia sit
                              perspiciatis velit necessitatibus.Lorem ipsum
                              dolor sit amet, consectetur adipisicing elit.
                              Lorem ipsum dolor sit amet.
                            </p>
                          </div>
                        </div>
                        <!--  Panel 3  -->
                        <div class="w-full lg:w-1/2 shadow11 mb-4">
                          <input
                            type="checkbox"
                            name="panel"
                            id="panel-3"
                            class="hidden"
                          />
                          <label
                            for="panel-3"
                            class="relative block bg-white text-black p-4 rounded-2xl"
                            >Questions text goes here</label
                          >
                          <div class="accordion__content overflow-hidden">
                            <p
                              class="accordion__body p-4 text-black"
                              id="panel1"
                            >
                              Lorem ipsum dolor sit amet, consectetur
                              adipisicing elit. Iusto possimus at a cum saepe
                              molestias modi illo facere ducimus voluptatibus
                              praesentium deleniti fugiat ab error quia sit
                              perspiciatis velit necessitatibus.Lorem ipsum
                              dolor sit amet, consectetur adipisicing elit.
                              Lorem ipsum dolor sit amet.
                            </p>
                          </div>
                        </div>
                        <!--  Panel 4  -->
                        <div class="w-full lg:w-1/2 shadow11 mb-4">
                          <input
                            type="checkbox"
                            name="panel"
                            id="panel-4"
                            class="hidden"
                          />
                          <label
                            for="panel-4"
                            class="relative block bg-white text-black p-4 rounded-2xl"
                            >Questions text goes here</label
                          >
                          <div class="accordion__content overflow-hidden">
                            <p
                              class="accordion__body p-4 text-black"
                              id="panel1"
                            >
                              Lorem ipsum dolor sit amet, consectetur
                              adipisicing elit. Iusto possimus at a cum saepe
                              molestias modi illo facere ducimus voluptatibus
                              praesentium deleniti fugiat ab error quia sit
                              perspiciatis velit necessitatibus.Lorem ipsum
                              dolor sit amet, consectetur adipisicing elit.
                              Lorem ipsum dolor sit amet.
                            </p>
                          </div>
                        </div>
                        <!--  Panel 5  -->
                        <div class="w-full lg:w-1/2 shadow11 mb-4">
                          <input
                            type="checkbox"
                            name="panel"
                            id="panel-5"
                            class="hidden"
                          />
                          <label
                            for="panel-5"
                            class="relative block bg-white text-black p-4 rounded-2xl"
                            >Questions text goes here</label
                          >
                          <div class="accordion__content overflow-hidden">
                            <p
                              class="accordion__body p-4 text-black"
                              id="panel1"
                            >
                              Lorem ipsum dolor sit amet, consectetur
                              adipisicing elit. Iusto possimus at a cum saepe
                              molestias modi illo facere ducimus voluptatibus
                              praesentium deleniti fugiat ab error quia sit
                              perspiciatis velit necessitatibus.Lorem ipsum
                              dolor sit amet, consectetur adipisicing elit.
                              Lorem ipsum dolor sit amet.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="max-w-6xl mx-auto"></div>
    </div>
  </section>
  <!-- service Post section end -->
</template>

<style scoped>
@import "../assets/css/service.css";
</style>
