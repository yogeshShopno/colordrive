<script setup>
  import Header from '@/components/Header.vue'
  import Footer from '@/components/Footer.vue'


</script>
<template>
  <div>
    <Header />
    <slot />
    <Footer />
  </div>
</template>
<style scoped>
/* Your layout-specific styles here */
</style>
