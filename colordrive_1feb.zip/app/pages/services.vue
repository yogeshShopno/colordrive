<script setup>
</script>

<template>
  <!-- main banner start -->
  <section id="services" class="ptb-80">
    <div class="container mx-auto text-center">
      <h1>Services</h1>
      <div class="flex items-center gap-2 justify-center">
        <a href="index.vue"> <p>Home</p></a>
        <i class="fa-solid fa-chevron-right" style="color: #000000"></i>
        <p>Services</p>
      </div>
    </div>
  </section>
  <!-- main banner end -->

  <!-- service section start -->
  <section class="py-100 px-4 px-md-0" id="wall-service">
    <div class="container mx-auto">
      <h2 class="text-center font-bold mb-4">Wall Designing</h2>
      <div
        class="img111 grid gap-x-8 gap-y-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-5"
      >
        <div>
          <div class="flex justify-center mb-3">
            <img
              src="assets/images/services/texture-designing.svg"
              alt="texture-designing"
              class="img-width"
            />
          </div>
          <h5 class="text-center">Texture designing</h5>
        </div>
        <div>
          <div class="flex justify-center mb-3">
            <img
              src="assets/images/services/stencils-designing.svg"
              alt="stencils-designing"
              class="img-width"
            />
          </div>
          <h5 class="text-center">Stencils designing</h5>
        </div>
        <div>
          <div class="flex justify-center mb-3">
            <img
              src="assets/images/services/wallpaper-designing.svg"
              alt="wallpaper-designing"
              class="img-width"
            />
          </div>
          <h5 class="text-center">Wallpaper designing</h5>
        </div>
        <div>
          <div class="flex justify-center mb-3">
            <img
              src="assets/images/services/kids-decor.svg"
              alt="kids-decor"
              class="img-width"
            />
          </div>
          <h5 class="text-center">Kids Decor</h5>
        </div>
        <div>
          <div class="flex justify-center mb-3">
            <img
              src="assets/images/services/free-hand-art.svg"
              alt="free-hand-art"
              class="img-width"
            />
          </div>
          <h5 class="text-center">Free Hand Art</h5>
        </div>
      </div>
    </div>
  </section>
  <!-- service section end -->

  <!-- service Post section start -->
  <section id="service-post" class="pb-200 px-4 px-md-0">
    <div class="container mx-auto">
      <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        <div class="bg-white shadow-mds rounded-2xl">
          <div>
            <div class="flex justify-center">
              <img
                src="assets/images/services/service-img1.webp"
                alt="Interior Painting"
                width="100%"
                class="br-16"
              />
            </div>
            <div class="p-5">
              <h5 class="font-semibold">Interior Painting</h5>
              <ul class="mt-2">
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Budget paints starting at 5 Rs/sq.ft.
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Complete Post Painting Cleanup
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  1-2 Day Quick Service
                </li>
              </ul>
            </div>
          </div>
          <div class="px-5 flex pb-5 gap-5 justify-between items-center">
            <div>
              <p class="">
                Show More
                <i
                  class="fa-solid fa-arrow-right ms-2"
                  style="color: #000000"
                ></i>
              </p>
            </div>
            <div>
              <button
                type="submit"
                class="mb-4 xl:mb-0 mt-4 text-black bg-yellow cta-btn font-medium rounded-xxl text-sm px-5 py-2.5 text-center before:ease relative overflow-hidden transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40"
                data-v-inspector="app/pages/index.vue:853:13"
                data-v-02281a80=""
              >
                <span
                  relative="relative z-10"
                  data-v-inspector="app/pages/index.vue:857:15"
                  data-v-02281a80=""
                  >Estimate Cost</span
                >
              </button>
            </div>
          </div>
        </div>
        <div class="bg-white shadow-mds rounded-2xl">
          <div>
            <div class="flex justify-center">
              <img
                src="assets/images/services/service-img2.webp"
                alt="Exterior Painting"
                width="100%"
                class="br-16"
              />
            </div>
            <div class="p-5">
              <h5 class="font-semibold">Exterior Painting</h5>
              <ul class="mt-2">
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Budget paints starting at 5 Rs/sq.ft.
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Complete Post Painting Cleanup
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  1-2 Day Quick Service
                </li>
              </ul>
            </div>
          </div>
          <div class="px-5 flex pb-5 gap-5 justify-between items-center">
            <div>
              <p class="">
                Show More
                <i
                  class="fa-solid fa-arrow-right ms-2"
                  style="color: #000000"
                ></i>
              </p>
            </div>
            <div>
              <button
                type="submit"
                class="mb-4 xl:mb-0 mt-4 text-black bg-yellow cta-btn font-medium rounded-xxl text-sm px-5 py-2.5 text-center before:ease relative overflow-hidden transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40"
                data-v-inspector="app/pages/index.vue:853:13"
                data-v-02281a80=""
              >
                <span
                  relative="relative z-10"
                  data-v-inspector="app/pages/index.vue:857:15"
                  data-v-02281a80=""
                  >Estimate Cost</span
                >
              </button>
            </div>
          </div>
        </div>
        <div class="bg-white shadow-mds rounded-2xl">
          <div>
            <div class="flex justify-center">
              <img
                src="assets/images/services/service-img3.webp"
                alt="Wall Design Painting"
                width="100%"
                class="br-16"
              />
            </div>
            <div class="p-5">
              <h5 class="font-semibold">Wall Design Painting</h5>
              <ul class="mt-2">
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Budget paints starting at 5 Rs/sq.ft.
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Complete Post Painting Cleanup
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  1-2 Day Quick Service
                </li>
              </ul>
            </div>
          </div>
          <div class="px-5 flex pb-5 gap-5 justify-between items-center">
            <div>
              <p class="">
                Show More
                <i
                  class="fa-solid fa-arrow-right ms-2"
                  style="color: #000000"
                ></i>
              </p>
            </div>
            <div>
              <button
                type="submit"
                class="mb-4 xl:mb-0 mt-4 text-black bg-yellow cta-btn font-medium rounded-xxl text-sm px-5 py-2.5 text-center before:ease relative overflow-hidden transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40"
                data-v-inspector="app/pages/index.vue:853:13"
                data-v-02281a80=""
              >
                <span
                  relative="relative z-10"
                  data-v-inspector="app/pages/index.vue:857:15"
                  data-v-02281a80=""
                  >Estimate Cost</span
                >
              </button>
            </div>
          </div>
        </div>
        <div class="bg-white shadow-mds rounded-2xl">
          <div>
            <div class="flex justify-center">
              <img
                src="assets/images/services/service-img4.webp"
                alt="Waterproofing Solutions"
                width="100%"
                class="br-16"
              />
            </div>
            <div class="p-5">
              <h5 class="font-semibold">Waterproofing Solutions</h5>
              <ul class="mt-2">
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Budget paints starting at 5 Rs/sq.ft.
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Complete Post Painting Cleanup
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  1-2 Day Quick Service
                </li>
              </ul>
            </div>
          </div>
          <div class="px-5 flex pb-5 gap-5 justify-between items-center">
            <div>
              <p class="">
                Show More
                <i
                  class="fa-solid fa-arrow-right ms-2"
                  style="color: #000000"
                ></i>
              </p>
            </div>
            <div>
              <button
                type="submit"
                class="mb-4 xl:mb-0 mt-4 text-black bg-yellow cta-btn font-medium rounded-xxl text-sm px-5 py-2.5 text-center before:ease relative overflow-hidden transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40"
                data-v-inspector="app/pages/index.vue:853:13"
                data-v-02281a80=""
              >
                <span
                  relative="relative z-10"
                  data-v-inspector="app/pages/index.vue:857:15"
                  data-v-02281a80=""
                  >Estimate Cost</span
                >
              </button>
            </div>
          </div>
        </div>
        <div class="bg-white shadow-mds rounded-2xl">
          <div>
            <div class="flex justify-center">
              <img
                src="assets/images/services/service-img5.webp"
                alt="Rental Painting"
                width="100%"
                class="br-16"
              />
            </div>
            <div class="p-5">
              <h5 class="font-semibold">Rental Painting</h5>
              <ul class="mt-2">
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Budget paints starting at 5 Rs/sq.ft.
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Complete Post Painting Cleanup
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  1-2 Day Quick Service
                </li>
              </ul>
            </div>
          </div>
          <div class="px-5 flex pb-5 gap-5 justify-between items-center">
            <div>
              <p class="">
                Show More
                <i
                  class="fa-solid fa-arrow-right ms-2"
                  style="color: #000000"
                ></i>
              </p>
            </div>
            <div>
              <button
                type="submit"
                class="mb-4 xl:mb-0 mt-4 text-black bg-yellow cta-btn font-medium rounded-xxl text-sm px-5 py-2.5 text-center before:ease relative overflow-hidden transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40"
                data-v-inspector="app/pages/index.vue:853:13"
                data-v-02281a80=""
              >
                <span
                  relative="relative z-10"
                  data-v-inspector="app/pages/index.vue:857:15"
                  data-v-02281a80=""
                  >Estimate Cost</span
                >
              </button>
            </div>
          </div>
        </div>
        <div class="bg-white shadow-mds rounded-2xl">
          <div>
            <div class="flex justify-center">
              <img
                src="assets/images/services/service-img6.webp"
                alt="House Wallpaper"
                width="100%"
                class="br-16"
              />
            </div>
            <div class="p-5">
              <h5 class="font-semibold">House Wallpaper</h5>
              <ul class="mt-2">
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Budget paints starting at 5 Rs/sq.ft.
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Complete Post Painting Cleanup
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  1-2 Day Quick Service
                </li>
              </ul>
            </div>
          </div>
          <div class="px-5 flex pb-5 gap-5 justify-between items-center">
            <div>
              <p class="">
                Show More
                <i
                  class="fa-solid fa-arrow-right ms-2"
                  style="color: #000000"
                ></i>
              </p>
            </div>
            <div>
              <button
                type="submit"
                class="mb-4 xl:mb-0 mt-4 text-black bg-yellow cta-btn font-medium rounded-xxl text-sm px-5 py-2.5 text-center before:ease relative overflow-hidden transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40"
                data-v-inspector="app/pages/index.vue:853:13"
                data-v-02281a80=""
              >
                <span
                  relative="relative z-10"
                  data-v-inspector="app/pages/index.vue:857:15"
                  data-v-02281a80=""
                  >Estimate Cost</span
                >
              </button>
            </div>
          </div>
        </div>
        <div class="bg-white shadow-mds rounded-2xl">
          <div>
            <div class="flex justify-center">
              <img
                src="assets/images/services/service-img7.webp"
                alt="Waterproofing Solutions"
                width="100%"
                class="br-16"
              />
            </div>
            <div class="p-5">
              <h5 class="font-semibold">Waterproofing Solutions</h5>
              <ul class="mt-2">
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Budget paints starting at 5 Rs/sq.ft.
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Complete Post Painting Cleanup
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  1-2 Day Quick Service
                </li>
              </ul>
            </div>
          </div>
          <div class="px-5 flex pb-5 gap-5 justify-between items-center">
            <div>
              <p class="">
                Show More
                <i
                  class="fa-solid fa-arrow-right ms-2"
                  style="color: #000000"
                ></i>
              </p>
            </div>
            <div>
              <button
                type="submit"
                class="mb-4 xl:mb-0 mt-4 text-black bg-yellow cta-btn font-medium rounded-xxl text-sm px-5 py-2.5 text-center before:ease relative overflow-hidden transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40"
                data-v-inspector="app/pages/index.vue:853:13"
                data-v-02281a80=""
              >
                <span
                  relative="relative z-10"
                  data-v-inspector="app/pages/index.vue:857:15"
                  data-v-02281a80=""
                  >Estimate Cost</span
                >
              </button>
            </div>
          </div>
        </div>
        <div class="bg-white shadow-mds rounded-2xl">
          <div>
            <div class="flex justify-center">
              <img
                src="assets/images/services/service-img8.webp"
                alt="Interior Painting"
                width="100%"
                class="br-16"
              />
            </div>
            <div class="p-5">
              <h5 class="font-semibold">Interior Painting</h5>
              <ul class="mt-2">
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Budget paints starting at 5 Rs/sq.ft.
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Complete Post Painting Cleanup
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  1-2 Day Quick Service
                </li>
              </ul>
            </div>
          </div>
          <div class="px-5 flex pb-5 gap-5 justify-between items-center">
            <div>
              <p class="">
                Show More
                <i
                  class="fa-solid fa-arrow-right ms-2"
                  style="color: #000000"
                ></i>
              </p>
            </div>
            <div>
              <button
                type="submit"
                class="mb-4 xl:mb-0 mt-4 text-black bg-yellow cta-btn font-medium rounded-xxl text-sm px-5 py-2.5 text-center before:ease relative overflow-hidden transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40"
                data-v-inspector="app/pages/index.vue:853:13"
                data-v-02281a80=""
              >
                <span
                  relative="relative z-10"
                  data-v-inspector="app/pages/index.vue:857:15"
                  data-v-02281a80=""
                  >Estimate Cost</span
                >
              </button>
            </div>
          </div>
        </div>
        <div class="bg-white shadow-mds rounded-2xl">
          <div>
            <div class="flex justify-center">
              <img
                src="assets/images/services/service-img9.webp"
                alt="Exterior Painting"
                width="100%"
                class="br-16"
              />
            </div>
            <div class="p-5">
              <h5 class="font-semibold">Exterior Painting</h5>
              <ul class="mt-2">
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Budget paints starting at 5 Rs/sq.ft.
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Complete Post Painting Cleanup
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  1-2 Day Quick Service
                </li>
              </ul>
            </div>
          </div>
          <div class="px-5 flex pb-5 gap-5 justify-between items-center">
            <div>
              <p class="">
                Show More
                <i
                  class="fa-solid fa-arrow-right ms-2"
                  style="color: #000000"
                ></i>
              </p>
            </div>
            <div>
              <button
                type="submit"
                class="mb-4 xl:mb-0 mt-4 text-black bg-yellow cta-btn font-medium rounded-xxl text-sm px-5 py-2.5 text-center before:ease relative overflow-hidden transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40"
                data-v-inspector="app/pages/index.vue:853:13"
                data-v-02281a80=""
              >
                <span
                  relative="relative z-10"
                  data-v-inspector="app/pages/index.vue:857:15"
                  data-v-02281a80=""
                  >Estimate Cost</span
                >
              </button>
            </div>
          </div>
        </div>
        <div class="bg-white shadow-mds rounded-2xl">
          <div>
            <div class="flex justify-center">
              <img
                src="assets/images/services/service-img10.webp"
                alt="Wall Design Painting"
                width="100%"
                class="br-16"
              />
            </div>
            <div class="p-5">
              <h5 class="font-semibold">Wall Design Painting</h5>
              <ul class="mt-2">
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Budget paints starting at 5 Rs/sq.ft.
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Complete Post Painting Cleanup
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  1-2 Day Quick Service
                </li>
              </ul>
            </div>
          </div>
          <div class="px-5 flex pb-5 gap-5 justify-between items-center">
            <div>
              <p class="">
                Show More
                <i
                  class="fa-solid fa-arrow-right ms-2"
                  style="color: #000000"
                ></i>
              </p>
            </div>
            <div>
              <button
                type="submit"
                class="mb-4 xl:mb-0 mt-4 text-black bg-yellow cta-btn font-medium rounded-xxl text-sm px-5 py-2.5 text-center before:ease relative overflow-hidden transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40"
                data-v-inspector="app/pages/index.vue:853:13"
                data-v-02281a80=""
              >
                <span
                  relative="relative z-10"
                  data-v-inspector="app/pages/index.vue:857:15"
                  data-v-02281a80=""
                  >Estimate Cost</span
                >
              </button>
            </div>
          </div>
        </div>
        <div class="bg-white shadow-mds rounded-2xl">
          <div>
            <div class="flex justify-center">
              <img
                src="assets/images/services/service-img11.webp"
                alt="Wall Design Painting"
                width="100%"
                class="br-16"
              />
            </div>
            <div class="p-5">
              <h5 class="font-semibold">Interior Painting</h5>
              <ul class="mt-2">
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Budget paints starting at 5 Rs/sq.ft.
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Complete Post Painting Cleanup
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  1-2 Day Quick Service
                </li>
              </ul>
            </div>
          </div>
          <div class="px-5 flex pb-5 gap-5 justify-between items-center">
            <div>
              <p class="">
                Show More
                <i
                  class="fa-solid fa-arrow-right ms-2"
                  style="color: #000000"
                ></i>
              </p>
            </div>
            <div>
              <button
                type="submit"
                class="mb-4 xl:mb-0 mt-4 text-black bg-yellow cta-btn font-medium rounded-xxl text-sm px-5 py-2.5 text-center before:ease relative overflow-hidden transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40"
                data-v-inspector="app/pages/index.vue:853:13"
                data-v-02281a80=""
              >
                <span
                  relative="relative z-10"
                  data-v-inspector="app/pages/index.vue:857:15"
                  data-v-02281a80=""
                  >Estimate Cost</span
                >
              </button>
            </div>
          </div>
        </div>
        <div class="bg-white shadow-mds rounded-2xl">
          <div>
            <div class="flex justify-center">
              <img
                src="assets/images/services/service-img12.webp"
                alt="Exterior Painting"
                width="100%"
                class="br-16"
              />
            </div>
            <div class="p-5">
              <h5 class="font-semibold">Interior Painting</h5>
              <ul class="mt-2">
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Budget paints starting at 5 Rs/sq.ft.
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  Complete Post Painting Cleanup
                </li>
                <li class="flex">
                  <div>
                    <i
                      class="fa-solid fa-check me-3"
                      style="color: #4e4e4e"
                    ></i>
                  </div>
                  1-2 Day Quick Service
                </li>
              </ul>
            </div>
          </div>
          <div class="px-5 flex pb-5 gap-5 justify-between items-center">
            <div>
              <p class="">
                Show More
                <i
                  class="fa-solid fa-arrow-right ms-2"
                  style="color: #000000"
                ></i>
              </p>
            </div>
            <div>
              <button
                type="submit"
                class="mb-4 xl:mb-0 mt-4 text-black bg-yellow cta-btn font-medium rounded-xxl text-sm px-5 py-2.5 text-center before:ease relative overflow-hidden transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40"
                data-v-inspector="app/pages/index.vue:853:13"
                data-v-02281a80=""
              >
                <span
                  relative="relative z-10"
                  data-v-inspector="app/pages/index.vue:857:15"
                  data-v-02281a80=""
                  >Estimate Cost</span
                >
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- service Post section end -->
</template>

<style scoped>
@import '../assets/css/service.css';
</style>
