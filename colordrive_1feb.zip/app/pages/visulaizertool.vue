<script></script>

<template>
    <!-- main banner start -->
    <section id="blog-new" class="py-100 px-3 mb-50px" data-v-inspector="app/pages/blog.vue:5:3" data-v-1bac7c7d="">
        <div class="container mx-auto" data-v-inspector="app/pages/blog.vue:6:5" data-v-1bac7c7d="">
            <!-- <h1>Blog</h1> -->
            <div class="text-center">
                <h2 class="text font-bold">Home Painting Colour Shades Visualizer</h2>
                <div class="flex items-center justify-center gap-2">
                    <a href="/texturepaint">
                        <p>Home</p>
                    </a>
                    <i class="fa-solid fa-chevron-right" style="color: #000000"></i>
                    <p class="text-gray-500">Home Painting Colour Shades Visualizer</p>
                </div>
            </div>
        </div>
    </section>
    <!-- main banner end -->

    <!-- service Post section start -->
    <section id="service-post" class="pb-200 mt-50px px-4 px-md-0">
        <div class="container mx-auto">
            <div class="max-w-full mx-auto">
                <div class="firstsecdiv">
                    <div class="cal3main">
                        <div>
                            <div class="calcseccardsdiv">
                                <div class="calcspace">
                                    <div class="calccardspacemini">
                                        <div class="flex sm:flex-row flex-col gap-4">
                                            <div class="basis-1/3">
                                                <div class="colorfilterdiv mt-8 overflow-x-auto mb-5">
                                                    <div
                                                        class="flex space-x-5 items-center justify-start md:justify-center px-4">
                                                        <!-- Color Option -->
                                                        <div class="flex flex-col items-center">
                                                            <div
                                                                class="w-10 h-10 rounded-full bg-pink-500 hover:shadow-md">
                                                            </div>
                                                            <span class="text-sm text-gray-900 mt-2">All</span>
                                                        </div>

                                                        <!-- Red -->
                                                        <div class="flex flex-col items-center">
                                                            <div
                                                                class="w-10 h-10 rounded-full bg-red-600 hover:shadow-md">
                                                            </div>
                                                            <span class="text-sm text-gray-900 mt-2">Red</span>
                                                        </div>

                                                        <!-- Green -->
                                                        <div class="flex flex-col items-center">
                                                            <div
                                                                class="w-10 h-10 rounded-full bg-green-600 hover:shadow-md">
                                                            </div>
                                                            <span class="text-sm text-gray-900 mt-2">Green</span>
                                                        </div>

                                                        <!-- Blue -->
                                                        <div class="flex flex-col items-center">
                                                            <div
                                                                class="w-10 h-10 rounded-full bg-blue-400 hover:shadow-md">
                                                            </div>
                                                            <span class="text-sm text-gray-900 mt-2">Blue</span>
                                                        </div>

                                                        <!-- Pastel -->
                                                        <div class="flex flex-col items-center">
                                                            <div
                                                                class="w-10 h-10 rounded-full bg-rose-200 hover:shadow-md">
                                                            </div>
                                                            <span class="text-sm text-gray-900 mt-2">Pastel</span>
                                                        </div>

                                                        <!-- Yellow -->
                                                        <div class="flex flex-col items-center">
                                                            <div
                                                                class="w-10 h-10 rounded-full bg-yellow-400 hover:shadow-md">
                                                            </div>
                                                            <span class="text-sm text-gray-900 mt-2">Yellow</span>
                                                        </div>

                                                        <!-- Gray -->
                                                        <div class="flex flex-col items-center">
                                                            <div
                                                                class="w-10 h-10 rounded-full bg-gray-400 hover:shadow-md">
                                                            </div>
                                                            <span class="text-sm text-gray-900 mt-2">Gray</span>
                                                        </div>

                                                        <!-- Purple -->
                                                        <div class="flex flex-col items-center">
                                                            <div
                                                                class="w-10 h-10 rounded-full bg-purple-500 hover:shadow-md">
                                                            </div>
                                                            <span class="text-sm text-gray-900 mt-2">Purple</span>
                                                        </div>

                                                        <!-- Brown -->
                                                        <div class="flex flex-col items-center">
                                                            <div
                                                                class="w-10 h-10 rounded-full bg-amber-900 hover:shadow-md">
                                                            </div>
                                                            <span class="text-sm text-gray-900 mt-2">Brown</span>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="calccardspacemini0 faqcustshadow p-4 rounded-lg">
                                                    <div class="calccardtitle mb-3">
                                                        <p class="font-semibold text-xl text-center">Select colour
                                                            shades from Red colour pallet & see demo on walls</p>
                                                    </div>
                                                    <div class="cal3fordiv colosselectgdiv">
                                                        <div class="maxhdiv overflow-y-auto">
                                                            <div class="grid grid-cols-5 gap-4 mb-3">
                                                                <div class="colordivcards text-center overflow-hidden">
                                                                    <img src="assets/images/calculator/colorcard.png"
                                                                        alt=""
                                                                        class="img-fluid rounded-2xl w-full mb-1">
                                                                    <h6 class="text-sm font-semibold">Rich Rouge</h6>
                                                                    <p class="text-xs text-gray-500">8101</p>
                                                                </div>
                                                                <div class="colordivcards text-center overflow-hidden">
                                                                    <img src="assets/images/calculator/colorcard.png"
                                                                        alt=""
                                                                        class="img-fluid rounded-2xl w-full mb-1">
                                                                    <h6 class="text-sm font-semibold">Rich Rouge</h6>
                                                                    <p class="text-xs text-gray-500">8101</p>
                                                                </div>
                                                                <div class="colordivcards text-center overflow-hidden">
                                                                    <img src="assets/images/calculator/colorcard.png"
                                                                        alt=""
                                                                        class="img-fluid rounded-2xl w-full mb-1">
                                                                    <h6 class="text-sm font-semibold">Rich Rouge</h6>
                                                                    <p class="text-xs text-gray-500">8101</p>
                                                                </div>
                                                                <div class="colordivcards text-center overflow-hidden">
                                                                    <img src="assets/images/calculator/colorcard.png"
                                                                        alt=""
                                                                        class="img-fluid rounded-2xl w-full mb-1">
                                                                    <h6 class="text-sm font-semibold">Rich Rouge</h6>
                                                                    <p class="text-xs text-gray-500">8101</p>
                                                                </div>
                                                                <div class="colordivcards text-center overflow-hidden">
                                                                    <img src="assets/images/calculator/colorcard.png"
                                                                        alt=""
                                                                        class="img-fluid rounded-2xl w-full mb-1">
                                                                    <h6 class="text-sm font-semibold">Rich Rouge</h6>
                                                                    <p class="text-xs text-gray-500">8101</p>
                                                                </div>
                                                                <div class="colordivcards text-center overflow-hidden">
                                                                    <img src="assets/images/calculator/colorcard.png"
                                                                        alt=""
                                                                        class="img-fluid rounded-2xl w-full mb-1">
                                                                    <h6 class="text-sm font-semibold">Rich Rouge</h6>
                                                                    <p class="text-xs text-gray-500">8101</p>
                                                                </div>
                                                                <div class="colordivcards text-center overflow-hidden">
                                                                    <img src="assets/images/calculator/colorcard.png"
                                                                        alt=""
                                                                        class="img-fluid rounded-2xl w-full mb-1">
                                                                    <h6 class="text-sm font-semibold">Rich Rouge</h6>
                                                                    <p class="text-xs text-gray-500">8101</p>
                                                                </div>
                                                                <div class="colordivcards text-center overflow-hidden">
                                                                    <img src="assets/images/calculator/colorcard.png"
                                                                        alt=""
                                                                        class="img-fluid rounded-2xl w-full mb-1">
                                                                    <h6 class="text-sm font-semibold">Rich Rouge</h6>
                                                                    <p class="text-xs text-gray-500">8101</p>
                                                                </div>
                                                                <div class="colordivcards text-center overflow-hidden">
                                                                    <img src="assets/images/calculator/colorcard.png"
                                                                        alt=""
                                                                        class="img-fluid rounded-2xl w-full mb-1">
                                                                    <h6 class="text-sm font-semibold">Rich Rouge</h6>
                                                                    <p class="text-xs text-gray-500">8101</p>
                                                                </div>
                                                                <div class="colordivcards text-center overflow-hidden">
                                                                    <img src="assets/images/calculator/colorcard.png"
                                                                        alt=""
                                                                        class="img-fluid rounded-2xl w-full mb-1">
                                                                    <h6 class="text-sm font-semibold">Rich Rouge</h6>
                                                                    <p class="text-xs text-gray-500">8101</p>
                                                                </div>
                                                                <div class="colordivcards text-center overflow-hidden">
                                                                    <img src="assets/images/calculator/colorcard.png"
                                                                        alt=""
                                                                        class="img-fluid rounded-2xl w-full mb-1">
                                                                    <h6 class="text-sm font-semibold">Rich Rouge</h6>
                                                                    <p class="text-xs text-gray-500">8101</p>
                                                                </div>
                                                                <div class="colordivcards text-center overflow-hidden">
                                                                    <img src="assets/images/calculator/colorcard.png"
                                                                        alt=""
                                                                        class="img-fluid rounded-2xl w-full mb-1">
                                                                    <h6 class="text-sm font-semibold">Rich Rouge</h6>
                                                                    <p class="text-xs text-gray-500">8101</p>
                                                                </div>
                                                                <div class="colordivcards text-center overflow-hidden">
                                                                    <img src="assets/images/calculator/colorcard.png"
                                                                        alt=""
                                                                        class="img-fluid rounded-2xl w-full mb-1">
                                                                    <h6 class="text-sm font-semibold">Rich Rouge</h6>
                                                                    <p class="text-xs text-gray-500">8101</p>
                                                                </div>
                                                                <div class="colordivcards text-center overflow-hidden">
                                                                    <img src="assets/images/calculator/colorcard.png"
                                                                        alt=""
                                                                        class="img-fluid rounded-2xl w-full mb-1">
                                                                    <h6 class="text-sm font-semibold">Rich Rouge</h6>
                                                                    <p class="text-xs text-gray-500">8101</p>
                                                                </div>
                                                                <div class="colordivcards text-center overflow-hidden">
                                                                    <img src="assets/images/calculator/colorcard.png"
                                                                        alt=""
                                                                        class="img-fluid rounded-2xl w-full mb-1">
                                                                    <h6 class="text-sm font-semibold">Rich Rouge</h6>
                                                                    <p class="text-xs text-gray-500">8101</p>
                                                                </div>
                                                                <div class="colordivcards text-center overflow-hidden">
                                                                    <img src="assets/images/calculator/colorcard.png"
                                                                        alt=""
                                                                        class="img-fluid rounded-2xl w-full mb-1">
                                                                    <h6 class="text-sm font-semibold">Rich Rouge</h6>
                                                                    <p class="text-xs text-gray-500">8101</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="viewmorediv mt-5 text-center">
                                                            <button
                                                                class="m-0 px-2 sm:px-5 py-2.5 main-btn before:ease relative overflow-hidden text-white shadow-2xl transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40 rounded-full">View
                                                                All Colours</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="basis-2/3">
                                                <div class="calccardspacemini00 sticky top-32 gap-4">
                                                    <div class="toggledivtonew mb-4">
                                                        <div
                                                            class="toggledivcalspace flex items-center justify-center gap-2 mt-3">
                                                            <!-- Example Toggle -->
                                                            <span
                                                                class=" text-gray-500 dark:text-gray-900 font-semibold capitalize">interior
                                                            </span>
                                                            <label
                                                                class="relative inline-flex items-center cursor-pointer">
                                                                <input type="checkbox" class="sr-only peer" checked />
                                                                <div
                                                                    class="w-11 h-6 bg-gray-300 rounded-full peer peer-checked:bg-pink-600 peer-focus:ring-pink-300 dark:peer-focus:ring-pink-800 dark:bg-gray-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all">
                                                                </div>
                                                                <span
                                                                    class="ml-3 text-pink-500 capitalize dark:text-pink-500">exterior
                                                                </span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="tabcontdiv mb-4">
                                                        <div
                                                            class="calccardspacemini sliderdiv justify-center overflow-x-auto flex flex-row flex-nowrap gap-2 text1">
                                                            <div class="calccardspacemini00">
                                                                <button
                                                                    class="btn btn-rounded btn-pink text-center px-3 py-2">View
                                                                    All Colours</button>
                                                            </div>
                                                            <div class="calccardspacemini00">
                                                                <button
                                                                    class="btn btn-rounded btn-pink-o text-center px-3 py-2">View
                                                                    All Colours</button>
                                                            </div>
                                                            <div class="calccardspacemini00">
                                                                <button
                                                                    class="btn btn-rounded btn-pink-o text-center px-3 py-2">View
                                                                    All Colours</button>
                                                            </div>
                                                            <div class="calccardspacemini00">
                                                                <button
                                                                    class="btn btn-rounded btn-pink-o text-center px-3 py-2">View
                                                                    All Colours</button>
                                                            </div>
                                                            <div class="calccardspacemini00">
                                                                <button
                                                                    class="btn btn-rounded btn-pink-o text-center px-3 py-2">View
                                                                    All Colours</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="imgcalcdiv visualrightmain align-center  rounded-md overflow-hidden relative">
                                                        <img src="assets/images/calculator/visultopimg.png"
                                                            alt="Interior Painting" width=""
                                                            class="br-16 max-w-full object-contain w-full" />
                                                        <div
                                                            class="absolute bottom-5 left-1/2 transform -translate-x-1/2">
                                                            <a href="/visualscreen2"
                                                                class="m-0 px-5 sm:px-5 py-2.5 main-btn before:ease relative overflow-hidden text-white shadow-2xl transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40 rounded-lg">save</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="shadesdivcontdiv mt-8">
                                        <div class="tabcontdiv mb-4">
                                            <div
                                                class="calccardspacemini sliderdiv justify-center flex flex-row gap-2 text1">
                                                <div class="calccardspacemini00">
                                                    <button class="btn rounded-lg btn-pink text-center px-3 py-2">Asian
                                                        Shades</button>
                                                </div>
                                                <div class="calccardspacemini00">
                                                    <button
                                                        class="btn rounded-lg btn-pink-o text-center px-3 py-2">Asian
                                                        Shades</button>
                                                </div>
                                                <div class="calccardspacemini00">
                                                    <button
                                                        class="btn rounded-lg btn-pink-o text-center px-3 py-2">Asian
                                                        Shades</button>
                                                </div>
                                                <div class="calccardspacemini00">
                                                    <button
                                                        class="btn rounded-lg btn-pink-o text-center px-3 py-2">Asian
                                                        Shades</button>
                                                </div>
                                                <div class="calccardspacemini00">
                                                    <button class="btn rounded-lg btn-pink-o text-center px-3 py-2">View
                                                        All Colours</button>
                                                </div>
                                                <div class="calccardspacemini00">
                                                    <button class="btn rounded-lg btn-pink-o text-center px-3 py-2">View
                                                        All Colours</button>
                                                </div>
                                                <div class="calccardspacemini00">
                                                    <button class="btn rounded-lg btn-pink-o text-center px-3 py-2">View
                                                        All Colours</button>
                                                </div>
                                                <div class="calccardspacemini00">
                                                    <button class="btn rounded-lg btn-pink-o text-center px-3 py-2">View
                                                        All Colours</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="calcseccardsdiv mt-8">
                                        <div class="calcspace">
                                            <div class="calccardtitle mb-3">
                                                <h3 class="text-xl font-bold text-center mb-5">
                                                    Check ColourDrive Expert Suggetions
                                                </h3>
                                            </div>
                                            <div class="calccardspacemini sliderdiv text1">
                                                <Swiper class="catalogue" :slides-per-view="1" :loop="true"
                                                    :breakpoints="{
                                                    0: { slidesPerView: 1 }, 
                                                    425: { slidesPerView: 1 }, 
                                                    575: { slidesPerView: 2 }, 
                                                    991: { slidesPerView: 3 },
                                                    1024: { slidesPerView: 4 },
                                                  }" :modules="[
                                                SwiperAutoplay,
                                                SwiperEffectCreative,
                                                SwiperNavigation,
                                              ]" :autoplay="{
                                                delay: 3000,
                                                disableOnInteraction: true,
                                              }" :pauseAutoplayOnMouseEnter="true" :navigation="true" :pagination="{
                                                clickable: true,
                                              }">
                                                    <SwiperSlide class="h-100 p-3">
                                                        <div class="row-span-612">
                                                            <div
                                                                class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                                <div class="imgcalcdivv border-none">
                                                                    <img src="assets/images/calculator/exprtsugg.png"
                                                                        alt="Interior Painting" width=""
                                                                        class="max-w-full w-full h-auto" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </SwiperSlide>
                                                    <SwiperSlide class="h-100 p-3">
                                                        <div class="row-span-612">
                                                            <div
                                                                class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                                <div class="imgcalcdivv border-none">
                                                                    <img src="assets/images/calculator/exprtsugg.png"
                                                                        alt="Interior Painting" width=""
                                                                        class="max-w-full w-full h-auto" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </SwiperSlide>
                                                    <SwiperSlide class="h-100 p-3">
                                                        <div class="row-span-612">
                                                            <div
                                                                class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                                <div class="imgcalcdivv border-none">
                                                                    <img src="assets/images/calculator/exprtsugg.png"
                                                                        alt="Interior Painting" width=""
                                                                        class="max-w-full w-full h-auto" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </SwiperSlide>
                                                    <SwiperSlide class="h-100 p-3">
                                                        <div class="row-span-612">
                                                            <div
                                                                class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                                <div class="imgcalcdivv border-none">
                                                                    <img src="assets/images/calculator/exprtsugg.png"
                                                                        alt="Interior Painting" width=""
                                                                        class="max-w-full w-full h-auto" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </SwiperSlide>
                                                    <SwiperSlide class="h-100 p-3">
                                                        <div class="row-span-612">
                                                            <div
                                                                class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                                <div class="imgcalcdivv border-none">
                                                                    <img src="assets/images/calculator/exprtsugg.png"
                                                                        alt="Interior Painting" width=""
                                                                        class="max-w-full w-full h-auto" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </SwiperSlide>
                                                </Swiper>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="getqote rounded-2xl  mt-8 cartvietotldiv bg-pink-100 px-4 py-3">
                                        <h5 class="text-2xl font-bold">Get Expert Colour Consultation</h5>
                                        <p class="text-sm text-gray-500">Book & get a free painting quotation for Asian
                                            Paints colours!</p>
                                        <div class="getqtformdiv">
                                            <form action="">
                                                <div class="cal3fordiv0 capitalize">
                                                    <div class="mt-3 grid grid-cols-3 gap-4"> 
                                                        <div class=" mb-3">
                                                            <label for="first-name"
                                                                class="block text-sm/6 font-medium text-gray-900">Email</label>
                                                            <div class="mt-2">
                                                                <input type="mail" name="first-name" id="first-name"
                                                                    autocomplete="given-name" placeholder="Email"
                                                                    class="block shadow w-full rounded-md px-3 py-1 text-base custsselect h-11 text-gray-900 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                                            </div>
                                                        </div>

                                                        <div class=" mb-3">
                                                            <label for="first-name"
                                                                class="block text-sm/6 font-medium text-gray-900">Mobile</label>
                                                            <div class="mt-2">
                                                                <input type="number" name="first-name" id="first-name"
                                                                    autocomplete="given-name" placeholder="Mobile"
                                                                    class="block shadow w-full rounded-md px-3 py-1 text-base custsselect h-11 text-gray-900 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                                            </div>
                                                        </div>

                                                        <div class=" mb-3">
                                                            <label for="street-address"
                                                                class="block text-sm/6 font-medium text-gray-900">location
                                                               </label>
                                                            <div class="mt-2">
                                                                <input type="text" name="street-location"
                                                                    id="street-location" placeholder="location"
                                                                    autocomplete="street-location"
                                                                    class="block shadow w-full rounded-md px-3 py-1 text-base custsselect h-11 text-gray-900 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                                            </div>
                                                        </div> 
                                                    </div>
                                                    <div class="mb-3">
                                                        <div class="flex gap-3">
                                                            <div class="flex h-6 shrink-0 items-center">
                                                                <div
                                                                    class="group grid size-4 grid-cols-1">
                                                                    <input id="offers"
                                                                        aria-describedby="offers-description"
                                                                        name="offers" type="checkbox"
                                                                        class="col-start-1 row-start-1 appearance-none rounded border border-gray-300 bg-white checked:border-pink-600 checked:bg-pink-600 indeterminate:border-pink-600 indeterminate:bg-pink-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-pink-600  forced-colors:appearance-auto" />
                                                                    <svg class="pointer-events-none col-start-1 row-start-1 size-3.5 self-center justify-self-center stroke-white group-has-[:disabled]:stroke-gray-950/25"
                                                                        viewBox="0 0 14 14" fill="none">
                                                                        <path
                                                                            class="opacity-0 group-has-[:checked]:opacity-100"
                                                                            d="M3 8L6 11L11 3.5"
                                                                            stroke-width="2"
                                                                            stroke-linecap="round"
                                                                            stroke-linejoin="round" />
                                                                        <path
                                                                            class="opacity-0 group-has-[:indeterminate]:opacity-100"
                                                                            d="M3 7H11" stroke-width="2"
                                                                            stroke-linecap="round"
                                                                            stroke-linejoin="round" />
                                                                    </svg>
                                                                </div>
                                                            </div>
                                                            <div class="text-sm/6">
                                                                <p id="offers-description"
                                                                    class="text-gray-500 text-sm">
                                                                    Yes, I want updates on  Whatsapp. Book Free Expert's Call
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="max-w-6xl mx-auto px-5">
                <div class="textcontentdiv pt-100">
                    <h2 class="font-bold text-center">
                        Choose Right Colour For Your House Walls
                    </h2>
                    <p class="text-sm text-gray-500 mt-3">
                        Painting is a quick and efficient approach to offer an old space a pant of outside air. Furthermore, nothing is as close to home as your divider colour. Selecting a colour palette is both the main part just as the scariest part for more than not many with regards to improving their house.

                    </p> 
                    <hr class="my-5" />
                    <h5 class="font-semibold">
                        What Is Actually an Exterior Painting Services company?
                    </h5>
                    <p class="text-sm text-gray-500 mt-3">
                        An Exterior Painting contractor can work as a sub-Exterior Paint
                        Colours company, or sub-contractor, under a general Residential
                        Exterior Painting contractor , or can retain the services of itself
                        out directly to the owner of the house. For the most part, the
                        painting contractor is a relatively smaller sized operation, ranging
                        from the one-man exceptional proprietor up to 25 or 45 painters
                        doing work for an insignificant company.
                    </p>
                    <hr class="my-5" />
                    <h5 class="font-semibold">What Will ColourDrive Do?</h5>
                    <p class="text-sm text-gray-500 mt-3">
                        Virtually all painting contractors will take on any kind of
                        profession, from merely painting you are your window trim to a
                        full-house paint profession. But let us believe that they are
                        painting them your exterior. You can actually usually expect to have
                        from ColourDrive
                    </p> 
                </div> 
                <section id="faq" class="px-4 pt-100">
                    <div class="container mx-auto">
                        <h2 class="text-center font-bold mb-5">FAQs</h2>
                        <div class="accordion flex flex-col items-center justify-center">
                            <!--  Panel 1  -->
                            <div class="w-full lg:w-1/2 shadow11 mb-4">
                                <input type="checkbox" name="panel" id="panel-1" class="hidden" />
                                <label for="panel-1"
                                    class="relative block bg-white text-black p-4 rounded-2xl">Questions text goes
                                    here</label>
                                <div class="accordion__content overflow-hidden">
                                    <p class="accordion__body p-4 text-black" id="panel1">
                                        Lorem Ipsum is simply dummy text of the printing and
                                        typesetting industry. Lorem Ipsum has been the industry's
                                        standard dummy text ever since the 1500s, when an unknown
                                        printer took a galley of type and scrambled it to make a
                                        type specimen.
                                    </p>
                                </div>
                            </div>
                            <!--  Panel 2  -->
                            <div class="w-full lg:w-1/2 shadow11 mb-4">
                                <input type="checkbox" name="panel" id="panel-2" class="hidden" />
                                <label for="panel-2"
                                    class="relative block bg-white text-black p-4 rounded-2xl">Questions text goes
                                    here</label>
                                <div class="accordion__content overflow-hidden">
                                    <p class="accordion__body p-4 text-black" id="panel1">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                                        Iusto possimus at a cum saepe molestias modi illo facere
                                        ducimus voluptatibus praesentium deleniti fugiat ab error
                                        quia sit perspiciatis velit necessitatibus.Lorem ipsum dolor
                                        sit amet, consectetur adipisicing elit. Lorem ipsum dolor
                                        sit amet.
                                    </p>
                                </div>
                            </div>
                            <!--  Panel 3  -->
                            <div class="w-full lg:w-1/2 shadow11 mb-4">
                                <input type="checkbox" name="panel" id="panel-3" class="hidden" />
                                <label for="panel-3"
                                    class="relative block bg-white text-black p-4 rounded-2xl">Questions text goes
                                    here</label>
                                <div class="accordion__content overflow-hidden">
                                    <p class="accordion__body p-4 text-black" id="panel1">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                                        Iusto possimus at a cum saepe molestias modi illo facere
                                        ducimus voluptatibus praesentium deleniti fugiat ab error
                                        quia sit perspiciatis velit necessitatibus.Lorem ipsum dolor
                                        sit amet, consectetur adipisicing elit. Lorem ipsum dolor
                                        sit amet.
                                    </p>
                                </div>
                            </div>
                            <!--  Panel 4  -->
                            <div class="w-full lg:w-1/2 shadow11 mb-4">
                                <input type="checkbox" name="panel" id="panel-4" class="hidden" />
                                <label for="panel-4"
                                    class="relative block bg-white text-black p-4 rounded-2xl">Questions text goes
                                    here</label>
                                <div class="accordion__content overflow-hidden">
                                    <p class="accordion__body p-4 text-black" id="panel1">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                                        Iusto possimus at a cum saepe molestias modi illo facere
                                        ducimus voluptatibus praesentium deleniti fugiat ab error
                                        quia sit perspiciatis velit necessitatibus.Lorem ipsum dolor
                                        sit amet, consectetur adipisicing elit. Lorem ipsum dolor
                                        sit amet.
                                    </p>
                                </div>
                            </div>
                            <!--  Panel 5  -->
                            <div class="w-full lg:w-1/2 shadow11 mb-4">
                                <input type="checkbox" name="panel" id="panel-5" class="hidden" />
                                <label for="panel-5"
                                    class="relative block bg-white text-black p-4 rounded-2xl">Questions text goes
                                    here</label>
                                <div class="accordion__content overflow-hidden">
                                    <p class="accordion__body p-4 text-black" id="panel1">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                                        Iusto possimus at a cum saepe molestias modi illo facere
                                        ducimus voluptatibus praesentium deleniti fugiat ab error
                                        quia sit perspiciatis velit necessitatibus.Lorem ipsum dolor
                                        sit amet, consectetur adipisicing elit. Lorem ipsum dolor
                                        sit amet.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
</template>

<style scoped>
    @import "../assets/css/service.css";
</style>