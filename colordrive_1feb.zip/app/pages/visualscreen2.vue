<script></script>

<template>
    <!-- main banner start -->
    <section id="blog-new" class="py-100 px-3 mb-50px" data-v-inspector="app/pages/blog.vue:5:3" data-v-1bac7c7d="">
        <div class="container mx-auto" data-v-inspector="app/pages/blog.vue:6:5" data-v-1bac7c7d="">
            <!-- <h1>Blog</h1> -->
            <div class="text-center">
                <h2 class="text font-bold">Home Painting Colour Shades Visualizer</h2>
                <div class="flex items-center justify-center gap-2">
                    <a href="/texturepaint">
                        <p>Home</p>
                    </a>
                    <i class="fa-solid fa-chevron-right" style="color: #000000"></i>
                    <p class="text-gray-500">Home Painting Colour Shades Visualizer</p>
                </div>
            </div>
        </div>
    </section>
    <!-- main banner end -->

    <!-- service Post section start -->
    <section id="service-post" class="pb-200 mt-50px px-4 px-md-0">
        <div class="container mx-auto">
            <div class="max-w-full mx-auto">
                <div class="firstsecdiv">
                    <div class="cal3main">
                        <div>
                            <div class="calcseccardsdiv">
                                <div class="calcspace">
                                    <div class="calccardspacemini">
                                        <div class="shadesdivcontdiv mt-8">
                                            <div class="tabcontdiv mb-4">
                                                <div
                                                    class="calccardspacemini sliderdiv justify-center flex flex-row gap-8 text1">
                                                    <div class="calccardspacemini00">
                                                        <button class="btn rounded-full btn-pink text-center px-3 py-2">
                                                            Asian Shades
                                                        </button>
                                                    </div>
                                                    <div class="calccardspacemini00">
                                                        <button
                                                            class="btn rounded-full btn-pink-o text-center px-3 py-2">
                                                            Asian Shades
                                                        </button>
                                                    </div>
                                                    <div class="calccardspacemini00">
                                                        <button
                                                            class="btn rounded-full btn-pink-o text-center px-3 py-2">
                                                            Asian Shades
                                                        </button>
                                                    </div>
                                                    <div class="calccardspacemini00">
                                                        <button
                                                            class="btn rounded-full btn-pink-o text-center px-3 py-2">
                                                            Asian Shades
                                                        </button>
                                                    </div>
                                                    <div class="calccardspacemini00">
                                                        <button
                                                            class="btn rounded-full btn-pink-o text-center px-3 py-2">
                                                            View All Colours
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="flex sm:flex-row flex-col gap-4">
                                            <div class="basis-3/4">
                                                <div class="calccardspacemini0 ">
                                                    <div class="cal3fordiv colosselectgdiv flex gap-4">
                                                        <div
                                                            class="maxhdiv overflow-y-auto faqcustshadow p-4 rounded-lg">
                                                            <div
                                                                class="flex items-center gap-2 flex-col justify-center">
                                                                <!-- Color Option -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-10 h-10 rounded-full bg-pink-500 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <!-- Red -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-10 h-10 rounded-full bg-red-600 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <!-- Green -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-10 h-10 rounded-full bg-green-600 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <!-- Blue -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-10 h-10 rounded-full bg-blue-400 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <!-- Pastel -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-10 h-10 rounded-full bg-rose-200 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <!-- Yellow -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-10 h-10 rounded-full bg-yellow-400 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <!-- Gray -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-10 h-10 rounded-full bg-gray-400 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <!-- Purple -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-10 h-10 rounded-full bg-purple-500 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <!-- Brown -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-10 h-10 rounded-full bg-amber-900 hover:shadow-md">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="calccardspacemini00 faqcustshadow overflow-hidden rounded-lg gap-4 w-full me-2">
                                                            <div
                                                                class="imgcalcdivv visualrightmain align-center w-full rounded-lg overflow-hidden relative ">
                                                                <img src="assets/images/calculator/visultopimg.png"
                                                                    alt="Interior Painting" width=""
                                                                    class="max-w-full w-full object-contain w-full" />
                                                                <div
                                                                    class="absolute bottom-0 w-full bg-white py-4 left-1/2 transform -translate-x-1/2">
                                                                    <div
                                                                        class="flex items-center gap-2 justify-center px-4">
                                                                        <!-- Color Option -->
                                                                        <div class="flex flex-col items-center">
                                                                            <div
                                                                                class="w-10 h-10 rounded-full bg-pink-500 hover:shadow-md">
                                                                            </div>
                                                                        </div>

                                                                        <!-- Red -->
                                                                        <div class="flex flex-col items-center">
                                                                            <div
                                                                                class="w-10 h-10 rounded-full bg-red-600 hover:shadow-md">
                                                                            </div>
                                                                        </div>

                                                                        <h5
                                                                            class="font-semibold text-2xl text-gray-500">
                                                                            Alliance</h5>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="basis-2/4">
                                                <div class="proddetmaindibvcont">
                                                    <h1 class="font-bold text-4xl mb-3">Guest Bedroom Azure Blues Colour
                                                        Shades</h1>
                                                    <p class="text-gray-500">This colour associated with playfulness,
                                                        fun and lightheartedness. Bright shades of pink like magenta or
                                                        fuschia stand out, while being less alarming or threatening than
                                                        the colour red.</p>
                                                    <div class="btnsdivmainnn w-6/12 mt-5 flex flex-col gap-4">
                                                        <button class="btn rounded-lg btn-pink text-center px-3 py-2">
                                                            apply
                                                        </button>
                                                        <button class="btn rounded-lg btn-pink-o text-center px-3 py-2">
                                                            apply
                                                        </button>
                                                        <button class="btn rounded-lg btn-pink-o text-center px-3 py-2">
                                                            apply
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mt-10 colorshadesmaincarddiv">
                                            <div
                                                class="grid grid-cols- sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/visultoolpro.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <div class="flex items-center gap-2 justify-center px-4">
                                                                <!-- Color Option -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-6 h-6 rounded-full bg-pink-500 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <!-- Red -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-6 h-6 rounded-full bg-red-600 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <h5 class="font-semibold text-2xl text-gray-500">
                                                                    Alliance</h5>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/visultoolpro.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <div class="flex items-center gap-2 justify-center px-4">
                                                                <!-- Color Option -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-6 h-6 rounded-full bg-pink-500 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <!-- Red -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-6 h-6 rounded-full bg-red-600 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <h5 class="font-semibold text-2xl text-gray-500">
                                                                    Alliance</h5>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/visultoolpro.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <div class="flex items-center gap-2 justify-center px-4">
                                                                <!-- Color Option -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-6 h-6 rounded-full bg-pink-500 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <!-- Red -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-6 h-6 rounded-full bg-red-600 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <h5 class="font-semibold text-2xl text-gray-500">
                                                                    Alliance</h5>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/visultoolpro.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <div class="flex items-center gap-2 justify-center px-4">
                                                                <!-- Color Option -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-6 h-6 rounded-full bg-pink-500 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <!-- Red -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-6 h-6 rounded-full bg-red-600 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <h5 class="font-semibold text-2xl text-gray-500">
                                                                    Alliance</h5>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/visultoolpro.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <div class="flex items-center gap-2 justify-center px-4">
                                                                <!-- Color Option -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-6 h-6 rounded-full bg-pink-500 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <!-- Red -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-6 h-6 rounded-full bg-red-600 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <h5 class="font-semibold text-2xl text-gray-500">
                                                                    Alliance</h5>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/visultoolpro.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <div class="flex items-center gap-2 justify-center px-4">
                                                                <!-- Color Option -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-6 h-6 rounded-full bg-pink-500 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <!-- Red -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-6 h-6 rounded-full bg-red-600 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <h5 class="font-semibold text-2xl text-gray-500">
                                                                    Alliance</h5>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/visultoolpro.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <div class="flex items-center gap-2 justify-center px-4">
                                                                <!-- Color Option -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-6 h-6 rounded-full bg-pink-500 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <!-- Red -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-6 h-6 rounded-full bg-red-600 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <h5 class="font-semibold text-2xl text-gray-500">
                                                                    Alliance</h5>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/visultoolpro.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <div class="flex items-center gap-2 justify-center px-4">
                                                                <!-- Color Option -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-6 h-6 rounded-full bg-pink-500 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <!-- Red -->
                                                                <div class="flex flex-col items-center">
                                                                    <div
                                                                        class="w-6 h-6 rounded-full bg-red-600 hover:shadow-md">
                                                                    </div>
                                                                </div>

                                                                <h5 class="font-semibold text-2xl text-gray-500">
                                                                    Alliance</h5>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="prodviewmoredivbtn mt-50px text-center">
                                                <a href="/calculator-2" id=" "
                                                    class="btn-pink rounded-lg text-white border px-8 px-4 py-2 focus:outline-none">
                                                    View More
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="calcseccardsdiv my-12 recentwork">
                                        <div class="calcseccardsdiv">
                                            <div class="calcspace">
                                                <div class="calccardtitle mb-3">
                                                    <h3 class="text-3xl font-bold text-center mb-5">
                                                        Recent Work Project Case Study
                                                    </h3>
                                                </div>
                                                <div class="calccardspacemini recentworkslider sliderdiv text1">
                                                    <Swiper class="catalogue" :slides-per-view="1" :loop="true"
                                                        :breakpoints="{
                                                        0: { slidesPerView: 1 }, 
                                                        425: { slidesPerView: 1 }, 
                                                        575: { slidesPerView: 2 }, 
                                                        991: { slidesPerView: 3 },
                                                        1024: { slidesPerView: 3 },
                                                      }" :modules="[
                                                    SwiperAutoplay,
                                                    SwiperEffectCreative,
                                                    SwiperNavigation,
                                                  ]" :autoplay="{
                                                    delay: 3000,
                                                    disableOnInteraction: true,
                                                  }" :pauseAutoplayOnMouseEnter="true" :navigation="true" :pagination="{
                                                    clickable: true,
                                                  }">
                                                        <SwiperSlide class="h-100 p-3">
                                                            <div class="row-span-612">
                                                                <div
                                                                    class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                                    <div class="imgcalcdivv relative border-none">
                                                                        <img src="assets/images/calculator/prod1.png"
                                                                            alt="Interior Painting" width=""
                                                                            class="max-w-full w-full h-auto" />
                                                                        <div class="absolute bottom-5 left-1/2 transform -translate-x-1/2">
                                                                            <h5 class="text-base text-white">
                                                                                Living Room
                                                                            </h5>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </SwiperSlide>
                                                        <SwiperSlide class="h-100 p-3">
                                                            <div class="row-span-612">
                                                                <div
                                                                    class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                                    <div class="imgcalcdivv relative border-none">
                                                                        <img src="assets/images/calculator/prod1.png"
                                                                            alt="Interior Painting" width=""
                                                                            class="max-w-full w-full h-auto" />
                                                                        <div class="absolute bottom-5 left-1/2 transform -translate-x-1/2">
                                                                            <h5 class="text-base text-white">
                                                                                Living Room
                                                                            </h5>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </SwiperSlide>
                                                        <SwiperSlide class="h-100 p-3">
                                                            <div class="row-span-612">
                                                                <div
                                                                    class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                                    <div class="imgcalcdivv relative border-none">
                                                                        <img src="assets/images/calculator/prod1.png"
                                                                            alt="Interior Painting" width=""
                                                                            class="max-w-full w-full h-auto" />
                                                                        <div class="absolute bottom-5 left-1/2 transform -translate-x-1/2">
                                                                            <h5 class="text-base text-white">
                                                                                Living Room
                                                                            </h5>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </SwiperSlide>
                                                        <SwiperSlide class="h-100 p-3">
                                                            <div class="row-span-612">
                                                                <div
                                                                    class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                                    <div class="imgcalcdivv relative border-none">
                                                                        <img src="assets/images/calculator/prod1.png"
                                                                            alt="Interior Painting" width=""
                                                                            class="max-w-full w-full h-auto" />
                                                                        <div class="absolute bottom-5 left-1/2 transform -translate-x-1/2">
                                                                            <h5 class="text-base text-white">
                                                                                Living Room
                                                                            </h5>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </SwiperSlide>
                                                    </Swiper>
                                                </div>
                                            </div>
                                        </div>
                                    </div> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </div>
    </section>
</template>

<style scoped>
    @import "../assets/css/service.css";
</style>