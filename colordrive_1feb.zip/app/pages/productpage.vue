<script></script>

<template>
    <!-- main banner start -->
    <section id="blog-neww" class="py-12 px-3">
        <div class="container mx-auto">
            <!-- <h1>Blog</h1> -->
            <div class="flex items-start text-sm flex-col sm:flex-row sm:items-center gap-2">
                <a href="index.vue" class="flex items-center gap-2">
                    <p>Home</p>
                    <i class="fa-solid fa-chevron-right" style="color: #000000"></i>
                </a>
                <a href="index.vue" class="flex items-center gap-2">
                    <p>Texture Category</p>
                    <i class="fa-solid fa-chevron-right" style="color: #000000"></i>
                </a>
                <p class="pink-txt">Texture Design Collection</p>
            </div>
        </div>
    </section>
    <!-- main banner end -->

    <!-- service Post section start -->
    <!-- service Post section start -->
    <section id="service-post" class="px-4 pb-200 px-md-0">
        <div class="container mx-auto">
            <div class="mx-auto">
                <div class="firstsecdiv">
                    <div class="cal3main">
                        <div>
                            <div class="calcseccardsdiv">
                                <div class="calcspace">
                                    <div class="calccardspacemini">
                                        <div class="flex md:flex-row flex-col gap-5 sm:gap-5">
                                            <div class="basis-2/2 max-w-md m-auto md:basis-1/2 md:max-w-full">
                                                <div class="calccardspacemini00 sticky top-32">
                                                    <div class="imgcalcdiv align-center rounded-md">
                                                        <img src="assets/images/calculator/cal3.png"
                                                            alt="Interior Painting" width=""
                                                            class="br-16 max-w-full object-contain" />
                                                    </div>
                                                    <div class="imgclprodimgslider mt-4">
                                                        <div
                                                            class="grid grid-cols-4 sm:grid-cols-4 grid-flow-col gap-4">
                                                            <div class="row-span-667">
                                                                <div class="calccardspacemini0">
                                                                    <a href="/"
                                                                        class="imgcalcdiv align-center flex justify-center rounded-md">
                                                                        <img src="assets/images/calculator/cal3.png"
                                                                            alt="Interior Painting" width=""
                                                                            class="rounded-xl max-w-full h-auto" />
                                                                    </a>
                                                                    <div class="lablediv mt-2 text-center">
                                                                        <h6 class="font-medium text-sm">Deep Passion
                                                                        </h6>
                                                                        <p class="text-sm text-gray-500">9102</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row-span-667">
                                                                <div class="calccardspacemini0">
                                                                    <a href="/"
                                                                        class="imgcalcdiv align-center flex justify-center rounded-md">
                                                                        <img src="assets/images/calculator/cal3.png"
                                                                            alt="Interior Painting" width=""
                                                                            class="rounded-xl max-w-full h-auto" />
                                                                    </a>
                                                                    <div class="lablediv mt-2 text-center">
                                                                        <h6 class="font-medium text-sm">Armada</h6>
                                                                        <p class="text-sm text-gray-500">9102</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row-span-667">
                                                                <div class="calccardspacemini0">
                                                                    <a href="/"
                                                                        class="imgcalcdiv align-center flex justify-center rounded-md">
                                                                        <img src="assets/images/calculator/cal3.png"
                                                                            alt="Interior Painting" width=""
                                                                            class="rounded-xl max-w-full h-auto" />
                                                                    </a>
                                                                    <div class="lablediv mt-2 text-center">
                                                                        <h6 class="font-medium text-sm">Deep Passion
                                                                        </h6>
                                                                        <p class="text-sm text-gray-500">9102</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row-span-667">
                                                                <div class="calccardspacemini0">
                                                                    <a href="/"
                                                                        class="imgcalcdiv align-center flex justify-center rounded-md">
                                                                        <img src="assets/images/calculator/cal3.png"
                                                                            alt="Interior Painting" width=""
                                                                            class="rounded-xl max-w-full h-auto" />
                                                                    </a>
                                                                    <div class="lablediv mt-2 text-center">
                                                                        <h6 class="font-medium text-sm">Armada</h6>
                                                                        <p class="text-sm text-gray-500">9102</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="sharethidiv flex justify-between mt-4">
                                                        <div class="sharethisdiv">
                                                            <div class="flex gap-2">
                                                                <h3 class="text-md">Share this</h3>
                                                                <ul class="flex gap-2">
                                                                    <li>
                                                                        <a href="#"
                                                                            class="text-gray-500 hover:text-pink-500">
                                                                            <i class="fa-brands fa-facebook"></i>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="#"
                                                                            class="text-gray-500 hover:text-pink-500">
                                                                            <i class="fa-brands fa-twitter"></i>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="#"
                                                                            class="text-gray-500 hover:text-pink-500">
                                                                            <i class="fa-brands fa-instagram"></i>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <a href="#"
                                                                            class="text-gray-500 hover:text-pink-500">
                                                                            <i class="fa-brands fa-linkedin-in"></i>
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="designwebtagdiv flex gap-3 items-center">
                                                            <button
                                                                class="btn-rounded faqcustshadow px-3 py-1 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed">design</button>
                                                            <button
                                                                class="btn-rounded faqcustshadow px-3 py-1 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed">web</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="basis-2/2 md:basis-1/2">
                                                <div class="prodformpagediv sticky top-32">
                                                    <div class="prodpagetitle ">
                                                        <div class="calccardtitle mb-4">
                                                            <h2 class="font-semibold">
                                                                Fizz Wall Texture Painting Design
                                                            </h2>
                                                        </div>
                                                    </div>
                                                    <div class="calccardspacemini0 faqcustshadow p-4 rounded-lg">
                                                        <div class="calccardtitle mb-4">
                                                            <p class="font-bold text-md">
                                                                Book Fizz Paint Design For Your Walls
                                                            </p>
                                                        </div>
                                                        <div class="cal3fordiv">
                                                            <form action="">
                                                                <div class="cal3fordiv0 capitalize">
                                                                    <div class="mt-3">
                                                                        <div class="sm:col-span-3 mb-3">
                                                                            <label for="width"
                                                                                class="block text-sm/6 font-medium text-gray-900">Width(In
                                                                                Feet)</label>
                                                                            <div class="mt-2">
                                                                                <input type="number" name="width"
                                                                                    id="first-name"
                                                                                    autocomplete="given-name"
                                                                                    placeholder="10"
                                                                                    class="block shadow w-full rounded-md px-3 py-1 text-base custsselect h-11 text-gray-900 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                                                            </div>
                                                                        </div>
                                                                        <div class="sm:col-span-3 mb-3">
                                                                            <label for="width"
                                                                                class="block text-sm/6 font-medium text-gray-900">Height(In
                                                                                Feet)</label>
                                                                            <div class="mt-2">
                                                                                <input type="number" name="height"
                                                                                    id="first-name"
                                                                                    autocomplete="given-name"
                                                                                    placeholder="10"
                                                                                    class="block shadow w-full rounded-md px-3 py-1 text-base custsselect h-11 text-gray-900 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                                                            </div>
                                                                        </div>
                                                                        <div class="sm:col-span-3 mb-3">
                                                                            <label for="width"
                                                                                class="block text-sm/6 font-medium text-gray-900">Number
                                                                                Of Walls</label>
                                                                            <div class="mt-2">
                                                                                <div class="relative">
                                                                                    <select
                                                                                        class="block shadow w-full rounded-md px-3 py-1 text-base custsselect h-11 text-gray-900 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6">
                                                                                        <option>10</option>
                                                                                        <option>20</option>
                                                                                        <option>30</option>
                                                                                    </select>
                                                                                    <div
                                                                                        class="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>

                                                                        <div class="sm:col-span-3 mb-3">
                                                                            <label for="first-name"
                                                                                class="block text-sm/6 font-medium text-gray-900">City
                                                                                Price</label>
                                                                            <div class="mt-2">
                                                                                <input type="text" name="cityprice"
                                                                                    id="cityprice"
                                                                                    placeholder="Bangalore - 70/SqFt"
                                                                                    class="block shadow w-full rounded-md px-3 py-1 text-base custsselect h-11 text-gray-900 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6" />
                                                                            </div>
                                                                        </div>
                                                                        <div class="sm:col-span-3 mb-3">
                                                                            <div
                                                                                class="flex priceminimain justify-between">
                                                                                <div class="pricedivmini">
                                                                                    <p class="text-gray-900"><span
                                                                                            class="font-semibold">Chargeable
                                                                                            Area :</span> 100 SqFt</p>
                                                                                </div>
                                                                                <div class="pricedivmini">
                                                                                    <p class="text-gray-900"><span
                                                                                            class="font-semibold">Price
                                                                                            ₹
                                                                                            : </span> 7000 /-</p>
                                                                                </div>
                                                                            </div>
                                                                        </div>

                                                                        <div
                                                                            class="mt-6 flex items-center justify-end gap-x-6">
                                                                            <a href="/productpagecontact"
                                                                                class="m-0 rounded-lg px-2 sm:px-5 py-2.5 main-btn before:ease relative text-center overflow-hidden text-white shadow-2xl transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40 w-full">
                                                                                Get Quote
                                                                            </a>
                                                                            <button type="submit"
                                                                                class="m-0 rounded-lg px-2 sm:px-5 py-2.5 main-btn before:ease relative overflow-hidden text-white shadow-2xl transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40 w-full">
                                                                                Save
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr class="my-10">
                            <div class="calcseccardsdiv">
                                <div class="calcspace">
                                    <div class="calccardspacemini">
                                        <div class="availabilit">
                                            <h3 class="text-xl font-semibold">Please call us to check the more
                                                colour/shades availability.*</h3>
                                            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 mt-3">
                                                <div class="basis-4/5 sm:basis-1/5">
                                                    <div class="availcard">
                                                        <p class="pink-txt text-sm">Name:</p>
                                                        <p class="font-semibold text-sm ">Fizz</p>
                                                    </div>
                                                </div>
                                                <div class="basis-4/5 sm:basis-1/5">
                                                    <div class="availcard">
                                                        <p class="pink-txt text-sm">Product:</p>
                                                        <p class="font-semibold text-sm ">Asian Paints Royale Play</p>
                                                    </div>
                                                </div>
                                                <div class="basis-4/5 sm:basis-1/5">
                                                    <div class="availcard">
                                                        <p class="pink-txt text-sm">Price Rate:</p>
                                                        <p class="font-semibold text-sm ">₹ 70/SqFt</p>
                                                    </div>
                                                </div>
                                                <div class="basis-4/5 sm:basis-1/5">
                                                    <div class="availcard">
                                                        <p class="pink-txt text-sm">Best for:</p>
                                                        <p class="font-semibold text-sm ">Bedroom</p>
                                                    </div>
                                                </div>
                                                <div class="basis-4/5 sm:basis-1/5">
                                                    <div class="availcard">
                                                        <p class="pink-txt text-sm">Category:</p>
                                                        <p class="font-semibold text-sm ">Royale Play Metallic</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="calcseccardsdiv">
                                <div class=" mx-auto px-5">
                                    <div class="textcontentdiv pt-100">
                                        <h3 class="text-xl font-bold text-center mb-5">
                                            More About Fizz Design
                                        </h3>
                                        <h4 class="font-semibold text-xl pink-txt">
                                            What Is Actually an Exterior Painting Services company?
                                        </h4>
                                        <p class="text-sm text-gray-500 mt-3">
                                            Decorate your living room wall with sparkling bubble chilled soft drinks or
                                            soapy water bubbles to refresh the mood.
                                        </p>
                                        <hr class="my-5" />
                                        <h4 class="font-semibold text-xl pink-txt">
                                            Royale Play Metallic Category
                                        </h4>
                                        <p class="text-sm text-gray-500 mt-3">
                                            Royale Play Metallic is a water-based interior paint. It is available in a
                                            variety of shades and special effect textures. You can give your wall a
                                            special effect with daily needs things like texture effects such as combing,
                                            spatula, crinkle in clothes, sponging, dapple, weaving, canvas, color wash,
                                            brushing, ragging by using a variety of texture design tools. It provides a
                                            metallic effect that creates elegant and stylish effects on the wall
                                            surface.
                                        </p>
                                        <p class="text-sm text-gray-500 mt-3">
                                            Royale Play Metallic is suitable for painting smooth wall surfaces. It is
                                            best suitable for kid's room, kitchen, and dining room for having features
                                            like abrasion-resistant, non-flammable, non-toxic, odorless.
                                        </p>
                                        <p class="text-sm text-gray-500 mt-3">
                                            Royale Play Metallic is suitable for painting smooth wall surfaces. It is
                                            best suitable for kid's room, kitchen, and dining room for having features
                                            like abrasion-resistant, non-flammable, non-toxic, odorless.
                                        </p>
                                        <p class="text-sm text-gray-500 mt-3">
                                            Royale Play Metallic is suitable for painting smooth wall surfaces. It is
                                            best suitable for kid's room, kitchen, and dining room for having features
                                            like abrasion-resistant, non-flammable, non-toxic, odorless.
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div class="calcseccardsdiv mt-50px">
                                <div class="calcspace">
                                    <div class="calccardtitle mb-3">
                                        <h3 class="text-xl font-bold text-center mb-5">
                                            How to Apply
                                        </h3>
                                    </div>
                                    <div class="calccardspacemini mb-2">
                                        <div class="grid grid-cols- sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                                            <div class="row-span-612">
                                                <div
                                                    class="servccarddiv-apply relative h-full overflow-hidden">
                                                    <div class="imgcalcdivv border-none w-32">
                                                        <img src="assets/images/calculator/apply1.png"
                                                            alt="Interior Painting" width=""
                                                            class="max-w-full w-full h-auto" />
                                                    </div>
                                                    <div class="lablediv howtoapplyshadow  howtoapplycard text-center p-3 bg-white rounded-2xl" style="border: 1px solid #fc2f93;">
                                                        <h5 class=" text-base pink-txt font-bold">
                                                            Plaster and Cleaning
                                                        </h5>
                                                        <div class="flex justify-between items-center mt-3 ">
                                                            <div class="pricediv">
                                                                <p class="text-gray-500 font-medium">
                                                                    It is recommended to allow 28 days as the curing time for new masonry surfaces. Growths of fungus, algae or moss should be removed by wire brushing and water.
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row-span-612">
                                                <div
                                                    class="servccarddiv-apply relative h-full overflow-hidden">
                                                    <div class="imgcalcdivv border-none w-32">
                                                        <img src="assets/images/calculator/apply2.png"
                                                            alt="Interior Painting" width=""
                                                            class="max-w-full w-full h-auto" />
                                                    </div>
                                                    <div class="lablediv howtoapplyshadow  howtoapplycard text-center p-3 bg-white rounded-2xl" style="border: 1px solid #fc2f93;">
                                                        <h5 class=" text-base pink-txt font-bold">
                                                            Filling for cracks and dents
                                                        </h5>
                                                        <div class="flex justify-between items-center mt-3 ">
                                                            <div class="pricediv">
                                                                <p class="text-gray-500 font-medium">
                                                                    In case of dents and holes, use Asian Paints Acrylic Wall Putty and fine sand in the ratio 1:3. Fill fine cracks using Asian Paints Smartcare Crack Seal.
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row-span-612">
                                                <div
                                                    class="servccarddiv-apply relative h-full overflow-hidden">
                                                    <div class="imgcalcdivv border-none w-32">
                                                        <img src="assets/images/calculator/apply3.png"
                                                            alt="Interior Painting" width=""
                                                            class="max-w-full w-full h-auto" />
                                                    </div>
                                                    <div class="lablediv howtoapplyshadow  howtoapplycard text-center p-3 bg-white rounded-2xl" style="border: 1px solid #fc2f93;">
                                                        <h5 class=" text-base pink-txt font-bold">
                                                            Undercoats
                                                        </h5>
                                                        <div class="flex justify-between items-center mt-3 ">
                                                            <div class="pricediv">
                                                                <p class="text-gray-500 font-medium">
                                                                    Use Trucare Interior Wall Primer (ST) / Trucare Interior Wall Primer (WT) with brush / roller. Apply Acrylic Wall Putty with putty knife to minimize the surface undulations. Apply Trucare Interior Wall Primer (WT) with brush/roller.
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row-span-612">
                                                <div
                                                    class="servccarddiv-apply relative h-full overflow-hidden">
                                                    <div class="imgcalcdivv border-none w-32">
                                                        <img src="assets/images/calculator/apply4.png"
                                                            alt="Interior Painting" width=""
                                                            class="max-w-full w-full h-auto" />
                                                    </div>
                                                    <div class="lablediv howtoapplyshadow  howtoapplycard text-center p-3 bg-white rounded-2xl" style="border: 1px solid #fc2f93;">
                                                        <h5 class=" text-base pink-txt font-bold">
                                                            Topcoat
                                                        </h5>
                                                        <div class="flex justify-between items-center mt-3 ">
                                                            <div class="pricediv">
                                                                <p class="text-gray-500 font-medium">
                                                                    Use 2 coats of Royale Luxury Emulsion as a base coat with roller (1 coat each before and after crinkle paper pasting) and create pattern using 1 coat of Royale Play Special Effects Paint as a top coat. Use application roller to deposit Royale Play Special Effect Paint & Create pattern with the help of recommended application tools.
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="calcseccardsdiv mt-50px">
                                <div class="calcspace">
                                    <div class="calccardtitle mb-3">
                                        <h3 class="text-xl font-bold text-center mb-5">
                                            See Our Real Work
                                        </h3>
                                    </div>
                                    <div class="calccardspacemini sliderdiv text1">
                                        <Swiper class="catalogue" :slides-per-view="1" :loop="true" :breakpoints="{
                                            0: { slidesPerView: 1 }, 
                                            425: { slidesPerView: 1 }, 
                                            575: { slidesPerView: 2 }, 
                                            768: { slidesPerView: 2 },
                                            1024: { slidesPerView: 2 },
                                          }"
                                            :modules="[
                                                SwiperAutoplay,
                                                SwiperEffectCreative,
                                                SwiperNavigation,
                                            ]" :autoplay="{
                                                delay: 3000,
                                                disableOnInteraction: true,
                                            }" :pauseAutoplayOnMouseEnter="true" :navigation="true" :pagination="{
                                                clickable: true,
                                            }">
                                            <SwiperSlide class="h-100">
                                                <div class="m-4 text-center h-100">
                                                    <div class="calccardspacemini0">
                                                        <a href=""
                                                            class="imgcalcdivvv align-center flex justify-center rounded-md">
                                                            <img src="assets/images/calculator/rw1.png"
                                                                alt="Interior Painting" width=""
                                                                class="rounded-xl w-full max-w-full h-auto" />
                                                        </a>
                                                    </div>
                                                    <!-- <div
                                            class="bg-white shadow-mds p-3 sm:p-5 rounded-2xl relative h-100"
                                          >
                                          </div> -->
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100">
                                                <div class="m-4 text-center h-100">
                                                    <div class="calccardspacemini0">
                                                        <a href=""
                                                            class="imgcalcdivvv align-center flex justify-center rounded-md">
                                                            <img src="assets/images/calculator/rw2.png"
                                                                alt="Interior Painting" width=""
                                                                class="rounded-xl w-full max-w-full h-auto" />
                                                        </a>
                                                    </div>
                                                    <!-- <div
                                            class="bg-white shadow-mds p-3 sm:p-5 rounded-2xl relative h-100"
                                          >
                                          </div> -->
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100">
                                                <div class="m-4 text-center h-100">
                                                    <div class="calccardspacemini0">
                                                        <a href=""
                                                            class="imgcalcdivvv align-center flex justify-center rounded-md">
                                                            <img src="assets/images/calculator/rw2.png"
                                                                alt="Interior Painting" width=""
                                                                class="rounded-xl w-full max-w-full h-auto" />
                                                        </a>
                                                    </div>
                                                    <!-- <div
                                            class="bg-white shadow-mds p-3 sm:p-5 rounded-2xl relative h-100"
                                          >
                                          </div> -->
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100">
                                                <div class="m-4 text-center h-100">
                                                    <div class="calccardspacemini0">
                                                        <a href=""
                                                            class="imgcalcdivvv align-center flex justify-center rounded-md">
                                                            <img src="assets/images/calculator/rw1.png"
                                                                alt="Interior Painting" width=""
                                                                class="rounded-xl w-full max-w-full h-auto" />
                                                        </a>
                                                    </div>
                                                    <!-- <div
                                            class="bg-white shadow-mds p-3 sm:p-5 rounded-2xl relative h-100"
                                          >
                                          </div> -->
                                                </div>
                                            </SwiperSlide>
                                        </Swiper>
                                    </div>
                                </div>
                            </div>

                            <div class="calcseccardsdiv mt-50px">
                                <div class="calcspace">
                                    <div class="calccardtitle mb-3">
                                        <h3 class="text-xl font-bold text-center mb-5">
                                            Stencil Painting

                                        </h3>
                                    </div>
                                    <div class="calccardspacemini sliderdiv text1">
                                        <Swiper class="catalogue" :slides-per-view="1" :loop="true" :breakpoints="{
                                            0: { slidesPerView: 1 }, 
                                            425: { slidesPerView: 1 }, 
                                            575: { slidesPerView: 2 }, 
                                            991: { slidesPerView: 3 },
                                            1024: { slidesPerView: 3 },
                                          }"
                                           :modules="[
                                        SwiperAutoplay,
                                        SwiperEffectCreative,
                                        SwiperNavigation,
                                      ]" :autoplay="{
                                        delay: 3000,
                                        disableOnInteraction: true,
                                      }" :pauseAutoplayOnMouseEnter="true" :navigation="true" :pagination="{
                                        clickable: true,
                                      }">
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/prod1.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <h5 class="text-xl font-bold">
                                                                Delta - Royale Play Metallic
                                                            </h5>
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-500 font-semibold">
                                                                        *₹ 70/SqFt
                                                                    </p>
                                                                </div>
                                                                <div class="btnviewsdiv">
                                                                    <a href="/productpage" id=" "
                                                                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none">
                                                                        View Details
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/prod1.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <h5 class="text-xl font-bold">
                                                                Delta - Royale Play Metallic
                                                            </h5>
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-500 font-semibold">
                                                                        *₹ 70/SqFt
                                                                    </p>
                                                                </div>
                                                                <div class="btnviewsdiv">
                                                                    <a href="/productpage" id=" "
                                                                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none">
                                                                        View Details
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/prod1.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <h5 class="text-xl font-bold">
                                                                Delta - Royale Play Metallic
                                                            </h5>
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-500 font-semibold">
                                                                        *₹ 70/SqFt
                                                                    </p>
                                                                </div>
                                                                <div class="btnviewsdiv">
                                                                    <a href="/productpage" id=" "
                                                                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none">
                                                                        View Details
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/prod1.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <h5 class="text-xl font-bold">
                                                                Delta - Royale Play Metallic
                                                            </h5>
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-500 font-semibold">
                                                                        *₹ 70/SqFt
                                                                    </p>
                                                                </div>
                                                                <div class="btnviewsdiv">
                                                                    <a href="/productpage" id=" "
                                                                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none">
                                                                        View Details
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                        </Swiper>
                                    </div>
                                </div>
                            </div>

                            <div class="calcseccardsdiv mt-50px">
                                <div class="calcspace">
                                    <div class="calccardtitle mb-3">
                                        <h3 class="text-xl font-bold text-center mb-5">
                                            Kids Room Decor

                                        </h3>
                                    </div>
                                    <div class="calccardspacemini sliderdiv text1">
                                        <Swiper class="catalogue" :slides-per-view="1" :loop="true" :breakpoints="{
                                            0: { slidesPerView: 1 }, 
                                            425: { slidesPerView: 1 }, 
                                            575: { slidesPerView: 2 }, 
                                            991: { slidesPerView: 3 },
                                            1024: { slidesPerView: 3 },
                                          }" :modules="[
                                        SwiperAutoplay,
                                        SwiperEffectCreative,
                                        SwiperNavigation,
                                      ]" :autoplay="{
                                        delay: 3000,
                                        disableOnInteraction: true,
                                      }" :pauseAutoplayOnMouseEnter="true" :navigation="true" :pagination="{
                                        clickable: true,
                                      }">
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/prod1.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <h5 class="text-xl font-bold">
                                                                Delta - Royale Play Metallic
                                                            </h5>
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-500 font-semibold">
                                                                        *₹ 70/SqFt
                                                                    </p>
                                                                </div>
                                                                <div class="btnviewsdiv">
                                                                    <a href="/productpage" id=" "
                                                                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none">
                                                                        View Details
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/prod1.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <h5 class="text-xl font-bold">
                                                                Delta - Royale Play Metallic
                                                            </h5>
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-500 font-semibold">
                                                                        *₹ 70/SqFt
                                                                    </p>
                                                                </div>
                                                                <div class="btnviewsdiv">
                                                                    <a href="/productpage" id=" "
                                                                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none">
                                                                        View Details
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/prod1.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <h5 class="text-xl font-bold">
                                                                Delta - Royale Play Metallic
                                                            </h5>
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-500 font-semibold">
                                                                        *₹ 70/SqFt
                                                                    </p>
                                                                </div>
                                                                <div class="btnviewsdiv">
                                                                    <a href="/productpage" id=" "
                                                                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none">
                                                                        View Details
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/prod1.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <h5 class="text-xl font-bold">
                                                                Delta - Royale Play Metallic
                                                            </h5>
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-500 font-semibold">
                                                                        *₹ 70/SqFt
                                                                    </p>
                                                                </div>
                                                                <div class="btnviewsdiv">
                                                                    <a href="/productpage" id=" "
                                                                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none">
                                                                        View Details
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                        </Swiper>
                                    </div>
                                </div>
                            </div>

                            <div class="calcseccardsdiv mt-50px">
                                <div class="calcspace">
                                    <div class="calccardtitle mb-3">
                                        <h3 class="text-xl font-bold text-center mb-5">
                                            Free Hand Paint Art

                                        </h3>
                                    </div>
                                    <div class="calccardspacemini sliderdiv text1">
                                        <Swiper class="catalogue" :slides-per-view="1" :loop="true" :breakpoints="{
                                            0: { slidesPerView: 1 }, 
                                            425: { slidesPerView: 1 }, 
                                            575: { slidesPerView: 2 }, 
                                            991: { slidesPerView: 3 },
                                            1024: { slidesPerView: 3 },
                                          }" :modules="[
                                        SwiperAutoplay,
                                        SwiperEffectCreative,
                                        SwiperNavigation,
                                      ]" :autoplay="{
                                        delay: 3000,
                                        disableOnInteraction: true,
                                      }" :pauseAutoplayOnMouseEnter="true" :navigation="true" :pagination="{
                                        clickable: true,
                                      }">
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/prod1.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <h5 class="text-xl font-bold">
                                                                Delta - Royale Play Metallic
                                                            </h5>
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-500 font-semibold">
                                                                        *₹ 70/SqFt
                                                                    </p>
                                                                </div>
                                                                <div class="btnviewsdiv">
                                                                    <a href="/productpage" id=" "
                                                                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none">
                                                                        View Details
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/prod1.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <h5 class="text-xl font-bold">
                                                                Delta - Royale Play Metallic
                                                            </h5>
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-500 font-semibold">
                                                                        *₹ 70/SqFt
                                                                    </p>
                                                                </div>
                                                                <div class="btnviewsdiv">
                                                                    <a href="/productpage" id=" "
                                                                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none">
                                                                        View Details
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/prod1.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <h5 class="text-xl font-bold">
                                                                Delta - Royale Play Metallic
                                                            </h5>
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-500 font-semibold">
                                                                        *₹ 70/SqFt
                                                                    </p>
                                                                </div>
                                                                <div class="btnviewsdiv">
                                                                    <a href="/productpage" id=" "
                                                                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none">
                                                                        View Details
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/prod1.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <h5 class="text-xl font-bold">
                                                                Delta - Royale Play Metallic
                                                            </h5>
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-500 font-semibold">
                                                                        *₹ 70/SqFt
                                                                    </p>
                                                                </div>
                                                                <div class="btnviewsdiv">
                                                                    <a href="/productpage" id=" "
                                                                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none">
                                                                        View Details
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                        </Swiper>
                                    </div>
                                </div>
                            </div>

                            <div class="calcseccardsdiv mt-50px">
                                <div class="calcspace">
                                    <div class="calccardtitle mb-3">
                                        <h3 class="text-xl font-bold text-center mb-5">
                                            Exterior Wall Textures
                                        </h3>
                                    </div>
                                    <div class="calccardspacemini sliderdiv text1">
                                        <Swiper class="catalogue" :slides-per-view="1" :loop="true" :breakpoints="{
                                            0: { slidesPerView: 1 }, 
                                            425: { slidesPerView: 1 }, 
                                            575: { slidesPerView: 2 }, 
                                            991: { slidesPerView: 3 },
                                            1024: { slidesPerView: 3 },
                                          }" :modules="[
                                        SwiperAutoplay,
                                        SwiperEffectCreative,
                                        SwiperNavigation,
                                      ]" :autoplay="{
                                        delay: 3000,
                                        disableOnInteraction: true,
                                      }" :pauseAutoplayOnMouseEnter="true" :navigation="true" :pagination="{
                                        clickable: true,
                                      }">
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/prod1.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <h5 class="text-xl font-bold">
                                                                Delta - Royale Play Metallic
                                                            </h5>
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-500 font-semibold">
                                                                        *₹ 70/SqFt
                                                                    </p>
                                                                </div>
                                                                <div class="btnviewsdiv">
                                                                    <a href="/productpage" id=" "
                                                                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none">
                                                                        View Details
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/prod1.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <h5 class="text-xl font-bold">
                                                                Delta - Royale Play Metallic
                                                            </h5>
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-500 font-semibold">
                                                                        *₹ 70/SqFt
                                                                    </p>
                                                                </div>
                                                                <div class="btnviewsdiv">
                                                                    <a href="/productpage" id=" "
                                                                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none">
                                                                        View Details
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/prod1.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <h5 class="text-xl font-bold">
                                                                Delta - Royale Play Metallic
                                                            </h5>
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-500 font-semibold">
                                                                        *₹ 70/SqFt
                                                                    </p>
                                                                </div>
                                                                <div class="btnviewsdiv">
                                                                    <a href="/productpage" id=" "
                                                                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none">
                                                                        View Details
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <img src="assets/images/calculator/prod1.png"
                                                                alt="Interior Painting" width=""
                                                                class="max-w-full w-full h-auto" />
                                                        </div>
                                                        <div class="lablediv p-3">
                                                            <h5 class="text-xl font-bold">
                                                                Delta - Royale Play Metallic
                                                            </h5>
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-500 font-semibold">
                                                                        *₹ 70/SqFt
                                                                    </p>
                                                                </div>
                                                                <div class="btnviewsdiv">
                                                                    <a href="/productpage" id=" "
                                                                        class="btn-pink btn-rounded text-white border px-8 px-4 py-2 focus:outline-none">
                                                                        View Details
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                        </Swiper>
                                    </div>
                                </div>
                            </div>

                            <div class="calcseccardsdiv mt-50px">
                                <div class="calcspace">
                                    <div class="calccardtitle mb-3">
                                        <h3 class="text-xl font-bold text-center mb-5">
                                            See Our Wall Texture Work
                                        </h3>
                                    </div>
                                    <div class="calccardspacemini sliderdiv text1">
                                        <Swiper class="catalogue" :slides-per-view="1" :loop="true" :breakpoints="{
                                            0: { slidesPerView: 1 }, 
                                            425: { slidesPerView: 1 }, 
                                            575: { slidesPerView: 2 }, 
                                            991: { slidesPerView: 3 },
                                            1024: { slidesPerView: 3 },
                                          }" :modules="[ 
                                        SwiperEffectCreative,
                                        SwiperNavigation,
                                      ]" :autoplay="{
                                        delay: 3000,
                                        disableOnInteraction: true,
                                      }" :pauseAutoplayOnMouseEnter="true" :navigation="true" :pagination="{
                                        clickable: true,
                                      }">
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <video loop autoplay controls>
                                                                <source src="https://endtest-videos.s3-us-west-2.amazonaws.com/documentation/endtest_data_driven_testing_csv.mp4" type="video/mp4">
                                                                <!-- <source src="video.webm" type="video/webm"> -->
                                                                Your browser does not support the video tag.
                                                            </video>
                                                        </div>
                                                        <div class="lablediv p-3"> 
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-900 text-sm">
                                                                        Asian Paints Calcecruda Texture | Royale Play Calcecruda | Wall Texture | IDC Calcecruda Stencils
                                                                    </p>
                                                                </div>
                                                                 
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <video loop autoplay controls>
                                                                <source src="https://endtest-videos.s3-us-west-2.amazonaws.com/documentation/endtest_data_driven_testing_csv.mp4" type="video/mp4">
                                                                <!-- <source src="video.webm" type="video/webm"> -->
                                                                Your browser does not support the video tag.
                                                            </video>
                                                        </div>
                                                        <div class="lablediv p-3"> 
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-900 text-sm">
                                                                        Asian Paints Calcecruda Texture | Royale Play Calcecruda | Wall Texture | IDC Calcecruda Stencils
                                                                    </p>
                                                                </div>
                                                                 
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <video loop autoplay controls>
                                                                <source src="https://endtest-videos.s3-us-west-2.amazonaws.com/documentation/endtest_data_driven_testing_csv.mp4" type="video/mp4">
                                                                <!-- <source src="video.webm" type="video/webm"> -->
                                                                Your browser does not support the video tag.
                                                            </video>
                                                        </div>
                                                        <div class="lablediv p-3"> 
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-900 text-sm">
                                                                        Asian Paints Calcecruda Texture | Royale Play Calcecruda | Wall Texture | IDC Calcecruda Stencils
                                                                    </p>
                                                                </div>
                                                                 
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                            <SwiperSlide class="h-100 p-3">
                                                <div class="row-span-612">
                                                    <div
                                                        class="servccarddiv bg-white custshadow overflow-hidden rounded-2xl">
                                                        <div class="imgcalcdivv border-none">
                                                            <video loop autoplay controls>
                                                                <source src="https://endtest-videos.s3-us-west-2.amazonaws.com/documentation/endtest_data_driven_testing_csv.mp4" type="video/mp4">
                                                                <!-- <source src="video.webm" type="video/webm"> -->
                                                                Your browser does not support the video tag.
                                                            </video>
                                                        </div>
                                                        <div class="lablediv p-3"> 
                                                            <div class="flex justify-between items-center mt-3 h-10">
                                                                <div class="pricediv">
                                                                    <p class="text-gray-900 text-sm">
                                                                        Asian Paints Calcecruda Texture | Royale Play Calcecruda | Wall Texture | IDC Calcecruda Stencils
                                                                    </p>
                                                                </div>
                                                                 
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </SwiperSlide>
                                             
                                        </Swiper>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<style scoped>
    @import "../assets/css/service.css";
</style>