<script setup></script>

<template>
  <!-- service Post section start -->
  <section id="service-post" class="mt-50px px-4 px-md-0">
    <div class="container mx-auto">
      <div class="max-w-full mx-auto">
        <div class="firstsecdiv">
          <div class="cal3main">
            <div>
              <div class="calcseccardsdiv">
                <div class="calcspace">
                  <div class="calccardspacemini">
                    <div class="flex sm:flex-row flex-col  gap-4">
                      <div class="basis-1/2">
                        <div class="calccardspacemini00 sticky top-32">
                          <div class="imgcalcdiv align-center rounded-md">
                            <img
                              src="assets/images/calculator/cal3.png"
                              alt="Interior Painting"
                              width=""
                              class="br-16 max-w-full w-full object-contain"
                            />
                          </div>
                        </div>
                      </div>
                      <div class="basis-1/2">
                        <div
                          class="calccardspacemini0 faqcustshadow p-4 rounded-lg"
                        >
                          <div class="calccardtitle mb-3">
                            <p class="font-bold text-md">Book Now</p>
                            <p class="text-gray-500 text-sm">
                              Fill the form below to book a free site evaluation
                              by a Beautiful Homes Painting Service expert.
                            </p>
                          </div>
                          <div class="cal3fordiv">
                            <form action="">
                              <div class="cal3fordiv0 capitalize">
                                <div class="mt-3">
                                  <div class="sm:col-span-3 mb-3">
                                    <label
                                      for="first-name"
                                      class="block text-sm/6 font-medium text-gray-900"
                                      >Name</label
                                    >
                                    <div class="mt-2">
                                      <input
                                        type="text"
                                        name="first-name"
                                        id="first-name"
                                        autocomplete="given-name"
                                        placeholder="Name"
                                        class="block shadow w-full rounded-md px-3 py-1 text-base custsselect h-11 text-gray-900 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                      />
                                    </div>
                                  </div>

                                  <div class="sm:col-span-3 mb-3">
                                    <label
                                      for="first-name"
                                      class="block text-sm/6 font-medium text-gray-900"
                                      >Email</label
                                    >
                                    <div class="mt-2">
                                      <input
                                        type="mail"
                                        name="first-name"
                                        id="first-name"
                                        autocomplete="given-name"
                                        placeholder="Email"
                                        class="block shadow w-full rounded-md px-3 py-1 text-base custsselect h-11 text-gray-900 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                      />
                                    </div>
                                  </div>

                                  <div class="sm:col-span-3 mb-3">
                                    <label
                                      for="first-name"
                                      class="block text-sm/6 font-medium text-gray-900"
                                      >Mobile</label
                                    >
                                    <div class="mt-2">
                                      <input
                                        type="number"
                                        name="first-name"
                                        id="first-name"
                                        autocomplete="given-name"
                                        placeholder="Mobile"
                                        class="block shadow w-full rounded-md px-3 py-1 text-base custsselect h-11 text-gray-900 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                      />
                                      <p
                                        class="text-gray-400 text-xs mt-1 text-end w-100"
                                      >
                                        Verify with OTP
                                      </p>
                                    </div>
                                  </div>

                                  <div class="sm:col-span-3 mb-3">
                                    <label
                                      for="street-address"
                                      class="block text-sm/6 font-medium text-gray-900"
                                      >Address 01</label
                                    >
                                    <div class="mt-2">
                                      <input
                                        type="text"
                                        name="street-address"
                                        id="street-address"
                                        placeholder="Address 01"
                                        autocomplete="street-address"
                                        class="block shadow w-full rounded-md px-3 py-1 text-base custsselect h-11 text-gray-900 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                      />
                                    </div>
                                  </div>

                                  <div class="sm:col-span-3 mb-3">
                                    <label
                                      for="street-address"
                                      class="block text-sm/6 font-medium text-gray-900"
                                      >Address 02</label
                                    >
                                    <div class="mt-2">
                                      <input
                                        type="text"
                                        name="street-address"
                                        id="street-address"
                                        placeholder="Address 02"
                                        autocomplete="street-address"
                                        class="block shadow w-full rounded-md px-3 py-1 text-base custsselect h-11 text-gray-900 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                      />
                                    </div>
                                  </div>

                                  <div class="grid grid-cols-2 gap-3">
                                    <div class="mb-3">
                                      <label
                                        for="pincode"
                                        class="block text-sm/6 font-medium text-gray-900"
                                        >Pincode</label
                                      >
                                      <div class="mt-2">
                                        <input
                                          type="number"
                                          name="pincode"
                                          id="pincode"
                                          placeholder="Address 02"
                                          autocomplete="pincode"
                                          class="block shadow w-full rounded-md px-3 py-1 text-base custsselect h-11 text-gray-900 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                        />
                                      </div>
                                    </div>
                                    <div class="mb-3">
                                      <label
                                        for="state"
                                        class="block text-sm/6 font-medium text-gray-900"
                                        >state</label
                                      >
                                      <div class="mt-2">
                                        <input
                                          type="text"
                                          name="state"
                                          id="state"
                                          placeholder="Gujarat"
                                          autocomplete="state"
                                          class="block shadow w-full rounded-md px-3 py-1 text-base custsselect h-11 text-gray-900 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                        />
                                      </div>
                                    </div>
                                  </div>
                                  <div class="mb-3">
                                    <label
                                      for="date"
                                      class="block text-sm/6 font-medium text-gray-900"
                                      >date</label
                                    >
                                    <div class="mt-2">
                                      <input
                                        type="date"
                                        name="date"
                                        id="date"
                                        placeholder="Gujarat"
                                        autocomplete="date"
                                        class="block shadow w-full rounded-md px-3 py-1 text-base custsselect h-11 text-gray-900 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm/6"
                                      />
                                    </div>
                                  </div>
                                  <div class="mb-3">
                                    <div class="flex gap-3">
                                      <div
                                        class="flex h-6 shrink-0 items-center"
                                      >
                                        <div
                                          class="group grid size-4 grid-cols-1"
                                        >
                                          <input
                                            id="offers"
                                            aria-describedby="offers-description"
                                            name="offers"
                                            type="checkbox"
                                            class="col-start-1 row-start-1 appearance-none rounded border border-gray-300 bg-white checked:border-indigo-600 checked:bg-indigo-600 indeterminate:border-indigo-600 indeterminate:bg-indigo-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 disabled:border-gray-300 disabled:bg-gray-100 disabled:checked:bg-gray-100 forced-colors:appearance-auto"
                                          />
                                          <svg
                                            class="pointer-events-none col-start-1 row-start-1 size-3.5 self-center justify-self-center stroke-white group-has-[:disabled]:stroke-gray-950/25"
                                            viewBox="0 0 14 14"
                                            fill="none"
                                          >
                                            <path
                                              class="opacity-0 group-has-[:checked]:opacity-100"
                                              d="M3 8L6 11L11 3.5"
                                              stroke-width="2"
                                              stroke-linecap="round"
                                              stroke-linejoin="round"
                                            />
                                            <path
                                              class="opacity-0 group-has-[:indeterminate]:opacity-100"
                                              d="M3 7H11"
                                              stroke-width="2"
                                              stroke-linecap="round"
                                              stroke-linejoin="round"
                                            />
                                          </svg>
                                        </div>
                                      </div>
                                      <div class="text-sm/6">
                                        <p
                                          id="offers-description"
                                          class="text-gray-500 text-sm"
                                        >
                                          T&C and Privacy Policy
                                        </p>
                                      </div>
                                    </div>
                                  </div>
                                  <div
                                    class="mt-6 flex items-center justify-end gap-x-6"
                                  >
                                    <button
                                      type="submit"
                                      class="rounded-md btn-pink w-full px-3 py-2 text-sm font-semibold text-white shadow-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                                    >
                                      Book Now
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> 
    </div>
  </section>
  <!-- service Post section end -->
</template>

<style scoped>
@import "../assets/css/service.css";
</style>
