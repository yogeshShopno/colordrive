<script>
//add javascript of this template only
</script>
<template>

    
<div>
    <!-- footer -->
    <section class="relative bg-gray1">
        <!-- CTA start -->
        <section class="px-4 cta-position">
            <div class="container mx-auto" id="cta-bg">
                <div class="grid gap-x-8 gap-y-4 grid-cols-2 items-center flex-column">
                    <div>
                        <img src="assets/images/cta2.webp" alt="cta" class="hidden xl:block" />
                        <img src="assets/images/res-cta.webp" alt="cta" class="block xl:hidden rounded-2xl" />
                    </div>
                    <div class="text-center md:text-start mx-3 md-mx-0">
                        <h5 class="text-white">Unable To Decide Upon a Colour?</h5>
                        <h2 class="text-white font-semibold">
                            Request Home Painting Services !
                        </h2>
                        <h4>Share details for Free Online-Quotation.</h4>
                        <button type="button" onclick="toggleModal1()" class="mb-4 xl:mb-0 mt-4 text-black bg-yellow cta-btn font-medium rounded-lg text-sm px-5 py-2.5 text-center before:ease relative overflow-hidden transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40">
                            <span relative="relative z-10">Enquire Now</span>
                        </button>
                    </div>
                </div>
            </div>
        </section>
        <!-- CTA start -->
        <section id="footer" class="pt-200 px-4 ">
            <a href="https://wa.me/919014182316" target="_blank">
            <img src="../assets/images/whatsapp-icon.png" alt="whatapp-icon" class="whatsapp"></a>
            <a href="" id="more-btn">
                <button
            type="button"
            class="m-0 text-white rounded px-8 py-2.5 more-btn pulse-animation"
          >
            More
          </button>
            </a>
            <div class="container mx-auto  pb-4 lg:pb-0">
                <div class="flex text-white flex-wrap">
                    <div class="w-full md:w-full lg:w-4/12 xl:w-4/12 mb-3 lg:mb-0">
                        <div class="mb-4">
                            <a href="/landing1">
                                <h1>LOREM</h1>
                            </a>
                        </div>
                        <div>
                            <p class="w-75 mb-3">
                                Home Painting Service Provider - Interior Painting, Exterior Painting, Rental Painting, Texture, Stencil, Kids Decor, Wallpaper, Free Hand Art, False Ceiling, Deep Cleaning, Waterproofing Service Provider in Bangalore, Hyderabad, Mumbai, Pune, Delhi, Bhopal, Indore
                            </p>
                            <ul class="p-0 m-0">
                                <li>
                                    <a href="mailto: support@colourdrive.in">support@colourdrive.in</a>
                                </li>
                                <li><a href="tel: +91-8151825126">+91-8151825126 </a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="w-6/12 md:w-3/12 lg:w-2/12 xl:w-2/12">
                        <h5 class="mb-4 font-medium">Infomation</h5>
                        <ul>
                            <li>Paints & Colours</li>
                            <li>Services</li>
                            <li>Waterproofing</li>
                            <li>Inspiration</li>
                            <li>Home Decor</li>
                            <li>Shop</li>
                        </ul>
                    </div>
                    <div class="w-6/12 md:w-5/12 lg:w-3/12 xl:w-3/12">
                        <h5 class="mb-4 font-medium">Services</h5>
                        <ul>
                            <li>Expert Site Supervision</li>
                            <li>Trained Professionals</li>
                            <li>Dust Free Mechanised Painting</li>
                            <li>Superior Finish</li>
                            <li>Full Home Cleaning After Painting</li>
                            <li>Asian Paints Warranty</li>
                        </ul>
                    </div>
                    <div class="w-full md:w-4/12 lg:w-3/12 xl:w-3/12">
                        <h5 class="mb-4 font-medium">Send Email</h5>
                        <div class="mb-3">
                            <form class="flex" id="subscription">
                                <div class="sm:flex sm:flex-wrap w-75">
                                    <input type="email" id="email" class="text-gray-900 text-sm block w-full p-2.5 dark:placeholder-gray-400 dark:text-white" placeholder="Enter your email" required />
                                </div>
                                <button type="submit" class="w-25 text-white main-btn font-medium text-sm p-2.5 text-center before:ease relative overflow-hidden transition-all before:absolute before:right-0 before:top-0 before:h-12 before:w-6 before:translate-x-12 before:rotate-6 before:bg-white before:opacity-10 before:duration-700 hover:shadow-pink-500 hover:before:-translate-x-40">
                                    <span relative="relative z-10">Send</span>
                                </button>
                            </form>

                            <!-- Success and error messages -->
                            <div id="message1" class="hidden text-center"></div>
                        </div>
                        <p>
                            Lorem Ipsum is simply dummy text of the printing and typesetting
                            industry. Lorem Ipsum has been.
                        </p>
                    </div>
                </div>
            </div>
            <div class="container border-t py-3 mx-auto text-white">
                <div class="grid gap-x-8 gap-y-4 sm:grid-cols-2 lg:grid-cols-3">
                    <div>
                        <p>©LoremDesign2020.</p>
                    </div>
                    <div class="justify-start sm:justify-end lg:justify-center flex">
                        <p>Privacy Policy | Terms & Conditions</p>
                    </div>
                    <div>
                        <ul class="flex gap-4 sm:justify-start lg:justify-end">
                            <li>
                                <a href="https://www.google.com/maps/place/ColourDrive/@12.8937837,77.583295,17z/data=!3m1!4b1!4m5!3m4!1s0x0:0x7e9b60370dd008f9!8m2!3d12.8937837!4d77.5854837?shorturl=1">
                                    <img src="../assets/images/home/google1.svg" alt="Google"> </a>
                            </li>
                            <li>
                                <a href="https://www.facebook.com/colourdrive/">
                                    <img src="../assets/images/home/facebook.svg" alt="facebook"></a>
                            </li>
                            <li>
                                <a href="https://www.instagram.com/colourdrive.in/">
                                    <img src="../assets/images/home/instagram.svg" alt="instagram"></a>
                            </li>
                            <li>
                                <a href="https://x.com/ColourDrive?mx=2">
                                    <img src="../assets/images/home/twitter.svg" alt="twitter"></a>
                            </li>
                            <li>
                                <a href="https://in.pinterest.com/colourdrive/">
                                    <img src="../assets/images/home/pinterest.svg" alt="pinterest"></a>
                            </li>
                            <li>
                                <a href="https://www.linkedin.com/company/colourdrive">
                                    <img src="../assets/images/home/linkdin.svg" alt="linkdin"></a>
                            </li>
                            <li>
                                <a href="https://www.youtube.com/channel/UCTtaHhqN87LYIGi-osmCLow">
                                    <img src="../assets/images/home/youtube1.svg" alt="youtube1"></a>
                            </li>
                            <li>
                                <a href="https://www.quora.com/profile/ColourDrive-1">
                                    <img src="../assets/images/home/quora.svg" alt="quora"></a>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </section>
    </section>
    <!-- footer -->

</div>
</template>

<style scoped>
@import '../assets/css/main.css';
</style>
